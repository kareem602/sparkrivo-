import { useTheme, type ThemeMode } from './ThemeContext'

interface Props {
  onClose: () => void
}

const OPTIONS: { id: ThemeMode; label: string; desc: string; icon: string }[] = [
  { id: 'light',  label: 'Light',  desc: 'Clean white interface',         icon: '☀️' },
  { id: 'dark',   label: 'Dark',   desc: 'Easy on the eyes at night',     icon: '🌙' },
  { id: 'system', label: 'System', desc: 'Follows your device setting',   icon: '🔄' },
]

export default function ThemeSettings({ onClose }: Props) {
  const { mode, setMode, isDark } = useTheme()

  return (
    <div
      className="absolute inset-0 z-[250] flex flex-col animate-slide-up"
      style={{ background: 'var(--color-bg)' }}
    >
      {/* Header */}
      <div
        className="flex-shrink-0 flex items-center gap-3 px-4 py-4"
        style={{ borderBottom: '1px solid var(--color-border)' }}
      >
        <button
          onClick={onClose}
          className="w-9 h-9 flex items-center justify-center rounded-full active:scale-90 transition-transform"
          style={{ background: 'var(--color-bg-tertiary)', color: 'var(--color-text-secondary)' }}
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div>
          <h2 className="font-bold text-base" style={{ color: 'var(--color-text)' }}>Appearance</h2>
          <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>Choose your preferred theme</p>
        </div>
        <span className="ml-auto text-2xl">{isDark ? '🌙' : '☀️'}</span>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5">

        {/* Live preview card */}
        <div
          className="rounded-2xl overflow-hidden shadow-md"
          style={{ border: '1px solid var(--color-border)' }}
        >
          {/* Mock header preview */}
          <div
            className="px-4 py-3 flex items-center justify-between"
            style={{ background: 'var(--color-nav-bg)', borderBottom: '1px solid var(--color-nav-border)' }}
          >
            <span className="text-base font-black" style={{ color: '#ff4d6d' }}>♥ SparkMatch</span>
            <div className="flex gap-2">
              <div className="w-6 h-6 rounded-full" style={{ background: 'var(--color-bg-tertiary)' }} />
              <div className="w-6 h-6 rounded-full" style={{ background: 'var(--color-bg-tertiary)' }} />
            </div>
          </div>
          {/* Mock body */}
          <div className="px-4 py-3 space-y-2" style={{ background: 'var(--color-bg)' }}>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full" style={{ background: 'var(--color-primary)', opacity: 0.7 }} />
              <div className="flex-1 space-y-1">
                <div className="h-2 rounded-full w-24" style={{ background: 'var(--color-text)', opacity: 0.15 }} />
                <div className="h-1.5 rounded-full w-16" style={{ background: 'var(--color-text-tertiary)', opacity: 0.4 }} />
              </div>
            </div>
            {/* Mock chat bubbles */}
            <div className="flex justify-end">
              <div className="px-3 py-1.5 rounded-2xl rounded-br-sm text-[11px] font-medium text-white" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
                Hey! How are you? 😊
              </div>
            </div>
            <div className="flex justify-start">
              <div className="px-3 py-1.5 rounded-2xl rounded-bl-sm text-[11px] font-medium" style={{ background: 'var(--color-bubble-in)', color: 'var(--color-bubble-in-text)' }}>
                I'm great, thanks! ✨
              </div>
            </div>
          </div>
          {/* Mock nav */}
          <div
            className="px-4 py-2 flex justify-around"
            style={{ background: 'var(--color-nav-bg)', borderTop: '1px solid var(--color-nav-border)' }}
          >
            {['Discover', 'Feed', 'Matches', 'Profile'].map((n, i) => (
              <div key={n} className="flex flex-col items-center gap-0.5">
                <div
                  className="w-5 h-5 rounded-full"
                  style={{ background: i === 1 ? '#ff4d6d' : 'var(--color-nav-icon)', opacity: i === 1 ? 1 : 0.4 }}
                />
                <span className="text-[8px] font-medium" style={{ color: i === 1 ? '#ff4d6d' : 'var(--color-nav-icon)' }}>{n}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Options */}
        <div className="space-y-3">
          {OPTIONS.map(opt => {
            const selected = mode === opt.id
            return (
              <button
                key={opt.id}
                onClick={() => setMode(opt.id)}
                className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-left active:scale-[0.98] transition-all"
                style={{
                  background: selected ? 'var(--color-primary-bg)' : 'var(--color-card-bg)',
                  border: `2px solid ${selected ? 'var(--color-primary)' : 'var(--color-card-border)'}`,
                }}
              >
                <span className="text-2xl">{opt.icon}</span>
                <div className="flex-1">
                  <p className="font-bold text-sm" style={{ color: selected ? '#ff4d6d' : 'var(--color-text)' }}>
                    {opt.label}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: 'var(--color-text-secondary)' }}>{opt.desc}</p>
                </div>
                {/* Radio */}
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                  style={{
                    border: `2px solid ${selected ? '#ff4d6d' : 'var(--color-border-soft)'}`,
                    background: selected ? '#ff4d6d' : 'transparent',
                  }}
                >
                  {selected && <div className="w-2 h-2 rounded-full bg-white" />}
                </div>
              </button>
            )
          })}
        </div>

        {/* Quick toggle row */}
        <div
          className="rounded-2xl px-4 py-4 flex items-center justify-between"
          style={{ background: 'var(--color-card-bg)', border: '1px solid var(--color-card-border)' }}
        >
          <div className="flex items-center gap-3">
            <span className="text-xl">{isDark ? '🌙' : '☀️'}</span>
            <div>
              <p className="font-semibold text-sm" style={{ color: 'var(--color-text)' }}>
                {isDark ? 'Dark mode active' : 'Light mode active'}
              </p>
              <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>Quick toggle</p>
            </div>
          </div>
          <button
            onClick={() => setMode(isDark ? 'light' : 'dark')}
            className="relative w-12 h-6 rounded-full transition-colors duration-300"
            style={{ background: isDark ? '#ff4d6d' : 'var(--color-border-soft)' }}
          >
            <div
              className="absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-300"
              style={{ transform: isDark ? 'translateX(24px)' : 'translateX(2px)' }}
            />
          </button>
        </div>

        {/* Info */}
        <p className="text-xs text-center" style={{ color: 'var(--color-text-tertiary)' }}>
          Theme preference is saved locally on this device
        </p>
      </div>
    </div>
  )
}
