import React from 'react'
import type { TabType } from '../App'
import type { BadgeCounts } from '../notifications/useNotificationStore'
import { useTheme } from '../theme/ThemeContext'

interface Props {
  activeTab: TabType
  setActiveTab: (tab: TabType) => void
  badges: BadgeCounts
}

function Badge({ count }: { count: number }) {
  const { isDark } = useTheme()
  if (count <= 0) return null
  return (
    <span
      className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 flex items-center justify-center text-white text-[9px] font-bold rounded-full leading-none badge-pop"
      style={{
        background: 'linear-gradient(135deg,#ff4d6d,#e11d48)',
        boxShadow: `0 0 0 2px ${isDark ? '#0f0f14' : '#ffffff'}`,
      }}
    >
      {count > 99 ? '99+' : count}
    </span>
  )
}

export default function BottomNav({ activeTab, setActiveTab, badges }: Props) {
  const { isDark } = useTheme()
  const iconInactive = isDark ? '#6b6a80' : '#9ca3af'
  const tabs: {
    id: TabType
    label: string
    badgeKey: keyof BadgeCounts
    icon: (active: boolean, badge: number) => React.ReactElement
  }[] = [
    {
      id: 'discover',
      label: 'Discover',
      badgeKey: 'discover',
      icon: (active, badge) => (
        <div className="relative">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke={active ? '#ff4d6d' : iconInactive} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="12" cy="12" r="10"/>
            <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>
          </svg>
          <Badge count={badge} />
        </div>
      ),
    },
    {
      id: 'feed',
      label: 'Feed',
      badgeKey: 'feed',
      icon: (active, badge) => (
        <div className="relative">
          <svg width="26" height="26" viewBox="0 0 24 24" fill={active ? '#ff4d6d' : 'none'} stroke={active ? '#ff4d6d' : iconInactive} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
          </svg>
          <Badge count={badge} />
        </div>
      ),
    },
    {
      id: 'likes',
      label: 'Likes',
      badgeKey: 'likes',
      icon: (active, badge) => (
        <div className="relative">
          <svg width="26" height="26" viewBox="0 0 24 24" fill={active ? '#ff4d6d' : 'none'} stroke={active ? '#ff4d6d' : iconInactive} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
          <Badge count={badge} />
        </div>
      ),
    },
    {
      id: 'matches',
      label: 'Matches',
      badgeKey: 'matches',
      icon: (active, badge) => (
        <div className="relative">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke={active ? '#ff4d6d' : iconInactive} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          <Badge count={badge} />
        </div>
      ),
    },
    {
      id: 'profile',
      label: 'Profile',
      badgeKey: 'profile',
      icon: (active, badge) => (
        <div className="relative">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke={active ? '#ff4d6d' : iconInactive} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
            <circle cx="12" cy="7" r="4"/>
          </svg>
          <Badge count={badge} />
        </div>
      ),
    },
  ]

  return (
    <div
      className="flex-shrink-0 safe-bottom transition-colors duration-300 dk-nav"
      style={{ borderTop: '1px solid var(--color-nav-border)' }}
    >
      <div className="flex items-center justify-around px-1 pt-2 pb-1">
        {tabs.map(tab => {
          const active = activeTab === tab.id
          const badge = badges[tab.badgeKey] as number
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex flex-col items-center gap-0.5 flex-1 py-1 active:scale-90 transition-transform"
            >
              {tab.icon(active, badge)}
              <span
                className="text-[10px] font-semibold"
                style={{ color: active ? '#ff4d6d' : iconInactive }}
              >
                {tab.label}
              </span>
            </button>
          )
        })}
      </div>
      <div className="flex justify-center pb-1">
        <div className="w-32 h-1 rounded-full" style={{ background: 'var(--color-border)' }} />
      </div>
    </div>
  )
}
