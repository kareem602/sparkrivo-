import { useState } from 'react'
import type { AppNotification, NotifType } from '../data/mockData'
import { SoundSettingsModal } from '../notifications/SoundSettingsModal'
import type { SoundSettings } from '../notifications/useNotificationStore'

interface Props {
  notifications: AppNotification[]
  onClose: () => void
  onMarkAllRead: () => void
  onMarkRead: (id: string) => void
  onDismiss: (id: string) => void
  soundSettings: SoundSettings
  pushPermission: string
  onUpdateSound: (patch: Partial<SoundSettings>) => void
  onRequestPush: () => Promise<boolean>
  unreadCount: number
}

const NOTIF_ICON: Record<NotifType, string> = {
  match: '💕', like: '❤️', message: '💬',
  comment: '🗨️', superlike: '⭐', system: '🔔',
}
const NOTIF_BG: Record<NotifType, string> = {
  match: 'bg-rose-100', like: 'bg-pink-100', message: 'bg-violet-100',
  comment: 'bg-blue-100', superlike: 'bg-amber-100', system: 'bg-gray-100',
}

const TABS = ['All', 'Matches', 'Likes', 'Messages'] as const
type Tab = typeof TABS[number]

function filterByTab(notifs: AppNotification[], tab: Tab) {
  if (tab === 'All') return notifs
  if (tab === 'Matches') return notifs.filter(n => n.type === 'match')
  if (tab === 'Likes') return notifs.filter(n => n.type === 'like' || n.type === 'superlike')
  if (tab === 'Messages') return notifs.filter(n => n.type === 'message' || n.type === 'comment')
  return notifs
}

export default function NotificationsPanel({
  notifications, onClose, onMarkAllRead, onMarkRead, onDismiss,
  soundSettings, pushPermission, onUpdateSound, onRequestPush, unreadCount,
}: Props) {
  const [tab, setTab] = useState<Tab>('All')
  const [showSettings, setShowSettings] = useState(false)

  const visible = filterByTab(notifications, tab)

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-white animate-slide-up">
      {/* ── Header ── */}
      <div className="flex-shrink-0 bg-white border-b border-gray-100 px-4 pt-4 pb-0">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <button onClick={onClose} className="p-1.5 -ml-1.5 rounded-full hover:bg-gray-100 active:scale-90 transition-transform">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6"/>
              </svg>
            </button>
            <h2 className="text-xl font-bold text-gray-900">Notifications</h2>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 text-[11px] font-bold text-white rounded-full" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
                {unreadCount}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <button onClick={onMarkAllRead} className="text-xs font-semibold text-[#ff4d6d] px-3 py-1.5 rounded-full bg-rose-50 active:scale-95 transition-transform">
                Mark all read
              </button>
            )}
            {/* Settings gear */}
            <button
              onClick={() => setShowSettings(true)}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500 active:scale-90 transition-transform"
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="3"/>
                <path d="M19.07 4.93A10 10 0 0 0 4.93 19.07m14.14 0A10 10 0 0 0 4.93 4.93"/>
                <path d="M12 2v2m0 16v2M2 12h2m16 0h2"/>
              </svg>
            </button>
          </div>
        </div>

        {/* Filter tabs */}
        <div className="flex gap-0 overflow-x-auto scrollbar-none">
          {TABS.map(t => {
            const count = t === 'All' ? unreadCount
              : t === 'Matches' ? notifications.filter(n => !n.isRead && n.type === 'match').length
              : t === 'Likes' ? notifications.filter(n => !n.isRead && (n.type === 'like' || n.type === 'superlike')).length
              : notifications.filter(n => !n.isRead && (n.type === 'message' || n.type === 'comment')).length
            return (
              <button key={t} onClick={() => setTab(t)}
                className={`flex-shrink-0 flex items-center gap-1.5 px-4 py-2.5 text-sm font-semibold border-b-2 transition-colors ${
                  tab === t ? 'text-[#ff4d6d] border-[#ff4d6d]' : 'text-gray-500 border-transparent hover:text-gray-700'
                }`}
              >
                {t}
                {count > 0 && (
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${tab === t ? 'bg-[#ff4d6d] text-white' : 'bg-gray-200 text-gray-600'}`}>
                    {count}
                  </span>
                )}
              </button>
            )
          })}
        </div>
      </div>

      {/* ── List ── */}
      <div className="flex-1 overflow-y-auto">
        {visible.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-8">
            <div className="w-20 h-20 rounded-full bg-rose-50 flex items-center justify-center mb-4 text-4xl">🔔</div>
            <h3 className="font-bold text-gray-800 mb-1">No notifications here</h3>
            <p className="text-sm text-gray-400">You're all caught up in this category!</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {visible.map(n => (
              <NotifRow key={n.id} notif={n} onRead={onMarkRead} onDismiss={onDismiss} />
            ))}
          </div>
        )}
      </div>

      {/* Sound settings modal on top */}
      {showSettings && (
        <SoundSettingsModal
          settings={soundSettings}
          pushPermission={pushPermission}
          onUpdate={onUpdateSound}
          onRequestPush={onRequestPush}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  )
}

function NotifRow({ notif, onRead, onDismiss }: { notif: AppNotification; onRead: (id: string) => void; onDismiss: (id: string) => void }) {
  const [gone, setGone] = useState(false)

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation()
    setGone(true)
    setTimeout(() => onDismiss(notif.id), 280)
  }

  return (
    <div
      onClick={() => !notif.isRead && onRead(notif.id)}
      className={`relative flex items-start gap-3 px-4 py-3.5 transition-all duration-280 cursor-pointer active:bg-gray-50 ${
        !notif.isRead ? 'bg-rose-50/50' : 'bg-white'
      } ${gone ? 'opacity-0 translate-x-8' : 'opacity-100 translate-x-0'}`}
    >
      {/* Unread pulse dot */}
      {!notif.isRead && (
        <div className="absolute left-2.5 top-1/2 -translate-y-1/2">
          <div className="w-2 h-2 rounded-full bg-[#ff4d6d] animate-badge-pop" />
        </div>
      )}

      {/* Avatar */}
      <div className="relative flex-shrink-0 ml-2">
        {notif.type === 'system' ? (
          <div className="w-11 h-11 rounded-full flex items-center justify-center text-xl" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
            🔔
          </div>
        ) : (
          <>
            <img src={notif.avatar} alt={notif.name} className="w-11 h-11 rounded-full object-cover" />
            <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full ${NOTIF_BG[notif.type]} flex items-center justify-center text-[11px] border-2 border-white`}>
              {NOTIF_ICON[notif.type]}
            </div>
          </>
        )}
      </div>

      {/* Text */}
      <div className="flex-1 min-w-0">
        <p className={`text-sm leading-snug ${!notif.isRead ? 'font-semibold text-gray-900' : 'text-gray-600'}`}>{notif.text}</p>
        <p className="text-[11px] text-gray-400 mt-0.5">{notif.timeAgo}</p>
      </div>

      {/* Right-side extras */}
      <div className="flex-shrink-0 flex flex-col items-end gap-1.5">
        {notif.postImage && (
          <img src={notif.postImage} alt="" className="w-12 h-12 rounded-xl object-cover" />
        )}
        {notif.type === 'match' && (
          <span className="text-[11px] font-bold text-white px-2.5 py-1 rounded-full" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
            Say hi 👋
          </span>
        )}
        <button onClick={handleDismiss} className="text-gray-300 hover:text-gray-500 p-1 transition-colors">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
    </div>
  )
}
