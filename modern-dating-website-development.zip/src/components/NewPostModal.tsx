import { useState, useRef, useCallback } from 'react'
import { currentUser } from '../data/mockData'
import { processFile, getAcceptString, validateFile } from '../lib/mediaUpload'
import type { Post } from '../data/mockData'

interface Props {
  onPublish: (post: Post) => void
  onClose: () => void
}

type MediaItem = {
  localUrl: string
  remoteUrl: string
  mimeType: string
  type: 'image' | 'video'
}

export default function NewPostModal({ onPublish, onClose }: Props) {
  const [caption, setCaption] = useState('')
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([])
  const [uploadProgress, setUploadProgress] = useState<number>(0)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [dragOver, setDragOver] = useState(false)
  const [activeMedia, setActiveMedia] = useState(0)

  const fileInputRef = useRef<HTMLInputElement>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const handleFiles = useCallback(async (files: FileList | null) => {
    if (!files || files.length === 0) return
    setError(null)

    const newItems: MediaItem[] = []

    for (const file of Array.from(files).slice(0, 5 - mediaItems.length)) {
      const isVideo = file.type.startsWith('video/')
      const mediaType = isVideo ? 'video' : 'image'
      const validationError = validateFile(file, mediaType)
      if (validationError) { setError(validationError); continue }

      setUploading(true)
      try {
        const result = await processFile(file, mediaType, (pct) => setUploadProgress(pct))
        newItems.push({
          localUrl: result.localUrl,
          remoteUrl: result.remoteUrl,
          mimeType: file.type,
          type: mediaType,
        })
      } catch {
        setError('Upload failed. Please try again.')
      }
      setUploading(false)
      setUploadProgress(0)
    }

    if (newItems.length > 0) {
      setMediaItems(prev => [...prev, ...newItems])
      setActiveMedia(mediaItems.length + newItems.length - 1)
    }
  }, [mediaItems.length])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    handleFiles(e.dataTransfer.files)
  }, [handleFiles])

  const removeMedia = (idx: number) => {
    setMediaItems(prev => {
      const next = prev.filter((_, i) => i !== idx)
      return next
    })
    setActiveMedia(prev => Math.max(0, prev - 1))
  }

  const handlePublish = () => {
    if (!caption.trim() && mediaItems.length === 0) return
    const firstMedia = mediaItems[0]
    const isVideo = firstMedia?.type === 'video'
    const post: Post = {
      id: Date.now().toString(),
      userId: 'me',
      userName: 'You',
      userAvatar: currentUser.avatar,
      timeAgo: 'just now',
      caption: caption.trim(),
      // Set the right field based on media type
      image: !isVideo ? firstMedia?.remoteUrl : undefined,
      video: isVideo  ? firstMedia?.remoteUrl : undefined,
      mediaType: firstMedia ? firstMedia.type : undefined,
      likes: 0,
      comments: 0,
      liked: false,
      commentList: [],
    }
    onPublish(post)
    onClose()
  }

  const canPost = (caption.trim().length > 0 || mediaItems.length > 0) && !uploading

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-white animate-slide-up">
      {/* ── Header ── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3.5 border-b border-gray-100">
        <button onClick={onClose} className="text-gray-500 w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
        <h2 className="font-bold text-gray-900 text-base">New Post</h2>
        <button
          onClick={handlePublish}
          disabled={!canPost}
          className="px-4 py-2 rounded-full text-sm font-bold text-white disabled:opacity-40 active:scale-95 transition-transform"
          style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
        >
          Share
        </button>
      </div>

      {/* ── Body ── */}
      <div className="flex-1 overflow-y-auto">

        {/* Caption row */}
        <div className="flex items-start gap-3 px-4 py-4 border-b border-gray-50">
          <img src={currentUser.avatar} alt="" className="w-10 h-10 rounded-full object-cover flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-gray-900 text-sm mb-1">You</p>
            <textarea
              ref={textareaRef}
              value={caption}
              onChange={e => setCaption(e.target.value)}
              placeholder="What's on your mind? ✨"
              maxLength={2200}
              rows={3}
              className="w-full bg-transparent text-sm text-gray-700 placeholder-gray-400 outline-none resize-none leading-relaxed"
            />
            {caption.length > 1800 && (
              <p className="text-xs text-gray-400 text-right mt-1">{caption.length}/2200</p>
            )}
          </div>
        </div>

        {/* ── Media grid preview ── */}
        {mediaItems.length > 0 && (
          <div className="px-4 pt-3 pb-2">
            {/* Single media view */}
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-square mb-2">
              {mediaItems[activeMedia]?.type === 'video' ? (
                <video
                  key={mediaItems[activeMedia].localUrl}
                  src={mediaItems[activeMedia].localUrl}
                  className="w-full h-full object-contain"
                  controls
                  playsInline
                />
              ) : (
                <img
                  src={mediaItems[activeMedia]?.localUrl}
                  alt=""
                  className="w-full h-full object-cover"
                />
              )}
              {/* Remove button */}
              <button
                onClick={() => removeMedia(activeMedia)}
                className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/60 flex items-center justify-center backdrop-blur"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                  <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                </svg>
              </button>
              {/* Counter pill */}
              {mediaItems.length > 1 && (
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
                  {mediaItems.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveMedia(i)}
                      className={`rounded-full transition-all ${i === activeMedia ? 'w-5 h-2 bg-white' : 'w-2 h-2 bg-white/50'}`}
                    />
                  ))}
                </div>
              )}
            </div>
            {/* Thumbnail strip */}
            {mediaItems.length > 1 && (
              <div className="flex gap-2 overflow-x-auto scrollbar-none pb-1">
                {mediaItems.map((m, i) => (
                  <button
                    key={m.localUrl}
                    onClick={() => setActiveMedia(i)}
                    className={`relative flex-shrink-0 w-16 h-16 rounded-xl overflow-hidden border-2 transition-all ${i === activeMedia ? 'border-[#ff4d6d]' : 'border-transparent'}`}
                  >
                    {m.type === 'video' ? (
                      <div className="w-full h-full bg-gray-900 flex items-center justify-center">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
                          <polygon points="5 3 19 12 5 21 5 3"/>
                        </svg>
                      </div>
                    ) : (
                      <img src={m.localUrl} alt="" className="w-full h-full object-cover" />
                    )}
                    <button
                      onClick={e => { e.stopPropagation(); removeMedia(i) }}
                      className="absolute top-0.5 right-0.5 w-4 h-4 bg-black/60 rounded-full flex items-center justify-center"
                    >
                      <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                      </svg>
                    </button>
                  </button>
                ))}
                {/* Add more */}
                {mediaItems.length < 5 && (
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="flex-shrink-0 w-16 h-16 rounded-xl border-2 border-dashed border-gray-300 flex items-center justify-center text-gray-400"
                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                      <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                    </svg>
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* ── Upload progress ── */}
        {uploading && (
          <div className="mx-4 mt-3 px-4 py-3 bg-rose-50 rounded-2xl flex items-center gap-3">
            <div className="w-8 h-8 rounded-full border-[3px] border-[#ff4d6d]/30 border-t-[#ff4d6d] animate-spin flex-shrink-0" />
            <div className="flex-1">
              <p className="text-sm font-semibold text-gray-800">Uploading…</p>
              <div className="mt-1.5 h-1.5 bg-rose-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-[#ff4d6d] rounded-full transition-all duration-150"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
            <span className="text-sm font-bold text-[#ff4d6d]">{uploadProgress}%</span>
          </div>
        )}

        {/* ── Error ── */}
        {error && (
          <div className="mx-4 mt-3 px-4 py-3 bg-red-50 rounded-2xl flex items-center gap-2">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round">
              <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <p className="text-sm text-red-600">{error}</p>
            <button onClick={() => setError(null)} className="ml-auto text-red-400">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        )}

        {/* ── Drop zone / media picker ── */}
        {mediaItems.length === 0 && !uploading && (
          <div
            onDrop={handleDrop}
            onDragOver={e => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onClick={() => fileInputRef.current?.click()}
            className={`mx-4 mt-4 border-2 border-dashed rounded-3xl p-8 flex flex-col items-center justify-center gap-4 cursor-pointer transition-all ${
              dragOver ? 'border-[#ff4d6d] bg-rose-50' : 'border-gray-200 hover:border-[#ff4d6d] hover:bg-rose-50/40'
            }`}
          >
            <div className="w-16 h-16 rounded-2xl bg-rose-50 flex items-center justify-center">
              <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#ff4d6d" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
              </svg>
            </div>
            <div className="text-center">
              <p className="font-bold text-gray-800 text-sm">Tap to add photo or video</p>
              <p className="text-gray-400 text-xs mt-1">Up to 5 files · JPG, PNG, MP4, MOV</p>
            </div>
            <p className="text-xs text-gray-300">or drag & drop here</p>
          </div>
        )}

        {/* ── Quick media action buttons ── */}
        <div className="px-4 pt-4 pb-6 grid grid-cols-3 gap-3">
          <MediaActionBtn
            icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>}
            label="Camera"
            color="bg-rose-50 text-[#ff4d6d]"
            onClick={() => { fileInputRef.current!.setAttribute('capture', 'environment'); fileInputRef.current?.click() }}
          />
          <MediaActionBtn
            icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>}
            label="Gallery"
            color="bg-violet-50 text-violet-500"
            onClick={() => { fileInputRef.current!.removeAttribute('capture'); fileInputRef.current?.click() }}
          />
          <MediaActionBtn
            icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>}
            label="Video"
            color="bg-amber-50 text-amber-500"
            onClick={() => {
              fileInputRef.current!.setAttribute('accept', 'video/*')
              fileInputRef.current!.removeAttribute('capture')
              fileInputRef.current?.click()
            }}
          />
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={getAcceptString(['image', 'video'])}
        className="hidden"
        onChange={e => handleFiles(e.target.files)}
      />
    </div>
  )
}

function MediaActionBtn({ icon, label, color, onClick }: { icon: React.ReactNode; label: string; color: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-2 py-4 rounded-2xl ${color} active:scale-95 transition-transform`}
    >
      {icon}
      <span className="text-xs font-semibold">{label}</span>
    </button>
  )
}
