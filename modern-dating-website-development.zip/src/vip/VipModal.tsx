import { useState } from 'react'
import { VIP_PLANS, PAYMENT_METHODS, VIP_FEATURES, type VipPlan, type PaymentProvider } from './vipStore'
import { useVip } from './VipContext'
import { VipBadge } from './VipBadge'
import { TEST_CARDS, processPayment, type PaymentMode } from './paymentSandbox'

interface Props {
  onClose: () => void
  defaultPlan?: VipPlan['id']
}

type Step = 'plans' | 'payment' | 'processing' | 'success' | 'error'

export default function VipModal({ onClose, defaultPlan = 'quarterly' }: Props) {
  const { purchase, isVip, subscription } = useVip()

  const [step, setStep] = useState<Step>(isVip ? 'success' : 'plans')
  const [selectedPlan, setSelectedPlan] = useState<VipPlan>(VIP_PLANS.find(p => p.id === defaultPlan) ?? VIP_PLANS[1])
  const [selectedProvider, setSelectedProvider] = useState<PaymentProvider>('paystack')
  const [paymentMode, setPaymentMode] = useState<PaymentMode>('sandbox')
  const [autoRenew, setAutoRenew] = useState(true)

  // Card form
  const [cardNum, setCardNum] = useState('')
  const [expiry, setExpiry] = useState('')
  const [cvv, setCvv] = useState('')
  const [cardName, setCardName] = useState('')
  const [email, setEmail] = useState('')
  const [showTestCards, setShowTestCards] = useState(true)

  const [errorMsg, setErrorMsg] = useState('')
  const [txId, setTxId] = useState('')
  const [gatewayMsg, setGatewayMsg] = useState('')

  const fmt = (n: number, cur: 'USD' | 'NGN' = 'USD') =>
    cur === 'NGN' ? `₦${n.toLocaleString()}` : `$${n.toFixed(2)}`

  const handlePay = async () => {
    setStep('processing')
    // Use sandbox processor first
    const sandboxResult = await processPayment({
      provider: selectedProvider,
      mode: paymentMode,
      cardNumber: cardNum || (selectedProvider === 'paypal' ? email : undefined),
      amount: paymentMode === 'sandbox' ? selectedPlan.priceNGN : selectedPlan.price,
      currency: paymentMode === 'sandbox' && (selectedProvider === 'paystack' || selectedProvider === 'flutterwave') ? 'NGN' : 'USD',
      email,
    })

    if (sandboxResult.success) {
      // Also update VIP store
      await purchase(selectedPlan, selectedProvider, autoRenew)
      setTxId(sandboxResult.transactionId)
      setGatewayMsg(sandboxResult.gatewayResponse || 'Approved')
      setStep('success')
    } else {
      setErrorMsg(sandboxResult.error ?? 'Payment failed.')
      setGatewayMsg(sandboxResult.gatewayResponse || '')
      setStep('error')
    }
  }

  const fillTestCard = (card: typeof TEST_CARDS['stripe'][0]) => {
    if (selectedProvider === 'paypal') {
      setEmail(card.number)
    } else {
      setCardNum(card.number)
      setExpiry(card.expiry)
      setCvv(card.cvv)
      setCardName('Test User')
    }
  }

  const formatCardNum = (v: string) => v.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim()
  const formatExpiry = (v: string) => { const d = v.replace(/\D/g, '').slice(0, 4); return d.length >= 3 ? `${d.slice(0, 2)}/${d.slice(2)}` : d }

  const testCards = TEST_CARDS[selectedProvider] || []

  return (
    <div className="absolute inset-0 z-[200] flex flex-col bg-white overflow-hidden animate-slide-up">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 pt-5 pb-4" style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}>
        <button onClick={onClose} className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center active:scale-90 transition-transform">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
        <div className="flex-1 text-center">
          <h2 className="text-white font-black text-lg">👑 SparkMatch VIP</h2>
          <p className="text-white/80 text-xs">Unlock everything — no limits</p>
        </div>
        <div className="w-9" />
      </div>

      <div className="flex-1 overflow-y-auto">

        {/* ══ PLANS ══ */}
        {step === 'plans' && (
          <div className="px-4 py-5 space-y-5">
            {/* Feature grid — calls highlighted at top */}
            <div className="grid grid-cols-2 gap-2">
              {/* Highlighted NEW features */}
              {[
                { icon: '📞', label: 'Private voice calls', isNew: true },
                { icon: '🎥', label: 'HD video calls', isNew: true },
                { icon: '🖼️', label: 'Custom chat wallpapers', isNew: true },
              ].map(f => (
                <div key={f.label} className="flex items-center gap-2 rounded-2xl px-3 py-2.5 bg-gradient-to-r from-amber-100 to-yellow-50 border border-amber-200">
                  <span className="text-lg">{f.icon}</span>
                  <span className="text-xs font-semibold text-amber-800 leading-tight flex-1">{f.label}</span>
                  <span className="text-[9px] font-black text-amber-600 bg-amber-200 px-1 py-0.5 rounded-full">NEW</span>
                </div>
              ))}
              {/* Other features */}
              {VIP_FEATURES.filter(f => f.icon !== '📞' && f.icon !== '🎥' && f.icon !== '🖼️').slice(0, 3).map(f => (
                <div key={f.label} className="flex items-center gap-2 bg-amber-50 rounded-2xl px-3 py-2.5">
                  <span className="text-lg">{f.icon}</span>
                  <span className="text-xs font-semibold text-amber-900 leading-tight">{f.label}</span>
                </div>
              ))}
            </div>

            {/* Plans */}
            <div className="space-y-3">
              <p className="text-sm font-bold text-gray-800">Choose your plan</p>
              {VIP_PLANS.map(plan => {
                const sel = selectedPlan.id === plan.id
                return (
                  <button key={plan.id} onClick={() => setSelectedPlan(plan)}
                    className={`relative w-full flex items-center gap-4 px-4 py-4 rounded-2xl border-2 transition-all active:scale-[0.98] ${sel ? 'border-amber-400 bg-amber-50 shadow-md shadow-amber-100' : 'border-gray-200 bg-white hover:border-amber-300'}`}
                  >
                    {plan.badge && (
                      <div className="absolute -top-3 left-4">
                        <span className="px-2.5 py-0.5 text-[10px] font-black rounded-full text-white" style={{ background: plan.id === 'yearly' ? 'linear-gradient(135deg,#f59e0b,#fbbf24)' : 'linear-gradient(135deg,#8b5cf6,#6d28d9)' }}>{plan.badge}</span>
                      </div>
                    )}
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${sel ? 'border-amber-500 bg-amber-500' : 'border-gray-300'}`}>
                      {sel && <div className="w-2 h-2 bg-white rounded-full" />}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-bold text-gray-900 text-sm">{plan.label}</p>
                      <p className="text-xs text-gray-400">{fmt(plan.perMonth)}/mo effective{plan.savingPct ? <span className="text-emerald-500 font-semibold ml-1">· Save {plan.savingPct}%</span> : ''}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-black text-gray-900 text-base">{fmt(plan.price)}</p>
                      <p className="text-xs text-gray-400">{fmt(plan.priceNGN, 'NGN')}</p>
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Comparison table */}
            <div className="border border-gray-100 rounded-2xl overflow-hidden">
              <div className="grid grid-cols-3 bg-gray-50 px-3 py-2 text-[10px] font-bold text-gray-500 uppercase tracking-wide">
                <span>Feature</span><span className="text-center">Free</span><span className="text-center text-amber-500">VIP</span>
              </div>
              {[['Messages','Unlimited ✅','Unlimited ✅'],['Likes who liked you','❌','✅'],['Swipes/day','30','∞'],['Custom username','❌','✅'],['Voice calls','❌','✅'],['Video calls','❌','✅'],['Chat wallpapers','❌','✅'],['Profile boost','❌','3×'],['Read receipts','❌','✅']].map(([f,free,vip]) => (
                <div key={f} className="grid grid-cols-3 px-3 py-2.5 border-t border-gray-50 text-xs">
                  <span className="text-gray-700 font-medium">{f}</span>
                  <span className="text-center text-gray-400">{free}</span>
                  <span className="text-center text-amber-500 font-bold">{vip}</span>
                </div>
              ))}
            </div>

            {/* Auto-renew */}
            <div className="flex items-center justify-between px-4 py-3 bg-gray-50 rounded-2xl">
              <div>
                <p className="font-semibold text-gray-800 text-sm">Auto-renew</p>
                <p className="text-xs text-gray-400">Cancel anytime from your profile</p>
              </div>
              <button onClick={() => setAutoRenew(v => !v)} className={`relative w-12 h-6 rounded-full transition-colors ${autoRenew ? 'bg-amber-400' : 'bg-gray-300'}`}>
                <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${autoRenew ? 'translate-x-6' : 'translate-x-0.5'}`} />
              </button>
            </div>

            <button onClick={() => setStep('payment')} className="w-full py-4 rounded-2xl text-white font-black text-base active:scale-[0.98] transition-transform shadow-xl shadow-amber-200" style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}>
              Continue — {fmt(selectedPlan.price)} ✨
            </button>
            <p className="text-center text-xs text-gray-400">Secure payment · Cancel anytime · No hidden fees</p>
          </div>
        )}

        {/* ══ PAYMENT ══ */}
        {step === 'payment' && (
          <div className="px-4 py-5 space-y-5">
            {/* Order summary */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3 flex items-center gap-3">
              <span className="text-2xl">👑</span>
              <div className="flex-1">
                <p className="font-bold text-amber-900 text-sm">VIP {selectedPlan.label}</p>
                <p className="text-xs text-amber-700">{selectedPlan.duration} days · {autoRenew ? 'Auto-renews' : 'One-time'}</p>
              </div>
              <div className="text-right">
                <p className="font-black text-amber-900">{fmt(selectedPlan.price)}</p>
                <p className="text-xs text-amber-700">{fmt(selectedPlan.priceNGN, 'NGN')}</p>
              </div>
            </div>

            {/* ── SANDBOX / LIVE MODE TOGGLE ── */}
            <div className={`rounded-2xl p-3 border-2 ${paymentMode === 'sandbox' ? 'bg-violet-50 border-violet-200' : 'bg-green-50 border-green-200'}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{paymentMode === 'sandbox' ? '🧪' : '🔴'}</span>
                  <div>
                    <p className={`font-bold text-sm ${paymentMode === 'sandbox' ? 'text-violet-800' : 'text-green-800'}`}>
                      {paymentMode === 'sandbox' ? 'Test / Sandbox Mode' : 'Live Mode'}
                    </p>
                    <p className={`text-xs ${paymentMode === 'sandbox' ? 'text-violet-600' : 'text-green-600'}`}>
                      {paymentMode === 'sandbox' ? 'No real money charged — use test cards below' : 'Real payment will be processed'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setPaymentMode(m => m === 'sandbox' ? 'live' : 'sandbox')}
                  className={`relative w-12 h-6 rounded-full transition-colors ${paymentMode === 'live' ? 'bg-green-500' : 'bg-violet-400'}`}
                >
                  <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${paymentMode === 'live' ? 'translate-x-6' : 'translate-x-0.5'}`} />
                </button>
              </div>
              {paymentMode === 'live' && (
                <div className="flex items-center gap-2 bg-orange-50 border border-orange-200 rounded-xl px-3 py-2">
                  <span className="text-base">⚠️</span>
                  <p className="text-xs text-orange-700 font-semibold">Live mode: your real card will be charged!</p>
                </div>
              )}
            </div>

            {/* Provider picker */}
            <div>
              <p className="text-sm font-bold text-gray-800 mb-3">Payment method</p>
              <div className="grid grid-cols-2 gap-2">
                {PAYMENT_METHODS.map(pm => {
                  const sel = selectedProvider === pm.id
                  return (
                    <button key={pm.id} onClick={() => setSelectedProvider(pm.id)}
                      className={`relative flex items-center gap-2.5 px-3.5 py-3 rounded-2xl border-2 transition-all active:scale-95 ${sel ? 'border-[#ff4d6d] bg-rose-50' : 'border-gray-200 bg-white hover:border-gray-300'}`}
                    >
                      {pm.recommended && <span className="absolute -top-2 -right-1 text-[9px] font-black px-1.5 py-0.5 bg-emerald-500 text-white rounded-full">Recommended</span>}
                      <span className="text-xl">{pm.icon}</span>
                      <span className={`font-bold text-sm ${sel ? 'text-[#ff4d6d]' : 'text-gray-700'}`}>{pm.label}</span>
                      {sel && <svg className="ml-auto" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff4d6d" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* ── TEST CARDS (sandbox only) ── */}
            {paymentMode === 'sandbox' && testCards.length > 0 && (
              <div className="bg-violet-50 border border-violet-200 rounded-2xl overflow-hidden">
                <button
                  onClick={() => setShowTestCards(v => !v)}
                  className="w-full flex items-center justify-between px-4 py-3"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">🧪</span>
                    <p className="font-bold text-violet-800 text-sm">Test Cards for {selectedProvider}</p>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#7c3aed" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
                    style={{ transform: showTestCards ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform 0.2s' }}>
                    <polyline points="6 9 12 15 18 9"/>
                  </svg>
                </button>
                {showTestCards && (
                  <div className="border-t border-violet-200 divide-y divide-violet-100">
                    {testCards.map((card, i) => (
                      <button
                        key={i}
                        onClick={() => fillTestCard(card)}
                        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-violet-100 active:scale-[0.98] transition-all text-left"
                      >
                        <span className="text-lg flex-shrink-0">{card.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-violet-900 text-xs">{card.label}</p>
                          <p className="text-violet-600 text-[11px] font-mono truncate">{card.number}</p>
                          {card.expiry && <p className="text-violet-400 text-[10px]">Exp: {card.expiry} · CVV: {card.cvv}{card.pin ? ` · PIN: ${card.pin}` : ''}</p>}
                        </div>
                        <span className="text-[10px] font-bold text-violet-600 bg-violet-100 px-2 py-1 rounded-full flex-shrink-0">Autofill</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Card form */}
            {['stripe', 'paystack', 'flutterwave'].includes(selectedProvider) && (
              <div className="space-y-3">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">Card Details</p>
                <input value={cardName} onChange={e => setCardName(e.target.value)} placeholder="Cardholder name"
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors" />
                <div className="relative">
                  <input value={cardNum} onChange={e => setCardNum(formatCardNum(e.target.value))} placeholder="1234 5678 9012 3456" inputMode="numeric"
                    className="w-full px-4 py-3.5 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors pr-14" />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 flex">
                    <div className="w-6 h-4 bg-red-500 rounded-sm opacity-70" />
                    <div className="w-6 h-4 bg-amber-500 rounded-sm opacity-70 -ml-2" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input value={expiry} onChange={e => setExpiry(formatExpiry(e.target.value))} placeholder="MM/YY" inputMode="numeric" maxLength={5}
                    className="w-full px-4 py-3.5 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors" />
                  <input value={cvv} onChange={e => setCvv(e.target.value.replace(/\D/g, '').slice(0, 4))} placeholder="CVV" inputMode="numeric" type="password"
                    className="w-full px-4 py-3.5 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors" />
                </div>
              </div>
            )}

            {selectedProvider === 'paypal' && (
              <div className="space-y-3">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wide">PayPal Account</p>
                <input value={email} onChange={e => setEmail(e.target.value)} placeholder={paymentMode === 'sandbox' ? 'test-success@example.com' : 'your@paypal.com'} type="email"
                  className="w-full px-4 py-3.5 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors" />
              </div>
            )}

            {/* Security badges */}
            <div className="flex items-center justify-center gap-4 py-1">
              {['🔒 SSL', '🛡️ PCI-DSS', '✅ 256-bit'].map(b => (
                <span key={b} className="text-[10px] text-gray-400 font-medium">{b}</span>
              ))}
            </div>

            {/* Pay button */}
            <button onClick={handlePay} className="w-full py-4 rounded-2xl text-white font-black text-base active:scale-[0.98] transition-transform shadow-xl shadow-amber-200" style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}>
              {paymentMode === 'sandbox' ? '🧪 Test Payment' : `Pay ${fmt(selectedPlan.price)}`} · Go VIP 👑
            </button>

            <button onClick={() => setStep('plans')} className="w-full py-2 text-gray-400 text-sm font-medium">← Back to plans</button>
          </div>
        )}

        {/* ══ PROCESSING ══ */}
        {step === 'processing' && (
          <div className="flex flex-col items-center justify-center h-full py-20 text-center px-8">
            <div className="relative mb-8">
              <div className="w-24 h-24 rounded-full border-4 border-amber-200 border-t-amber-500 animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center text-4xl">👑</div>
            </div>
            <h3 className="font-black text-gray-900 text-xl mb-2">
              {paymentMode === 'sandbox' ? 'Processing Test Payment…' : 'Processing Payment…'}
            </h3>
            <p className="text-gray-500 text-sm">Connecting to {PAYMENT_METHODS.find(p => p.id === selectedProvider)?.label}…</p>
            {paymentMode === 'sandbox' && <p className="text-violet-500 text-xs mt-2 font-semibold">🧪 Sandbox mode — no real charge</p>}
          </div>
        )}

        {/* ══ SUCCESS ══ */}
        {step === 'success' && (
          <div className="flex flex-col items-center justify-center py-10 text-center px-6">
            <div className="w-28 h-28 rounded-full flex items-center justify-center text-5xl mb-6 shadow-2xl" style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)', boxShadow: '0 0 40px rgba(245,158,11,0.5)' }}>
              👑
            </div>
            <h3 className="font-black text-gray-900 text-2xl mb-1">Welcome to VIP!</h3>
            <p className="text-gray-500 text-sm mb-2">Your account has been upgraded</p>
            {paymentMode === 'sandbox' && (
              <div className="px-3 py-1.5 bg-violet-100 rounded-full mb-3">
                <p className="text-violet-700 text-xs font-bold">🧪 Sandbox test — no real charge was made</p>
              </div>
            )}
            <VipBadge size="lg" animated />
            {subscription && (
              <div className="mt-4 space-y-1.5 text-sm text-gray-500">
                <p>Plan: <span className="font-bold text-gray-800">VIP {subscription.plan.label}</span></p>
                <p>Ref: <span className="font-mono text-xs text-gray-600 break-all">{txId}</span></p>
                {gatewayMsg && <p className="text-xs text-emerald-600 font-semibold">{gatewayMsg}</p>}
              </div>
            )}
            <button onClick={onClose} className="w-full mt-6 py-4 rounded-2xl text-white font-black text-base active:scale-[0.98] transition-transform" style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}>
              Start Exploring ✨
            </button>
          </div>
        )}

        {/* ══ ERROR ══ */}
        {step === 'error' && (
          <div className="flex flex-col items-center justify-center py-16 text-center px-8">
            <div className="w-20 h-20 rounded-full bg-red-100 flex items-center justify-center text-4xl mb-5">❌</div>
            <h3 className="font-black text-gray-900 text-xl mb-2">Payment Failed</h3>
            <p className="text-gray-500 text-sm mb-2">{errorMsg}</p>
            {gatewayMsg && <p className="text-xs text-red-500 font-semibold mb-4">{gatewayMsg}</p>}
            {paymentMode === 'sandbox' && (
              <p className="text-xs text-violet-600 mb-4 font-medium">💡 Try a different test card from the list above</p>
            )}
            <button onClick={() => setStep('payment')} className="w-full py-4 rounded-2xl text-white font-bold active:scale-[0.98] transition-transform" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
              Try Again
            </button>
            <button onClick={onClose} className="mt-3 text-gray-400 text-sm font-medium w-full py-2">Cancel</button>
          </div>
        )}
      </div>
    </div>
  )
}
