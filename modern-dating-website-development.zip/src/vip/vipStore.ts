import { useState, useCallback } from 'react'

// ─── Plans ────────────────────────────────────────────────────────────────
export interface VipPlan {
  id: 'monthly' | 'quarterly' | 'yearly'
  label: string
  price: number          // USD
  priceNGN: number       // Naira equivalent (approx)
  perMonth: number       // effective monthly cost
  duration: number       // days
  badge?: string         // e.g. "Most Popular"
  savingPct?: number
  color: string
}

export const VIP_PLANS: VipPlan[] = [
  {
    id: 'monthly',
    label: '1 Month',
    price: 5,
    priceNGN: 7500,
    perMonth: 5,
    duration: 30,
    color: 'from-rose-400 to-pink-500',
  },
  {
    id: 'quarterly',
    label: '3 Months',
    price: 12,
    priceNGN: 18000,
    perMonth: 4,
    duration: 90,
    badge: 'Most Popular',
    savingPct: 20,
    color: 'from-violet-500 to-purple-600',
  },
  {
    id: 'yearly',
    label: '12 Months',
    price: 45,
    priceNGN: 67500,
    perMonth: 3.75,
    duration: 365,
    badge: 'Best Value',
    savingPct: 25,
    color: 'from-amber-500 to-yellow-400',
  },
]

// ─── Payment providers ────────────────────────────────────────────────────
export type PaymentProvider = 'stripe' | 'paystack' | 'flutterwave' | 'paypal'

export interface PaymentMethod {
  id: PaymentProvider
  label: string
  icon: string
  color: string
  currencies: string[]
  recommended?: boolean
}

export const PAYMENT_METHODS: PaymentMethod[] = [
  {
    id: 'paystack',
    label: 'Paystack',
    icon: '🟢',
    color: '#00c3f7',
    currencies: ['NGN', 'GHS', 'ZAR', 'USD'],
    recommended: true,
  },
  {
    id: 'flutterwave',
    label: 'Flutterwave',
    icon: '🔶',
    color: '#f5a623',
    currencies: ['NGN', 'GHS', 'KES', 'USD'],
  },
  {
    id: 'stripe',
    label: 'Stripe',
    icon: '💳',
    color: '#635bff',
    currencies: ['USD', 'EUR', 'GBP'],
  },
  {
    id: 'paypal',
    label: 'PayPal',
    icon: '🅿️',
    color: '#003087',
    currencies: ['USD', 'EUR', 'GBP'],
  },
]

// ─── Subscription state ───────────────────────────────────────────────────
export interface Subscription {
  plan: VipPlan
  provider: PaymentProvider
  startedAt: number      // ms
  expiresAt: number      // ms
  autoRenew: boolean
  transactionId: string
}

// ─── Boost ────────────────────────────────────────────────────────────────
export interface Boost {
  id: string
  purchasedAt: number
  expiresAt: number      // 30 min boost
  multiplier: number     // 3x
}

// ─── Gift ─────────────────────────────────────────────────────────────────
export interface Gift {
  id: string
  emoji: string
  label: string
  price: number          // USD
  priceNGN: number
}

export const GIFTS: Gift[] = [
  { id: 'rose',      emoji: '🌹', label: 'Rose',      price: 0.99, priceNGN: 1500 },
  { id: 'heart',     emoji: '❤️',  label: 'Heart',     price: 1.99, priceNGN: 3000 },
  { id: 'diamond',   emoji: '💎',  label: 'Diamond',   price: 4.99, priceNGN: 7500 },
  { id: 'crown',     emoji: '👑',  label: 'Crown',     price: 9.99, priceNGN: 15000 },
  { id: 'fire',      emoji: '🔥',  label: 'Fire',      price: 2.99, priceNGN: 4500 },
  { id: 'star',      emoji: '⭐',  label: 'Super Star', price: 3.99, priceNGN: 6000 },
]

// ─── VIP features list ────────────────────────────────────────────────────
export const VIP_FEATURES = [
  { icon: '❤️',  label: 'See who liked you',             free: false },
  { icon: '∞',   label: 'Unlimited swipes & likes',       free: false },
  { icon: '🚀',  label: 'Profile boost (3× visibility)',  free: false },
  { icon: '🔍',  label: 'Advanced search filters',        free: false },
  { icon: '⭐',  label: 'Priority in discovery',          free: false },
  { icon: '🎬',  label: 'Featured in video feed',         free: false },
  { icon: '💬',  label: 'Unlimited messages (everyone)',    free: true  },
  { icon: '📖',  label: 'Read receipts',                  free: false },
  { icon: '📞',  label: 'Private voice calls',            free: false },
  { icon: '🎥',  label: 'HD video calls',                 free: false },
  { icon: '🛡️', label: 'VIP verified badge glow',        free: false },
  { icon: '🎁',  label: 'Send & receive gifts',           free: false },
  { icon: '🖼️', label: 'Custom chat wallpapers',         free: false },
  { icon: '✏️', label: 'Custom username (@handle)',       free: false },
]

// ─── Hook ─────────────────────────────────────────────────────────────────
export function useVipStore() {
  const [subscription, setSubscription] = useState<Subscription | null>(null)
  const [boosts, setBoosts] = useState<Boost[]>([])
  const [showVipModal, setShowVipModal] = useState(false)
  const [giftsSent, setGiftsSent] = useState<{ gift: Gift; toUserId: string; at: number }[]>([])

  const isVip = subscription !== null && subscription.expiresAt > Date.now()

  const daysLeft = subscription
    ? Math.max(0, Math.ceil((subscription.expiresAt - Date.now()) / 86400000))
    : 0

  const activeBoost = boosts.find(b => b.expiresAt > Date.now()) ?? null
  const boostMinutesLeft = activeBoost
    ? Math.ceil((activeBoost.expiresAt - Date.now()) / 60000)
    : 0

  // Simulate payment processing
  const purchase = useCallback(async (
    plan: VipPlan,
    provider: PaymentProvider,
    autoRenew: boolean
  ): Promise<{ success: boolean; transactionId: string; error?: string }> => {
    // Simulate network delay + success
    await new Promise(r => setTimeout(r, 1800))

    // 95% success rate simulation
    if (Math.random() < 0.05) {
      return { success: false, transactionId: '', error: 'Payment declined. Please try another method.' }
    }

    const txId = `TXN-${Date.now()}-${Math.random().toString(36).slice(2).toUpperCase()}`
    const sub: Subscription = {
      plan,
      provider,
      startedAt: Date.now(),
      expiresAt: Date.now() + plan.duration * 86400000,
      autoRenew,
      transactionId: txId,
    }
    setSubscription(sub)
    return { success: true, transactionId: txId }
  }, [])

  const cancelSubscription = useCallback(() => {
    setSubscription(prev => prev ? { ...prev, autoRenew: false } : null)
  }, [])

  const purchaseBoost = useCallback(async (): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 800))
    const boost: Boost = {
      id: `boost-${Date.now()}`,
      purchasedAt: Date.now(),
      expiresAt: Date.now() + 30 * 60000, // 30 min
      multiplier: 3,
    }
    setBoosts(prev => [...prev, boost])
    return true
  }, [])

  const sendGift = useCallback(async (gift: Gift, toUserId: string): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 600))
    setGiftsSent(prev => [...prev, { gift, toUserId, at: Date.now() }])
    return true
  }, [])

  return {
    subscription,
    isVip,
    daysLeft,
    boosts,
    activeBoost,
    boostMinutesLeft,
    giftsSent,
    showVipModal,
    setShowVipModal,
    purchase,
    cancelSubscription,
    purchaseBoost,
    sendGift,
  }
}
