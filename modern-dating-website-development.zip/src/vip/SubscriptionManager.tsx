import { useState } from 'react'
import { useVip } from './VipContext'
import { VipBadge, VipCountdownPill, BoostActivePill } from './VipBadge'
import { PAYMENT_METHODS, GIFTS } from './vipStore'
import type { Gift } from './vipStore'

interface Props {
  onClose: () => void
  onUpgrade: () => void
}

export default function SubscriptionManager({ onClose, onUpgrade }: Props) {
  const { subscription, isVip, daysLeft, activeBoost, boostMinutesLeft, purchaseBoost, sendGift, cancelSubscription } = useVip()
  const [tab, setTab] = useState<'status' | 'boost' | 'gifts'>('status')
  const [boostBuying, setBoostBuying] = useState(false)
  const [boostDone, setBoostDone] = useState(false)
  const [giftSending, setGiftSending] = useState<string | null>(null)
  const [giftDone, setGiftDone] = useState<string | null>(null)
  const [showCancelConfirm, setShowCancelConfirm] = useState(false)

  const handleBoost = async () => {
    setBoostBuying(true)
    const ok = await purchaseBoost()
    setBoostBuying(false)
    if (ok) setBoostDone(true)
  }

  const handleGift = async (gift: Gift) => {
    setGiftSending(gift.id)
    await sendGift(gift, 'demo-user')
    setGiftSending(null)
    setGiftDone(gift.id)
    setTimeout(() => setGiftDone(null), 2000)
  }

  const provider = subscription ? PAYMENT_METHODS.find(p => p.id === subscription.provider) : null

  return (
    <div className="absolute inset-0 z-[200] flex flex-col bg-white animate-slide-up">
      {/* Header */}
      <div
        className="flex-shrink-0 flex items-center gap-3 px-4 pt-5 pb-4"
        style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
      >
        <button onClick={onClose} className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center active:scale-90 transition-transform">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div className="flex-1">
          <h2 className="text-white font-black text-lg">VIP Dashboard</h2>
          <p className="text-white/80 text-xs">Manage your subscription</p>
        </div>
        <VipBadge size="sm" />
      </div>

      {/* Tabs */}
      <div className="flex-shrink-0 flex border-b border-gray-100">
        {([
          { id: 'status', label: '📊 Status' },
          { id: 'boost',  label: '🚀 Boost' },
          { id: 'gifts',  label: '🎁 Gifts' },
        ] as const).map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex-1 py-3 text-sm font-bold border-b-2 transition-colors ${
              tab === t.id ? 'text-amber-600 border-amber-500' : 'text-gray-400 border-transparent'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5">

        {/* ── STATUS TAB ── */}
        {tab === 'status' && (
          <div className="space-y-5">
            {isVip && subscription ? (
              <>
                {/* VIP card */}
                <div
                  className="rounded-3xl p-5 text-white relative overflow-hidden"
                  style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24,#f59e0b)', backgroundSize: '200% auto', animation: 'vip-shimmer 3s linear infinite' }}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-white/10 -translate-y-8 translate-x-8" />
                  <p className="text-white/80 text-xs font-bold uppercase tracking-wide mb-1">Current Plan</p>
                  <h3 className="text-2xl font-black mb-0.5">VIP {subscription.plan.label}</h3>
                  <p className="text-white/80 text-sm">
                    {new Date(subscription.startedAt).toLocaleDateString()} →{' '}
                    {new Date(subscription.expiresAt).toLocaleDateString()}
                  </p>
                  <div className="mt-3">
                    <VipCountdownPill daysLeft={daysLeft} />
                  </div>
                </div>

                {/* Details */}
                <div className="bg-gray-50 rounded-2xl divide-y divide-gray-100">
                  {[
                    ['Plan', `VIP ${subscription.plan.label}`],
                    ['Price', `$${subscription.plan.price} / ${subscription.plan.label.toLowerCase()}`],
                    ['Provider', `${provider?.icon} ${provider?.label}`],
                    ['Auto-renew', subscription.autoRenew ? '✅ Enabled' : '❌ Disabled'],
                    ['Transaction ID', subscription.transactionId],
                  ].map(([label, val]) => (
                    <div key={label} className="flex items-center justify-between px-4 py-3">
                      <span className="text-sm text-gray-500">{label}</span>
                      <span className="text-sm font-semibold text-gray-800 text-right max-w-[160px] truncate">{val}</span>
                    </div>
                  ))}
                </div>

                {/* Actions */}
                <button
                  onClick={onUpgrade}
                  className="w-full py-3.5 rounded-2xl text-white font-bold text-sm active:scale-[0.98] transition-transform"
                  style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
                >
                  Upgrade / Change Plan
                </button>

                {!showCancelConfirm ? (
                  <button
                    onClick={() => setShowCancelConfirm(true)}
                    className="w-full py-3 text-red-400 text-sm font-semibold"
                  >
                    Cancel Auto-Renew
                  </button>
                ) : (
                  <div className="bg-red-50 rounded-2xl p-4 space-y-3">
                    <p className="text-sm text-red-700 font-semibold text-center">Are you sure? You'll lose VIP access after {daysLeft} days.</p>
                    <div className="flex gap-2">
                      <button onClick={() => setShowCancelConfirm(false)} className="flex-1 py-2.5 bg-gray-100 rounded-xl text-gray-700 font-semibold text-sm">Keep VIP</button>
                      <button onClick={() => { cancelSubscription(); setShowCancelConfirm(false) }} className="flex-1 py-2.5 bg-red-500 rounded-xl text-white font-bold text-sm">Cancel</button>
                    </div>
                  </div>
                )}
              </>
            ) : (
              /* Not VIP */
              <div className="text-center py-8 space-y-4">
                <div className="text-6xl">👑</div>
                <h3 className="font-black text-gray-900 text-xl">No active subscription</h3>
                <p className="text-gray-500 text-sm">Upgrade to VIP for unlimited access</p>
                <button
                  onClick={onUpgrade}
                  className="px-8 py-4 rounded-2xl text-white font-black text-base active:scale-[0.98] transition-transform shadow-xl shadow-amber-200"
                  style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
                >
                  Get VIP — From $5/mo
                </button>
              </div>
            )}
          </div>
        )}

        {/* ── BOOST TAB ── */}
        {tab === 'boost' && (
          <div className="space-y-5">
            {/* Current boost */}
            {activeBoost ? (
              <div
                className="rounded-2xl p-4 text-white"
                style={{ background: 'linear-gradient(135deg,#8b5cf6,#6d28d9)' }}
              >
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-3xl">🚀</span>
                  <div>
                    <p className="font-black text-lg">Boost Active!</p>
                    <BoostActivePill minutesLeft={boostMinutesLeft} />
                  </div>
                </div>
                <p className="text-white/80 text-sm">Your profile is being shown {activeBoost.multiplier}× more often to nearby users right now.</p>
              </div>
            ) : (
              <div className="text-center py-4">
                <div className="text-5xl mb-3">🚀</div>
                <h3 className="font-black text-gray-900 text-lg mb-1">No active boost</h3>
                <p className="text-gray-500 text-sm">A boost lasts 30 minutes and shows your profile 3× more</p>
              </div>
            )}

            {/* Boost card */}
            <div className="bg-violet-50 border-2 border-violet-200 rounded-2xl p-4">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-12 h-12 rounded-xl bg-violet-500 flex items-center justify-center text-2xl flex-shrink-0">🚀</div>
                <div>
                  <p className="font-bold text-gray-900 text-sm">Profile Boost</p>
                  <p className="text-xs text-gray-500">3× visibility · 30 minutes · $1.99</p>
                </div>
              </div>
              <ul className="space-y-1.5 mb-4">
                {['Show at top of Discover for 30 min', '3× more profile views guaranteed', 'Supercharge your matches today'].map(f => (
                  <li key={f} className="flex items-center gap-2 text-xs text-gray-600">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8b5cf6" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    {f}
                  </li>
                ))}
              </ul>
              <button
                onClick={handleBoost}
                disabled={boostBuying || !!activeBoost}
                className="w-full py-3 rounded-xl text-white font-bold text-sm disabled:opacity-50 active:scale-95 transition-transform"
                style={{ background: 'linear-gradient(135deg,#8b5cf6,#6d28d9)' }}
              >
                {boostBuying ? 'Activating…' : boostDone ? '✅ Boost Active!' : activeBoost ? 'Already Boosting' : 'Boost Now — $1.99'}
              </button>
            </div>

            {/* Stats preview */}
            <div className="grid grid-cols-3 gap-3">
              {[['🔥', '3×', 'Visibility'], ['👁️', '+180%', 'Profile views'], ['💕', '+65%', 'Match rate']].map(([icon, val, label]) => (
                <div key={label} className="bg-gray-50 rounded-2xl p-3 text-center">
                  <div className="text-xl mb-1">{icon}</div>
                  <p className="font-black text-violet-600 text-base">{val}</p>
                  <p className="text-[10px] text-gray-400">{label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── GIFTS TAB ── */}
        {tab === 'gifts' && (
          <div className="space-y-4">
            <div className="text-center mb-2">
              <h3 className="font-bold text-gray-900 text-base">Send a Gift 🎁</h3>
              <p className="text-sm text-gray-400 mt-0.5">Show someone you care — gifts appear on their profile</p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {GIFTS.map(gift => {
                const sending = giftSending === gift.id
                const done = giftDone === gift.id
                return (
                  <button
                    key={gift.id}
                    onClick={() => handleGift(gift)}
                    disabled={!!giftSending}
                    className="flex flex-col items-center gap-2 p-3 bg-gray-50 rounded-2xl border-2 border-transparent hover:border-[#ff4d6d] hover:bg-rose-50 active:scale-95 transition-all disabled:opacity-50"
                  >
                    <span className="text-3xl">{sending ? '⏳' : done ? '✅' : gift.emoji}</span>
                    <span className="text-xs font-bold text-gray-700">{gift.label}</span>
                    <span className="text-[11px] text-[#ff4d6d] font-bold">${gift.price}</span>
                    <span className="text-[10px] text-gray-400">₦{gift.priceNGN.toLocaleString()}</span>
                  </button>
                )
              })}
            </div>

            <div className="bg-rose-50 rounded-2xl p-4 text-center">
              <p className="text-sm font-semibold text-rose-700">🎁 Gifts are future-ready</p>
              <p className="text-xs text-rose-400 mt-1">Connect your Paystack/Stripe keys to enable real gift purchases</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
