import { createContext, useContext, type ReactNode } from 'react'
import { usePrivacyStore } from './privacyStore'
import type { ReportReason } from './privacyStore'

type PrivacyCtx = ReturnType<typeof usePrivacyStore>

const Ctx = createContext<PrivacyCtx | null>(null)

export function PrivacyProvider({ children }: { children: ReactNode }) {
  const store = usePrivacyStore()
  return <Ctx.Provider value={store}>{children}</Ctx.Provider>
}

export function usePrivacy(): PrivacyCtx {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('usePrivacy must be used inside PrivacyProvider')
  return ctx
}

export type { ReportReason }
