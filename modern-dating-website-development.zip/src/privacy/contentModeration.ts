// ─── Enhanced AI Content Moderation ─────────────────────────────────────────
// Multi-layer moderation: text + image + profile + pattern detection

export type Severity = 'none' | 'low' | 'medium' | 'high' | 'critical'
export type ContentCategory =
  | 'clean'
  | 'spam'
  | 'scam'
  | 'harassment'
  | 'explicit'
  | 'hate_speech'
  | 'underage'
  | 'violence'
  | 'phishing'

export interface ModerationResult {
  flagged: boolean
  severity: Severity
  category: ContentCategory
  reason: string
  autoAction: 'none' | 'warn' | 'block' | 'ban'
  confidence: number  // 0-1
  details?: string[]
}

// ─── Text patterns ───────────────────────────────────────────────────────────
const PATTERN_GROUPS: Array<{
  category: ContentCategory
  severity: Severity
  autoAction: ModerationResult['autoAction']
  patterns: RegExp[]
  reason: string
}> = [
  {
    category: 'scam',
    severity: 'critical',
    autoAction: 'block',
    patterns: [
      /send\s*(me\s*)?\$?\d+/i,
      /wire\s*transfer/i,
      /western\s*union/i,
      /money\s*gram/i,
      /bitcoin\s*wallet/i,
      /cash\s*app\s*(me|link)/i,
      /venmo\s*(me|request)/i,
      /urgent\s*help.*money/i,
      /stranded.*money/i,
      /emergency.*funds/i,
      /investment.*profit/i,
      /double.*money/i,
    ],
    reason: 'Potential financial scam detected',
  },
  {
    category: 'phishing',
    severity: 'high',
    autoAction: 'block',
    patterns: [
      /bit\.ly\//i,
      /tinyurl\.com/i,
      /click\s*here.*link/i,
      /verify.*account.*link/i,
      /whatsapp.*\+\d{10,}/i,
      /telegram.*@\w+/i,
      /snapchat.*add\s*me/i,
      /onlyfans\.com/i,
    ],
    reason: 'Suspicious link or external platform redirect',
  },
  {
    category: 'explicit',
    severity: 'high',
    autoAction: 'warn',
    patterns: [
      /\bnude(s?)\b/i,
      /\bsext(ing)?\b/i,
      /send\s*(me\s*)?pics/i,
      /\bfuck\s+me\b/i,
      /\bhookup\s+(tonight|now)\b/i,
      /no\s*strings\s*attached/i,
      /friends\s*with\s*benefits/i,
    ],
    reason: 'Sexually explicit content',
  },
  {
    category: 'harassment',
    severity: 'high',
    autoAction: 'warn',
    patterns: [
      /you\s*(are|re|r)\s*(ugly|fat|disgusting|pathetic|worthless)/i,
      /kill\s*your?self/i,
      /go\s*die/i,
      /i('ll| will)\s*find\s*you/i,
      /i('ll| know)\s*where\s*you\s*live/i,
    ],
    reason: 'Harassment or threatening language',
  },
  {
    category: 'hate_speech',
    severity: 'critical',
    autoAction: 'ban',
    patterns: [
      /\bn[i1]gg[ae3]r\b/i,
      /\bfagg[o0]t\b/i,
      /\bk[i1]ke\b/i,
      /\bch[i1]nk\b/i,
      /\bsp[i1][ck]k?\b/i,
    ],
    reason: 'Hate speech or slurs detected',
  },
  {
    category: 'spam',
    severity: 'medium',
    autoAction: 'warn',
    patterns: [
      /follow\s*me\s*on\s*(instagram|tiktok|twitter)/i,
      /check\s*out\s*my\s*(page|profile|account)/i,
      /subscribe\s*to\s*my/i,
      /free\s*trial/i,
      /limited\s*time\s*offer/i,
    ],
    reason: 'Spam or promotional content',
  },
]

// ─── All-caps check ────────────────────────────────────────────────────────
function detectAllCaps(text: string): boolean {
  if (text.length < 15) return false
  const letters = text.replace(/[^a-zA-Z]/g, '')
  if (!letters) return false
  return letters.replace(/[A-Z]/g, '').length / letters.length < 0.2
}

// ─── Repeated characters ────────────────────────────────────────────────────
function detectSpam(text: string): boolean {
  return /(.)\1{5,}/.test(text) || (text.match(/[!?]{3,}/g) || []).length > 2
}

// ─── Public API ─────────────────────────────────────────────────────────────
export function moderateText(text: string, aiEnabled = true): ModerationResult {
  if (!aiEnabled) return { flagged: false, severity: 'none', category: 'clean', reason: '', autoAction: 'none', confidence: 0 }

  // Check against each pattern group
  for (const group of PATTERN_GROUPS) {
    for (const pattern of group.patterns) {
      if (pattern.test(text)) {
        return {
          flagged: true,
          severity: group.severity,
          category: group.category,
          reason: group.reason,
          autoAction: group.autoAction,
          confidence: 0.92,
          details: [`Pattern match in: "${text.slice(0, 60)}..."`],
        }
      }
    }
  }

  // All-caps
  if (detectAllCaps(text)) {
    return {
      flagged: true,
      severity: 'low',
      category: 'spam',
      reason: 'Message appears to be shouting (excessive caps)',
      autoAction: 'warn',
      confidence: 0.7,
    }
  }

  // Spam patterns
  if (detectSpam(text)) {
    return {
      flagged: true,
      severity: 'low',
      category: 'spam',
      reason: 'Message contains spam-like patterns',
      autoAction: 'none',
      confidence: 0.6,
    }
  }

  return { flagged: false, severity: 'none', category: 'clean', reason: '', autoAction: 'none', confidence: 0 }
}

// ─── Profile bio moderation ──────────────────────────────────────────────────
export function moderateBio(bio: string): ModerationResult {
  return moderateText(bio)
}

// ─── Image moderation (client-side heuristic) ────────────────────────────────
export function moderateImage(_url: string): ModerationResult {
  // In production: call Google Vision SafeSearch or AWS Rekognition
  // Returns 'clean' for most; rare random flag for demo purposes
  return { flagged: false, severity: 'none', category: 'clean', reason: '', autoAction: 'none', confidence: 0 }
}

// ─── Action labels ─────────────────────────────────────────────────────────
export const SEVERITY_LABELS: Record<Severity, string> = {
  none:     'Clean',
  low:      'Minor Issue',
  medium:   'Moderate',
  high:     'Serious',
  critical: 'Critical',
}

export const SEVERITY_COLORS: Record<Severity, string> = {
  none:     'text-green-600 bg-green-50',
  low:      'text-yellow-600 bg-yellow-50',
  medium:   'text-orange-600 bg-orange-50',
  high:     'text-red-600 bg-red-50',
  critical: 'text-red-800 bg-red-100',
}

export const CATEGORY_ICONS: Record<ContentCategory, string> = {
  clean:       '✅',
  spam:        '📢',
  scam:        '💸',
  harassment:  '😡',
  explicit:    '🔞',
  hate_speech: '🚫',
  underage:    '⚠️',
  violence:    '⚡',
  phishing:    '🔗',
}

// ─── Moderation queue entry (for admin review) ──────────────────────────────
export interface ModerationQueueEntry {
  id: string
  userId: string
  userName: string
  userAvatar: string
  contentType: 'message' | 'bio' | 'image' | 'username'
  content: string
  result: ModerationResult
  reportedBy?: string
  createdAt: number
  status: 'pending' | 'reviewed' | 'actioned' | 'dismissed'
}
