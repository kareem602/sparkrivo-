import { useState } from 'react'

type LegalPage = 'terms' | 'privacy' | 'cookies' | 'community'

interface Props {
  page: LegalPage
  onClose: () => void
}

const LAST_UPDATED = 'January 15, 2025'
const APP_NAME = 'SparkMatch'
const COMPANY = 'SparkMatch Technologies Ltd'
const EMAIL = 'legal@sparkmatch.app'

// ─── Terms of Service ────────────────────────────────────────────────
const TERMS_SECTIONS = [
  {
    title: '1. Acceptance of Terms',
    content: `By accessing or using ${APP_NAME} ("the App"), you agree to be bound by these Terms of Service ("Terms"). If you do not agree, please do not use the App. These Terms constitute a legally binding agreement between you and ${COMPANY}.`,
  },
  {
    title: '2. Eligibility',
    content: `You must be at least 18 years of age to use ${APP_NAME}. By using the App, you represent and warrant that:\n\n• You are at least 18 years old\n• You have the legal capacity to enter into these Terms\n• You are not prohibited from using dating services under applicable laws\n• You are not a registered sex offender\n\nWe reserve the right to verify your age and terminate accounts of users who misrepresent their age.`,
  },
  {
    title: '3. Account Responsibilities',
    content: `You are responsible for:\n\n• Maintaining the confidentiality of your account credentials\n• All activities that occur under your account\n• Providing accurate, truthful profile information\n• Keeping your contact information current\n• Notifying us immediately of any unauthorized use\n\nYou may not share your account with others or create multiple accounts.`,
  },
  {
    title: '4. Prohibited Conduct',
    content: `You agree NOT to:\n\n• Harass, abuse, or harm other users\n• Post false, misleading, or fraudulent content\n• Share sexually explicit material without consent\n• Solicit money or financial information from other users\n• Use the App for commercial solicitation or spam\n• Impersonate other persons or entities\n• Scrape or collect user data without authorization\n• Attempt to circumvent safety features\n• Use automated bots or scripts\n• Engage in romance scams or catfishing\n\nViolation of these rules may result in immediate account suspension.`,
  },
  {
    title: '5. VIP Subscriptions & Payments',
    content: `VIP subscriptions are billed in advance. By subscribing, you authorize us to charge your payment method.\n\n• Monthly plan: $5.00/month\n• Quarterly plan: $12.00/3 months\n• Annual plan: $45.00/year\n\nSubscriptions auto-renew unless cancelled at least 24 hours before the renewal date. Refunds are issued at our discretion within 7 days of purchase for unused subscription periods. All payments are processed securely through Paystack, Flutterwave, Stripe, or PayPal.`,
  },
  {
    title: '6. Content & Intellectual Property',
    content: `You retain ownership of content you post. By posting content, you grant ${APP_NAME} a non-exclusive, royalty-free, worldwide license to use, display, and distribute your content within the App.\n\nYou represent that your content does not infringe any third-party rights. We may remove any content that violates these Terms without notice.`,
  },
  {
    title: '7. Privacy',
    content: `Your privacy is important to us. Our Privacy Policy, incorporated herein by reference, explains how we collect, use, and protect your personal data. By using the App, you consent to our data practices as described in the Privacy Policy.`,
  },
  {
    title: '8. Safety & Moderation',
    content: `${APP_NAME} uses automated AI moderation and human review to maintain a safe environment. We reserve the right to:\n\n• Remove content that violates community standards\n• Suspend or permanently ban accounts for violations\n• Report illegal activity to law enforcement\n• Cooperate with legal investigations\n\nWe are not liable for content posted by users or harm resulting from user interactions.`,
  },
  {
    title: '9. Disclaimers & Limitation of Liability',
    content: `The App is provided "as is" without warranties of any kind. ${COMPANY} is not liable for:\n\n• Accuracy of user profiles or information\n• Outcomes of in-person meetings\n• Loss of data or service interruptions\n• Indirect or consequential damages\n\nOur total liability shall not exceed the amount you paid in the 12 months prior to the claim.`,
  },
  {
    title: '10. Governing Law & Disputes',
    content: `These Terms are governed by the laws of the Federal Republic of Nigeria. Any disputes shall be resolved through binding arbitration in Lagos, Nigeria, except for claims eligible for small claims court. You waive the right to participate in class action lawsuits.`,
  },
  {
    title: '11. Changes to Terms',
    content: `We may modify these Terms at any time. We will notify you of material changes via email or in-app notification. Continued use after changes constitutes acceptance of the new Terms.`,
  },
  {
    title: '12. Contact Us',
    content: `For questions about these Terms:\n\n${COMPANY}\nEmail: ${EMAIL}\nWebsite: www.sparkmatch.app\n\nLast Updated: ${LAST_UPDATED}`,
  },
]

// ─── Privacy Policy ──────────────────────────────────────────────────
const PRIVACY_SECTIONS = [
  {
    title: '1. Information We Collect',
    content: `We collect the following types of information:\n\n**Account Information:** Name, email address, date of birth, gender, profile photos, bio, and location.\n\n**Usage Data:** App interactions, swipe patterns, messages sent/received (metadata only), features used, and session duration.\n\n**Device Data:** Device type, OS version, IP address, and browser type for security and analytics.\n\n**Payment Data:** Transaction IDs and billing country. Full payment details are processed by our payment partners and never stored on our servers.\n\n**Communications:** Messages you send through the App (encrypted in transit and at rest).`,
  },
  {
    title: '2. How We Use Your Information',
    content: `We use your information to:\n\n• Provide and improve the App's matching and messaging features\n• Personalize your experience and recommendations\n• Process payments and manage subscriptions\n• Send notifications about matches, messages, and features\n• Detect and prevent fraud, spam, and abuse\n• Comply with legal obligations\n• Conduct safety moderation and enforce community standards\n• Analyze aggregate usage patterns to improve the service`,
  },
  {
    title: '3. Information Sharing',
    content: `We do NOT sell your personal data. We share information only with:\n\n• **Other users:** Your public profile information (name, photos, bio, interests) as part of normal App functionality\n• **Service providers:** Payment processors (Paystack, Flutterwave, Stripe, PayPal), cloud hosting, analytics, and moderation services under strict data processing agreements\n• **Law enforcement:** When required by valid legal process or to protect safety\n• **Business transfers:** In connection with a merger, acquisition, or asset sale (you will be notified)`,
  },
  {
    title: '4. Data Security',
    content: `We implement industry-standard security measures:\n\n• AES-256 encryption for data at rest\n• TLS 1.3 encryption for data in transit\n• Regular security audits and penetration testing\n• Multi-factor authentication for admin access\n• Automated threat detection and monitoring\n• PCI-DSS compliance for payment processing\n\nDespite our efforts, no system is 100% secure. Please report security vulnerabilities to security@sparkmatch.app.`,
  },
  {
    title: '5. Your Rights & Choices',
    content: `You have the right to:\n\n• **Access:** Request a copy of your personal data\n• **Correction:** Update inaccurate information via profile settings\n• **Deletion:** Delete your account and associated data\n• **Portability:** Export your data in a machine-readable format\n• **Opt-out:** Disable marketing communications\n• **Restrict processing:** Limit how we use your data\n\nTo exercise these rights, contact ${EMAIL} or use the in-app settings.`,
  },
  {
    title: '6. Data Retention',
    content: `We retain your data for as long as your account is active. Upon deletion:\n\n• Profile data is deleted within 30 days\n• Messages are deleted within 7 days\n• Payment records are retained for 7 years (legal requirement)\n• Anonymized analytics data may be retained indefinitely\n\nBackups may retain data for up to 90 days after deletion.`,
  },
  {
    title: '7. Cookies & Tracking',
    content: `We use cookies and similar technologies for:\n\n• Session management and authentication\n• Remembering your preferences\n• Analytics and performance monitoring\n• Security and fraud prevention\n\nYou can control cookies through your browser settings, but disabling them may affect App functionality.`,
  },
  {
    title: '8. Children\'s Privacy',
    content: `${APP_NAME} is strictly for users aged 18 and over. We do not knowingly collect data from minors. If we discover a user is under 18, we will immediately delete their account and associated data. To report an underage user, contact ${EMAIL}.`,
  },
  {
    title: '9. International Transfers',
    content: `Your data may be processed in countries outside your jurisdiction. We ensure appropriate safeguards are in place for international transfers, including standard contractual clauses and adequacy decisions where applicable.`,
  },
  {
    title: '10. Contact & DPO',
    content: `For privacy inquiries or to exercise your rights:\n\nData Protection Officer\n${COMPANY}\nEmail: ${EMAIL}\nAddress: 14 Admiralty Way, Lekki Phase 1, Lagos, Nigeria\n\nLast Updated: ${LAST_UPDATED}`,
  },
]

// ─── Community Guidelines ────────────────────────────────────────────
const COMMUNITY_SECTIONS = [
  {
    title: '🤝 Be Respectful',
    content: `Every person on ${APP_NAME} deserves to feel safe and respected. Treat others the way you want to be treated. We celebrate diversity — different backgrounds, orientations, body types, and relationship goals are all welcome here.`,
  },
  {
    title: '✅ Be Authentic',
    content: `Use real photos of yourself. Don't impersonate others or create fake profiles. Catfishing destroys trust and hurts real people. Your bio should represent who you truly are — authentic connections start with honesty.`,
  },
  {
    title: '🚫 Zero Tolerance: Harassment',
    content: `We have absolutely zero tolerance for:\n\n• Sending unsolicited explicit content\n• Threatening, intimidating, or stalking any user\n• Hate speech targeting race, ethnicity, religion, gender, sexuality, or disability\n• Body shaming or degrading comments\n• Persistent messaging after someone has made clear they're not interested\n\nFirst offense: permanent ban. No appeals.`,
  },
  {
    title: '💸 No Scamming or Solicitation',
    content: `Do not use ${APP_NAME} to:\n\n• Solicit money, gifts, or financial information\n• Promote products, services, or other apps\n• Recruit for pyramid schemes or MLM\n• Engage in romance scams\n• Share links to external websites (unless explicitly asked)\n\nIf someone asks you for money, report them immediately.`,
  },
  {
    title: '📸 Photo Guidelines',
    content: `Your photos must:\n\n• Clearly show your face in the primary photo\n• Feature only you (no group photos as the main image)\n• Be taken by or of you (no celebrity photos)\n• Be appropriate for all audiences\n\nWe prohibit:\n• Nudity or sexually explicit content\n• Photos featuring minors\n• Photos promoting violence or illegal activity\n• Heavily filtered images that don't resemble you`,
  },
  {
    title: '🔞 Age Verification',
    content: `You must be 18 or older. Attempting to connect with minors or sharing content involving minors will result in:\n\n1. Immediate permanent account ban\n2. Reporting to the relevant authorities\n3. Possible criminal referral\n\nIf you encounter anyone who appears underage, report them immediately using the in-app report feature.`,
  },
  {
    title: '📢 How to Report',
    content: `See something wrong? Use the report button on any profile or message:\n\n1. Tap the ··· menu on a profile or message\n2. Select "Report"\n3. Choose the reason\n4. Add details (optional)\n5. Submit\n\nOur moderation team reviews reports within 24 hours. All reports are confidential.`,
  },
  {
    title: '⚖️ Enforcement',
    content: `Violations result in:\n\n• **Minor violations:** Warning + content removal\n• **Moderate violations:** Temporary suspension (3–30 days)\n• **Serious violations:** Permanent ban + data deletion\n• **Illegal activity:** Law enforcement referral\n\nYou can appeal decisions by emailing appeals@sparkmatch.app within 30 days.`,
  },
]

export function LegalPage({ page, onClose }: Props) {
  const [expandedSection, setExpandedSection] = useState<number | null>(null)

  const configs: Record<LegalPage, { title: string; subtitle: string; icon: string; color: string; sections: typeof TERMS_SECTIONS }> = {
    terms: {
      title: 'Terms of Service',
      subtitle: `Last updated ${LAST_UPDATED}`,
      icon: '📄',
      color: 'from-blue-500 to-indigo-600',
      sections: TERMS_SECTIONS,
    },
    privacy: {
      title: 'Privacy Policy',
      subtitle: `Last updated ${LAST_UPDATED}`,
      icon: '🔒',
      color: 'from-emerald-500 to-teal-600',
      sections: PRIVACY_SECTIONS,
    },
    community: {
      title: 'Community Guidelines',
      subtitle: 'Our standards for a safe community',
      icon: '🤝',
      color: 'from-rose-500 to-pink-600',
      sections: COMMUNITY_SECTIONS,
    },
    cookies: {
      title: 'Cookie Policy',
      subtitle: `Last updated ${LAST_UPDATED}`,
      icon: '🍪',
      color: 'from-amber-500 to-orange-600',
      sections: [
        {
          title: 'What Are Cookies',
          content: 'Cookies are small text files stored on your device when you visit a website or use an app. They help us recognize you and remember your preferences.',
        },
        {
          title: 'Essential Cookies',
          content: 'Required for the App to function. These include session cookies for authentication and security tokens. You cannot opt out of these.',
        },
        {
          title: 'Analytics Cookies',
          content: 'We use analytics to understand how the App is used and to improve performance. These collect anonymized data about navigation patterns.',
        },
        {
          title: 'Managing Cookies',
          content: 'You can control cookies through your device settings. Note that disabling certain cookies may impact App functionality.',
        },
      ],
    },
  }

  const config = configs[page]

  return (
    <div className="absolute inset-0 z-[400] flex flex-col bg-white animate-slide-up">
      {/* Header */}
      <div
        className={`flex-shrink-0 px-4 pt-5 pb-5 bg-gradient-to-br ${config.color}`}
      >
        <div className="flex items-center gap-3 mb-3">
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center active:scale-90 transition-transform"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
          <div className="flex-1">
            <p className="text-white/70 text-xs">{APP_NAME}</p>
            <h1 className="text-white font-black text-xl">{config.title}</h1>
          </div>
          <span className="text-3xl">{config.icon}</span>
        </div>
        <div className="bg-white/20 rounded-xl px-3 py-2">
          <p className="text-white/90 text-xs font-medium">{config.subtitle}</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2">
        {config.sections.map((section, i) => (
          <div
            key={i}
            className="border border-gray-100 rounded-2xl overflow-hidden"
          >
            <button
              onClick={() => setExpandedSection(expandedSection === i ? null : i)}
              className="w-full flex items-center justify-between px-4 py-4 text-left hover:bg-gray-50 active:bg-gray-100 transition-colors"
            >
              <span className="font-bold text-gray-900 text-sm pr-4 leading-snug">{section.title}</span>
              <svg
                width="16" height="16" viewBox="0 0 24 24" fill="none"
                stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
                className="flex-shrink-0 transition-transform duration-200"
                style={{ transform: expandedSection === i ? 'rotate(180deg)' : 'rotate(0deg)' }}
              >
                <polyline points="6 9 12 15 18 9"/>
              </svg>
            </button>
            {expandedSection === i && (
              <div className="px-4 pb-4 border-t border-gray-50">
                {section.content.split('\n').map((line, j) => (
                  line.trim() === '' ? (
                    <div key={j} className="h-2" />
                  ) : line.startsWith('•') ? (
                    <div key={j} className="flex items-start gap-2 mt-1.5">
                      <span className="text-[#ff4d6d] mt-0.5 flex-shrink-0">•</span>
                      <span className="text-sm text-gray-600 leading-relaxed">{line.slice(1).trim()}</span>
                    </div>
                  ) : line.startsWith('**') ? (
                    <p key={j} className="text-sm font-bold text-gray-800 mt-2">{line.replace(/\*\*/g, '')}</p>
                  ) : (
                    <p key={j} className="text-sm text-gray-600 leading-relaxed mt-2 first:mt-3">{line}</p>
                  )
                ))}
              </div>
            )}
          </div>
        ))}

        {/* Footer */}
        <div className="bg-gray-50 rounded-2xl p-4 mt-4">
          <p className="text-xs text-gray-500 text-center leading-relaxed">
            Questions? Contact us at{' '}
            <span className="text-[#ff4d6d] font-semibold">{EMAIL}</span>
          </p>
        </div>
      </div>
    </div>
  )
}

// ─── Legal Hub (shows all documents) ─────────────────────────────────
interface HubProps {
  onClose: () => void
}

export function LegalHub({ onClose }: HubProps) {
  const [activePage, setActivePage] = useState<LegalPage | null>(null)

  const links: { id: LegalPage; icon: string; title: string; desc: string; color: string }[] = [
    { id: 'terms',     icon: '📄', title: 'Terms of Service',      desc: 'Rules for using SparkMatch',         color: 'bg-blue-50 border-blue-100'    },
    { id: 'privacy',   icon: '🔒', title: 'Privacy Policy',         desc: 'How we collect & use your data',    color: 'bg-emerald-50 border-emerald-100' },
    { id: 'community', icon: '🤝', title: 'Community Guidelines',   desc: 'Our standards for a safe community', color: 'bg-rose-50 border-rose-100'    },
    { id: 'cookies',   icon: '🍪', title: 'Cookie Policy',           desc: 'How we use cookies & tracking',     color: 'bg-amber-50 border-amber-100'  },
  ]

  if (activePage) {
    return <LegalPage page={activePage} onClose={() => setActivePage(null)} />
  }

  return (
    <div className="absolute inset-0 z-[400] flex flex-col bg-white animate-slide-up">
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-4 border-b border-gray-100">
        <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-gray-500">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div>
          <h2 className="font-black text-gray-900 text-lg">Legal & Policies</h2>
          <p className="text-xs text-gray-400">SparkMatch Technologies Ltd</p>
        </div>
        <span className="ml-auto text-2xl">⚖️</span>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-3">
        {links.map(l => (
          <button
            key={l.id}
            onClick={() => setActivePage(l.id)}
            className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl border active:scale-[0.98] transition-transform text-left ${l.color}`}
          >
            <span className="text-3xl">{l.icon}</span>
            <div className="flex-1">
              <p className="font-bold text-gray-900 text-sm">{l.title}</p>
              <p className="text-xs text-gray-500 mt-0.5">{l.desc}</p>
            </div>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </button>
        ))}

        {/* App version info */}
        <div className="bg-gray-50 rounded-2xl p-4 mt-2">
          <p className="text-xs text-gray-400 text-center">SparkMatch v2.0.0 · Built with ❤️ in Lagos</p>
          <p className="text-xs text-gray-400 text-center mt-1">© 2025 SparkMatch Technologies Ltd. All rights reserved.</p>
        </div>
      </div>
    </div>
  )
}
