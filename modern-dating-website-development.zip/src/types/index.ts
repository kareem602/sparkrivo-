export interface User {
  id: string
  email: string
  name: string
  age: number
  gender: string
  bio: string
  photo_url: string
  is_vip: boolean
  vip_expires_at?: string
  created_at: string
  updated_at: string
}

export interface Profile {
  id: string
  user_id: string
  name: string
  age: number
  gender: string
  bio: string
  photo_url: string
  location?: string
  interests?: string[]
  is_vip: boolean
  vip_expires_at?: string
  is_admin?: boolean
  created_at: string
  updated_at: string
}

export interface Swipe {
  id: string
  swiper_id: string
  swiped_id: string
  action: 'like' | 'pass'
  created_at: string
}

export interface Match {
  id: string
  user1_id: string
  user2_id: string
  created_at: string
}

export interface Message {
  id: string
  match_id: string
  sender_id: string
  receiver_id: string
  content: string
  is_read: boolean
  created_at: string
}

export interface Notification {
  id: string
  user_id: string
  type: 'match' | 'message' | 'like' | 'system'
  title: string
  message: string
  is_read: boolean
  related_user_id?: string
  created_at: string
}

export interface Subscription {
  id: string
  user_id: string
  status: 'active' | 'canceled' | 'expired'
  plan: 'monthly' | 'yearly'
  amount: number
  currency: string
  stripe_subscription_id?: string
  current_period_start: string
  current_period_end: string
  created_at: string
  user?: {
    email: string
    id: string
  }
}

export interface AdminStats {
  total_users: number
  vip_users: number
  total_matches: number
  total_messages: number
  revenue_today: number
  revenue_month: number
}
