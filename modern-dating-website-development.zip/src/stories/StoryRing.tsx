import type { StoryUser } from '../data/mockData'

interface Props {
  user: StoryUser
  onClick: () => void
}

/* Gradient ring for unseen, gray for seen, dashed for own empty */
export function StoryRing({ user, onClick }: Props) {
  const isSeen = user.seen && !user.isOwn
  const isEmpty = user.isOwn && user.slides.length === 0

  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1.5 flex-shrink-0 active:scale-95 transition-transform"
    >
      {isEmpty ? (
        /* Own story — empty: dashed circle with + */
        <div className="relative">
          <div className="w-[66px] h-[66px] rounded-full border-2 border-dashed border-gray-300 flex items-center justify-center bg-gray-50">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </div>
          <div
            className="absolute bottom-0 right-0 w-5 h-5 rounded-full flex items-center justify-center border-2 border-white"
            style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
          >
            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </div>
        </div>
      ) : user.isOwn ? (
        /* Own story — has content: pink ring with + badge */
        <div className="relative">
          <div className="w-[66px] h-[66px] rounded-full p-[2.5px]" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
            <img
              src={user.avatar}
              alt={user.name}
              className="w-full h-full rounded-full object-cover border-2 border-white"
            />
          </div>
          <div
            className="absolute bottom-0 right-0 w-5 h-5 rounded-full flex items-center justify-center border-2 border-white"
            style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
          >
            <svg width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </div>
        </div>
      ) : isSeen ? (
        /* Other user — already seen: gray ring */
        <div className="w-[66px] h-[66px] rounded-full p-[2.5px] bg-gray-300">
          <img
            src={user.avatar}
            alt={user.name}
            className="w-full h-full rounded-full object-cover border-2 border-white"
          />
        </div>
      ) : (
        /* Other user — unseen: pink gradient ring with multi-segment arc hint */
        <div
          className="w-[66px] h-[66px] rounded-full p-[2.5px] story-ring-gradient"
          style={{ background: 'linear-gradient(135deg,#ff4d6d,#f97316,#ff4d6d)' }}
        >
          <div className="relative w-full h-full">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-full h-full rounded-full object-cover border-2 border-white"
            />
            {/* VIP crown */}
            {user.isVip && (
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center text-[9px] border border-white">
                👑
              </div>
            )}
          </div>
        </div>
      )}

      <span className="text-[11px] text-gray-700 font-medium w-[66px] text-center truncate leading-tight">
        {user.isOwn ? 'Your story' : user.name}
      </span>
    </button>
  )
}
