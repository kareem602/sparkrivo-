import { useState, useEffect, useRef, useCallback } from 'react'
import type { StoryUser, StorySlide } from '../data/mockData'

/* ─── Viewer Props ────────────────────────────────────────── */
interface Props {
  users: StoryUser[]
  startIndex: number          // which user to open first
  onClose: () => void
  onUserSeen: (userId: string) => void
}

/* ─── Watcher (fake viewer data per slide) ───────────────── */
const FAKE_WATCHERS = [
  { id: 'w1', name: 'Chisom',  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&h=60&fit=crop&crop=face' },
  { id: 'w2', name: 'Kevin',   avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=60&h=60&fit=crop&crop=face' },
  { id: 'w3', name: 'Fatima',  avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=60&h=60&fit=crop&crop=face' },
  { id: 'w4', name: 'Olawale', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=60&h=60&fit=crop&crop=face' },
  { id: 'w5', name: 'Blessing',avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=60&h=60&fit=crop&crop=face' },
  { id: 'w6', name: 'Ngozi',   avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=60&h=60&fit=crop&crop=face' },
]

function fmtAgo(ms: number) {
  const s = Math.floor((Date.now() - ms) / 1000)
  if (s < 60) return `${s}s ago`
  if (s < 3600) return `${Math.floor(s / 60)}m ago`
  return `${Math.floor(s / 3600)}h ago`
}

/* ─── Progress bar for one segment ─────────────────────────── */
function ProgressBar({ active, seen, duration }: { active: boolean; seen: boolean; duration: number }) {
  const [width, setWidth] = useState(seen ? 100 : 0)
  const startRef = useRef<number | null>(null)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    if (!active) {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      setWidth(seen ? 100 : 0)
      return
    }
    setWidth(0)
    startRef.current = null

    const animate = (ts: number) => {
      if (!startRef.current) startRef.current = ts
      const elapsed = ts - startRef.current
      setWidth(Math.min(100, (elapsed / duration) * 100))
      if (elapsed < duration) rafRef.current = requestAnimationFrame(animate)
    }
    rafRef.current = requestAnimationFrame(animate)
    return () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }
  }, [active, seen, duration])

  return (
    <div className="flex-1 h-[3px] rounded-full overflow-hidden bg-white/30">
      <div
        className="h-full bg-white rounded-full"
        style={{ width: `${width}%`, transition: active ? 'none' : 'none' }}
      />
    </div>
  )
}

/* ─── Reply bar ──────────────────────────────────────────── */
function ReplyBar({ userName, onSend }: { userName: string; onSend: (t: string) => void }) {
  const [val, setVal] = useState('')
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 flex items-center bg-white/20 backdrop-blur rounded-full px-4 py-2.5 gap-2">
        <input
          value={val}
          onChange={e => setVal(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && val.trim()) { onSend(val.trim()); setVal('') } }}
          placeholder={`Reply to ${userName}…`}
          className="flex-1 bg-transparent text-white text-sm outline-none placeholder-white/60"
        />
      </div>
      <button
        onClick={() => { if (val.trim()) { onSend(val.trim()); setVal('') } }}
        className="w-10 h-10 rounded-full bg-white/20 backdrop-blur flex items-center justify-center active:scale-90 transition-transform"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
        </svg>
      </button>
    </div>
  )
}

/* ─── Watchers Sheet ─────────────────────────────────────── */
function WatchersSheet({ isOwn, onClose }: { isOwn: boolean; onClose: () => void }) {
  if (!isOwn) return null
  const watchers = FAKE_WATCHERS.slice(0, 3 + Math.floor(Math.random() * 3))
  return (
    <div
      className="absolute inset-0 z-20 flex flex-col justify-end"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-t-3xl px-5 pt-4 pb-8"
        onClick={e => e.stopPropagation()}
        style={{ maxHeight: '60%' }}
      >
        {/* Handle */}
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-4" />
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-gray-900 text-base">Views ({watchers.length})</h3>
          <button onClick={onClose}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round">
              <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
        <div className="overflow-y-auto space-y-3">
          {watchers.map(w => (
            <div key={w.id} className="flex items-center gap-3">
              <img src={w.avatar} alt={w.name} className="w-10 h-10 rounded-full object-cover flex-shrink-0" />
              <div className="flex-1">
                <p className="font-semibold text-gray-900 text-sm">{w.name}</p>
                <p className="text-xs text-gray-400">Viewed your story</p>
              </div>
              <button className="text-[11px] font-bold text-[#ff4d6d] px-3 py-1 rounded-full border border-[#ff4d6d]">
                Message
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

/* ─── Single slide renderer ──────────────────────────────── */
function SlideContent({ slide }: { slide: StorySlide }) {
  if (slide.type === 'text') {
    return (
      <div className={`absolute inset-0 bg-gradient-to-br ${slide.bgGradient || 'from-rose-400 to-pink-600'} flex items-center justify-center p-8`}>
        <p
          className="text-center font-black text-3xl leading-tight"
          style={{ color: slide.textColor || '#fff', textShadow: '0 2px 12px rgba(0,0,0,0.3)' }}
        >
          {slide.textContent}
        </p>
      </div>
    )
  }

  if (slide.type === 'image') {
    return (
      <>
        <img
          src={slide.mediaUrl}
          alt=""
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />
        {/* bottom gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-black/20 pointer-events-none" />
        {slide.overlayText && (
          <div className="absolute bottom-36 left-0 right-0 flex justify-center px-6 pointer-events-none">
            <p
              className="text-center font-bold text-xl drop-shadow-lg"
              style={{ color: slide.overlayTextColor || '#fff' }}
            >
              {slide.overlayText}
            </p>
          </div>
        )}
      </>
    )
  }

  if (slide.type === 'video') {
    return (
      <>
        <video
          src={slide.mediaUrl}
          className="absolute inset-0 w-full h-full object-cover"
          autoPlay muted playsInline loop
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20 pointer-events-none" />
        {slide.overlayText && (
          <div className="absolute bottom-36 left-0 right-0 flex justify-center px-6 pointer-events-none">
            <p
              className="text-center font-bold text-xl drop-shadow-lg"
              style={{ color: slide.overlayTextColor || '#fff' }}
            >
              {slide.overlayText}
            </p>
          </div>
        )}
      </>
    )
  }

  return null
}

/* ─── More Options Menu Sheet ───────────────────────────── */
interface MoreMenuProps {
  userName: string
  userAvatar: string
  isMuted: boolean
  isOwn: boolean
  onMuteToggle: () => void
  onReport: () => void
  onBlock: () => void
  onShare: () => void
  onClose: () => void
}

function StoryMoreMenu({ userName, userAvatar, isMuted, isOwn, onMuteToggle, onReport, onBlock, onShare, onClose }: MoreMenuProps) {
  const options: Array<{
    icon: string
    label: string
    sub: string
    danger?: boolean
    action: () => void
    hidden?: boolean
  }> = [
    {
      icon: isMuted ? '🔊' : '🔇',
      label: isMuted ? `Unmute ${userName}` : `Mute ${userName}`,
      sub: isMuted ? 'See their stories again' : 'Hide stories without blocking',
      action: onMuteToggle,
      hidden: isOwn,
    },
    {
      icon: '🔗',
      label: 'Share story',
      sub: 'Copy link or share externally',
      action: onShare,
    },
    {
      icon: '🚩',
      label: `Report ${userName}`,
      sub: 'Inappropriate or harmful content',
      danger: true,
      action: onReport,
      hidden: isOwn,
    },
    {
      icon: '🚫',
      label: `Block ${userName}`,
      sub: "They won't see your profile",
      danger: true,
      action: onBlock,
      hidden: isOwn,
    },
  ].filter(o => !o.hidden)

  return (
    /* Backdrop */
    <div
      className="absolute inset-0 z-[50] flex flex-col justify-end"
      style={{ background: 'rgba(0,0,0,0.6)' }}
      onClick={onClose}
    >
      {/* Sheet */}
      <div
        className="bg-white rounded-t-3xl px-5 pt-2 pb-10 animate-slide-up"
        onClick={e => e.stopPropagation()}
      >
        {/* Handle */}
        <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-4 mt-2" />

        {/* User header */}
        <div className="flex items-center gap-3 mb-5 pb-4 border-b border-gray-100">
          <img src={userAvatar} alt={userName} className="w-11 h-11 rounded-full object-cover" />
          <div>
            <p className="font-bold text-gray-900 text-sm">{userName}'s story</p>
            <p className="text-xs text-gray-400">Story options</p>
          </div>
        </div>

        {/* Options */}
        <div className="space-y-2">
          {options.map(opt => (
            <button
              key={opt.label}
              onClick={opt.action}
              className={`w-full flex items-center gap-4 px-4 py-3.5 rounded-2xl active:scale-[0.98] transition-all text-left ${
                opt.danger ? 'bg-red-50 hover:bg-red-100' : 'bg-gray-50 hover:bg-gray-100'
              }`}
            >
              <span className="text-2xl w-8 text-center flex-shrink-0">{opt.icon}</span>
              <div className="flex-1 min-w-0">
                <p className={`font-bold text-sm ${opt.danger ? 'text-red-600' : 'text-gray-900'}`}>
                  {opt.label}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">{opt.sub}</p>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d1d5db" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>

        {/* Cancel */}
        <button
          onClick={onClose}
          className="w-full mt-4 py-3.5 rounded-2xl bg-gray-100 text-gray-600 font-bold text-sm active:scale-[0.98] transition-transform"
        >
          Cancel
        </button>
      </div>
    </div>
  )
}

/* ─── Main Viewer ────────────────────────────────────────── */
export default function StoryViewer({ users, startIndex, onClose, onUserSeen }: Props) {
  const [userIdx, setUserIdx] = useState(startIndex)
  const [slideIdx, setSlideIdx] = useState(0)
  const [paused, setPaused] = useState(false)
  const [liked, setLiked] = useState<Set<string>>(new Set())
  const [showWatchers, setShowWatchers] = useState(false)
  const [showReplySent, setShowReplySent] = useState(false)
  const [showMoreMenu, setShowMoreMenu] = useState(false)
  const [muted, setMuted] = useState(false)
  const [slideKey, setSlideKey] = useState(0) // forces re-render on slide change

  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const holdRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const longPressActive = useRef(false)

  const user = users[userIdx]
  const slide = user?.slides[slideIdx]
  const isOwn = user?.isOwn ?? false
  const totalSlides = user?.slides.length ?? 0

  /* ── Auto-advance timer ─────────────────────── */
  const advance = useCallback(() => {
    if (slideIdx < totalSlides - 1) {
      setSlideIdx(i => i + 1)
      setSlideKey(k => k + 1)
    } else {
      // Mark this user as seen
      onUserSeen(user.id)
      if (userIdx < users.length - 1) {
        setUserIdx(u => u + 1)
        setSlideIdx(0)
        setSlideKey(k => k + 1)
      } else {
        onClose()
      }
    }
  }, [slideIdx, totalSlides, userIdx, users.length, user, onUserSeen, onClose])

  useEffect(() => {
    if (paused || !slide) return
    timerRef.current = setTimeout(advance, slide.duration)
    return () => { if (timerRef.current) clearTimeout(timerRef.current) }
  }, [slide, paused, advance, slideKey])

  /* ── Tap left / right ─────────────────────── */
  const tapLeft = () => {
    if (longPressActive.current) return
    if (slideIdx > 0) {
      setSlideIdx(i => i - 1)
      setSlideKey(k => k + 1)
    } else if (userIdx > 0) {
      const prevUser = users[userIdx - 1]
      setUserIdx(u => u - 1)
      setSlideIdx(prevUser.slides.length - 1)
      setSlideKey(k => k + 1)
    }
  }

  const tapRight = () => {
    if (longPressActive.current) return
    advance()
  }

  /* ── Hold to pause ────────────────────────── */
  const startHold = () => {
    holdRef.current = setTimeout(() => {
      longPressActive.current = true
      setPaused(true)
    }, 150)
  }
  const endHold = () => {
    clearTimeout(holdRef.current!)
    longPressActive.current = false
    setPaused(false)
  }

  /* ── Like ─────────────────────────────────── */
  const toggleLike = () => {
    if (!slide) return
    setLiked(prev => {
      const n = new Set(prev)
      n.has(slide.id) ? n.delete(slide.id) : n.add(slide.id)
      return n
    })
  }

  /* ── Reply ────────────────────────────────── */
  const handleReply = (_text: string) => {
    setShowReplySent(true)
    setTimeout(() => setShowReplySent(false), 2000)
  }

  if (!user || !slide) return null

  const isLiked = liked.has(slide.id)

  return (
    <div className="absolute inset-0 z-[100] bg-black flex items-center justify-center select-none">
      {/* ── Slide ── */}
      <div className="relative w-full h-full overflow-hidden">
        <SlideContent slide={slide} />

        {/* ── Tap zones (left / right) — behind header ── */}
        <div className="absolute inset-0 flex" style={{ zIndex: 10 }}>
          {/* Left third — go back */}
          <div
            className="w-1/3 h-full"
            onPointerDown={startHold}
            onPointerUp={() => { endHold(); if (!longPressActive.current) tapLeft() }}
            onPointerLeave={endHold}
          />
          {/* Middle — stay / pause only; top 80px excluded so close button works */}
          <div
            className="flex-1 h-full"
            onPointerDown={startHold}
            onPointerUp={() => { endHold(); if (!longPressActive.current) tapRight() }}
            onPointerLeave={endHold}
          />
        </div>

        {/* ── Top bar: progress + header — ABOVE tap zones ── */}
        <div className="absolute top-0 left-0 right-0 px-3 pt-3 pb-2" style={{ zIndex: 30 }}>
          {/* Progress segments — no pointer events so tap-through works */}
          <div className="flex gap-1 mb-3 pointer-events-none">
            {user.slides.map((s, i) => (
              <ProgressBar
                key={s.id}
                active={!paused && i === slideIdx}
                seen={i < slideIdx}
                duration={s.duration}
              />
            ))}
          </div>

          {/* Header row — all interactive */}
          <div className="flex items-center gap-2.5">
            <img
              src={user.avatar}
              alt={user.name}
              className="w-9 h-9 rounded-full object-cover border-2 border-white shadow pointer-events-none"
            />
            <div className="flex-1 min-w-0 pointer-events-none">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-white text-sm drop-shadow">{user.name}</span>
                {user.isVip && <span className="text-xs">👑</span>}
              </div>
              <span className="text-white/70 text-[11px]">{fmtAgo(slide.createdAt)}</span>
            </div>

            {/* Pause indicator */}
            {paused && (
              <div className="px-2 py-0.5 bg-white/20 backdrop-blur rounded-full pointer-events-none">
                <span className="text-white text-[10px] font-bold">PAUSED</span>
              </div>
            )}

            {/* ✕ Close button — highest z, isolated from tap zones */}
            <button
              onPointerDown={e => e.stopPropagation()}
              onPointerUp={e => { e.stopPropagation(); onClose() }}
              onClick={e => { e.stopPropagation(); onClose() }}
              className="w-10 h-10 rounded-full bg-black/40 backdrop-blur flex items-center justify-center active:scale-90 transition-transform flex-shrink-0"
              style={{ touchAction: 'manipulation' }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        </div>

        {/* ── Arrow hints — also above tap zones ── */}
        {userIdx > 0 && (
          <button
            onPointerDown={e => e.stopPropagation()}
            onClick={e => { e.stopPropagation(); tapLeft() }}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/30 backdrop-blur flex items-center justify-center opacity-70 active:scale-90 transition-transform"
            style={{ zIndex: 30 }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="15 18 9 12 15 6"/>
            </svg>
          </button>
        )}
        {userIdx < users.length - 1 && (
          <button
            onPointerDown={e => e.stopPropagation()}
            onClick={e => { e.stopPropagation(); tapRight() }}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/30 backdrop-blur flex items-center justify-center opacity-70 active:scale-90 transition-transform"
            style={{ zIndex: 30 }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </button>
        )}

        {/* ── Bottom bar ── */}
        <div className="absolute bottom-0 left-0 right-0 px-4 pb-8 pt-6" style={{ zIndex: 30 }}>
          {/* Reply sent flash */}
          {showReplySent && (
            <div className="flex justify-center mb-3">
              <div className="px-4 py-2 bg-white/20 backdrop-blur rounded-full">
                <span className="text-white text-sm font-semibold">✓ Sent!</span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-3">
            {/* Reply or Watchers */}
            <div className="flex-1">
              {isOwn ? (
                <button
                  onPointerDown={e => e.stopPropagation()}
                  onPointerUp={e => e.stopPropagation()}
                  onClick={e => { e.stopPropagation(); setPaused(true); setShowWatchers(true) }}
                  className="flex items-center gap-2 text-white/90 text-sm font-semibold"
                  style={{ touchAction: 'manipulation' }}
                >
                  <div className="flex -space-x-2">
                    {FAKE_WATCHERS.slice(0, 3).map(w => (
                      <img key={w.id} src={w.avatar} alt="" className="w-6 h-6 rounded-full border border-black object-cover" />
                    ))}
                  </div>
                  <span className="text-white/80 text-xs">{3 + Math.floor(Math.random() * 3)} viewers</span>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="18 15 12 9 6 15"/>
                  </svg>
                </button>
              ) : (
                <ReplyBar userName={user.name} onSend={handleReply} />
              )}
            </div>

            {/* Like button */}
            <button
              onPointerDown={e => e.stopPropagation()}
              onPointerUp={e => e.stopPropagation()}
              onClick={e => { e.stopPropagation(); toggleLike() }}
              className="w-11 h-11 flex items-center justify-center rounded-full bg-black/30 backdrop-blur active:scale-90 transition-transform"
              style={{ touchAction: 'manipulation' }}
            >
              <svg
                width="22"
                height="20"
                viewBox="0 0 24 22"
                fill={isLiked ? '#ff4d6d' : 'none'}
                stroke={isLiked ? '#ff4d6d' : 'white'}
                strokeWidth="1.8"
                style={{ transition: 'all 0.18s ease', transform: isLiked ? 'scale(1.2)' : 'scale(1)' }}
              >
                <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
              </svg>
            </button>

            {/* More options ⋯ */}
            <button
              onPointerDown={e => e.stopPropagation()}
              onPointerUp={e => e.stopPropagation()}
              onClick={e => {
                e.stopPropagation()
                setPaused(true)
                setShowMoreMenu(true)
              }}
              className="w-11 h-11 flex items-center justify-center rounded-full bg-black/30 backdrop-blur active:scale-90 transition-transform"
              style={{ touchAction: 'manipulation' }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                <circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* ── Watchers sheet ── */}
      {showWatchers && (
        <WatchersSheet
          isOwn={isOwn}
          onClose={() => { setShowWatchers(false); setPaused(false) }}
        />
      )}

      {/* ── More Options Sheet ── */}
      {showMoreMenu && (
        <StoryMoreMenu
          userName={user.name}
          userAvatar={user.avatar}
          isMuted={muted}
          isOwn={isOwn}
          onMuteToggle={() => setMuted(m => !m)}
          onReport={() => {
            setShowMoreMenu(false)
            setPaused(false)
            // In real app: open report flow
            alert(`Reported ${user.name}'s story. Our team will review it within 24 hours.`)
          }}
          onBlock={() => {
            setShowMoreMenu(false)
            onClose()
          }}
          onShare={() => {
            setShowMoreMenu(false)
            setPaused(false)
            if (navigator.share) {
              navigator.share({ title: `${user.name}'s Story`, url: window.location.href }).catch(() => {})
            } else {
              navigator.clipboard.writeText(window.location.href).catch(() => {})
              alert('Link copied to clipboard!')
            }
          }}
          onClose={() => { setShowMoreMenu(false); setPaused(false) }}
        />
      )}
    </div>
  )
}
