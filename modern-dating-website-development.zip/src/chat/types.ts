export type MessageStatus = 'sending' | 'sent' | 'seen'
export type MessageType = 'text' | 'image' | 'video' | 'voice' | 'file'

export interface ReplyTo {
  id: string
  senderName: string
  preview: string // text or "[Image]" / "[Voice note]" etc
}

export interface ChatMessage {
  id: string
  senderId: string
  type: MessageType
  text?: string
  mediaUrl?: string        // blob URL or remote URL
  mediaMimeType?: string
  mediaName?: string
  mediaSize?: number
  voiceDuration?: number   // seconds
  waveform?: number[]      // 0-1 amplitudes
  uploadProgress?: number  // 0-100 while uploading
  status: MessageStatus
  time: string             // display time string
  timestamp: number        // ms, for sorting
  replyTo?: ReplyTo
  deleted?: boolean
  emoji?: string           // quick emoji reaction
}
