import { useState, useRef, useEffect, useCallback } from 'react'
import { useChatStore } from './useChatStore'
import { useVoiceRecorder } from './useVoiceRecorder'
import { VoiceMessageBubble } from './components/VoiceMessageBubble'
import { MediaBubble } from './components/MediaBubble'
import { FullscreenMedia } from './components/FullscreenMedia'
import { MessageStatusIcon } from './components/MessageStatus'
import { ReplyBanner } from './components/ReplyBanner'
import { TypingIndicator } from './components/TypingIndicator'
import { EmojiPicker, QuickReactions } from './components/EmojiPicker'
import { LiveWaveform } from './components/WaveformBars'
import type { ChatMessage, MessageType, ReplyTo } from './types'
import { usePrivacy } from '../privacy/PrivacyContext'
import { moderateText } from '../privacy/contentModeration'
import { ModerationWarning, UserOptionsSheet, ReportFlow, BlockConfirmSheet } from '../privacy/PrivacySettings'
import { useCall } from '../calls/CallContext'
import UserProfileView from '../components/UserProfileView'
import { getRichProfile } from '../data/mockData'
import { useVip } from '../vip/VipContext'
import WallpaperPicker from './WallpaperPicker'
import {
  getWallpaperForMatch,
  setWallpaperForMatch,
  clearWallpaperForMatch,
  resolveWallpaperCss,
} from './wallpapers'

interface Match {
  id: string
  name: string
  avatar: string
  isVip?: boolean
  isOnline?: boolean
}

interface Props {
  match: Match
  onBack: () => void
}

function fmtDuration(s: number) {
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

function getMessagePreview(msg: ChatMessage): string {
  if (msg.type === 'text') return msg.text || ''
  if (msg.type === 'image') return '📷 Photo'
  if (msg.type === 'video') return '🎥 Video'
  if (msg.type === 'voice') return '🎤 Voice note'
  if (msg.type === 'file') return `📎 ${msg.mediaName || 'File'}`
  return ''
}

export default function ChatScreen({ match, onBack }: Props) {
  const { messages, isOtherTyping, sendText, sendMedia, deleteMessage, markSeen } =
    useChatStore(match.id)
  const voice = useVoiceRecorder()
  const { settings, blockUser, isBlocked, submitReport } = usePrivacy()
  const { startCall } = useCall()
  // Read VIP status directly from the global store — NOT from props
  const { isVip } = useVip()
  const [showCallVipPrompt, setShowCallVipPrompt] = useState<'voice' | 'video' | null>(null)
  const [showMatchProfile, setShowMatchProfile] = useState(false)
  const [showWallpaperPicker, setShowWallpaperPicker] = useState(false)

  // Wallpaper state — persisted per match
  const [wallpaperId, setWallpaperId] = useState<string | null>(() => getWallpaperForMatch(match.id))
  const [wallpaperCustomUrl, setWallpaperCustomUrl] = useState<string | null>(null)

  const { backgroundCss: wallpaperBg } = resolveWallpaperCss(wallpaperId, wallpaperCustomUrl)

  const applyWallpaper = (id: string | null, customUrl: string | null) => {
    if (customUrl) {
      // Custom uploaded photo
      setWallpaperId(null)
      setWallpaperCustomUrl(customUrl)
      setWallpaperForMatch(match.id, '__custom__')
    } else if (!id || id === 'default') {
      // Clear wallpaper
      clearWallpaperForMatch(match.id)
      setWallpaperId(null)
      setWallpaperCustomUrl(null)
    } else {
      // Preset wallpaper
      setWallpaperForMatch(match.id, id)
      setWallpaperId(id)
      setWallpaperCustomUrl(null)
    }
  }

  type ChatMenu = 'none' | 'options' | 'block' | 'report'
  const [chatMenu, setChatMenu] = useState<ChatMenu>('none')

  // AI moderation warning
  const [modWarning, setModWarning] = useState<{ reason: string; severity: 'low' | 'medium' | 'high'; pendingText: string } | null>(null)

  const [input, setInput] = useState('')
  const [replyTo, setReplyTo] = useState<ReplyTo | null>(null)
  const [expandedImage, setExpandedImage] = useState<string | null>(null)
  const [showEmoji, setShowEmoji] = useState(false)
  const [longPressMsg, setLongPressMsg] = useState<ChatMessage | null>(null)

  const matchUser = { id: match.id, name: match.name, avatar: match.avatar }
  const blocked = isBlocked(match.id)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  // Messaging is unlimited for everyone — no daily cap
  const canSend = true

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isOtherTyping])

  // Mark seen when opening
  useEffect(() => { markSeen() }, [markSeen])

  // Close menus on outside click
  useEffect(() => {
    const handler = () => { setLongPressMsg(null); setShowEmoji(false) }
    document.addEventListener('click', handler)
    return () => document.removeEventListener('click', handler)
  }, [])

  /* ─── SEND TEXT (with AI moderation) ───────── */
  const handleSendText = useCallback(() => {
    const t = input.trim()
    if (!t || !canSend) return

    // AI moderation check
    if (settings.aiModeration) {
      const result = moderateText(t)
      if (result.flagged) {
        setModWarning({ reason: result.reason!, severity: result.severity as 'low' | 'medium' | 'high', pendingText: t })
        return
      }
    }

    sendText(t, replyTo ?? undefined)
    setInput('')
    setReplyTo(null)
    setShowEmoji(false)
    inputRef.current?.focus()
  }, [input, sendText, replyTo, settings.aiModeration])

  /* ─── SEND VOICE ─────────────────────────────── */
  const handleSendVoice = useCallback(async () => {
    if (!voice.recording) return
    const file = new File([voice.recording.blob], 'voice.webm', { type: voice.recording.blob.type })
    await sendMedia(file, 'voice', replyTo ?? undefined, voice.recording.waveform, voice.recording.duration)
    voice.clearRecording()
    setReplyTo(null)
  }, [voice, sendMedia, replyTo])

  /* ─── FILE PICK ─────────────────────────────── */
  const handleFilePick = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    let type: MessageType = 'file'
    if (file.type.startsWith('image/')) type = 'image'
    else if (file.type.startsWith('video/')) type = 'video'
    else if (file.type.startsWith('audio/')) type = 'voice'
    await sendMedia(file, type, replyTo ?? undefined)
    setReplyTo(null)
    e.target.value = ''
  }, [sendMedia, replyTo])

  /* ─── LONG PRESS ─────────────────────────────── */
  const handleLongPress = useCallback((msg: ChatMessage, e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault()
    longPressTimer.current = setTimeout(() => {
      setLongPressMsg(msg)
    }, 400)
  }, [])
  const cancelLongPress = useCallback(() => {
    if (longPressTimer.current) clearTimeout(longPressTimer.current)
  }, [])

  /* ─── REPLY ─────────────────────────────────── */
  const handleReply = useCallback((msg: ChatMessage) => {
    setReplyTo({
      id: msg.id,
      senderName: msg.senderId === 'me' ? 'You' : match.name,
      preview: getMessagePreview(msg),
    })
    setLongPressMsg(null)
    inputRef.current?.focus()
  }, [match.name])

  /* ─── DELETE ─────────────────────────────────── */
  const handleDelete = useCallback((msgId: string) => {
    deleteMessage(msgId)
    setLongPressMsg(null)
  }, [deleteMessage])

  /* ─── EMOJI INSERT ───────────────────────────── */
  const insertEmoji = useCallback((emoji: string) => {
    setInput(prev => prev + emoji)
    setShowEmoji(false)
    inputRef.current?.focus()
  }, [])

  /* ─── RENDER ─────────────────────────────────── */
  return (
    <div className="flex flex-col h-full overflow-hidden relative" style={{ background: 'var(--color-bg)' }}>
      {/* ── HEADER ── */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-3 z-10" style={{ background: 'var(--color-surface)', borderBottom: '1px solid var(--color-border)', boxShadow: '0 1px 8px rgba(255,77,109,0.06)' }}>
        <button onClick={onBack} className="p-1 -ml-1 text-gray-500 active:scale-90 transition-transform">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        {/* Avatar — tap to view profile */}
        <button
          onClick={() => setShowMatchProfile(true)}
          className="relative flex-shrink-0 active:scale-90 transition-transform"
        >
          <img src={match.avatar} alt={match.name} className="w-10 h-10 rounded-full object-cover ring-2 ring-transparent hover:ring-[#ff4d6d]/30" />
          {match.isOnline && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-400 rounded-full border-2 border-white" />}
        </button>
        {/* Name — also taps to view profile */}
        <button onClick={() => setShowMatchProfile(true)} className="flex-1 min-w-0 text-left active:opacity-70 transition-opacity">
          <div className="flex items-center gap-1.5">
            <h3 className="font-bold text-gray-900 text-sm truncate">{match.name}</h3>
            {match.isVip && <span className="text-xs flex-shrink-0">👑</span>}
          </div>
          <p className="text-xs text-gray-400">{isOtherTyping ? 'typing…' : match.isOnline ? 'Online now' : 'Offline'}</p>
        </button>
        <div className="flex items-center gap-2">
          {/* Voice call — VIP only */}
          {isVip ? (
            <button
              onClick={() => startCall({ id: match.id, name: match.name, avatar: match.avatar, isVip: match.isVip }, 'voice')}
              className="w-9 h-9 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600 active:scale-90 transition-transform"
              title="Voice call"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02L6.6 10.8z"/>
              </svg>
            </button>
          ) : (
            <button
              onClick={() => setShowCallVipPrompt('voice')}
              className="relative w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 active:scale-90 transition-transform"
              title="Voice call — VIP only"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor">
                <path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02L6.6 10.8z"/>
              </svg>
              {/* Lock badge */}
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-amber-400 rounded-full flex items-center justify-center text-[7px]">🔒</span>
            </button>
          )}
          {/* Video call — VIP only */}
          {isVip ? (
            <button
              onClick={() => startCall({ id: match.id, name: match.name, avatar: match.avatar, isVip: match.isVip }, 'video')}
              className="w-9 h-9 rounded-full bg-rose-50 flex items-center justify-center text-[#ff4d6d] active:scale-90 transition-transform"
              title="Video call"
            >
              <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
              </svg>
            </button>
          ) : (
            <button
              onClick={() => setShowCallVipPrompt('video')}
              className="relative w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 active:scale-90 transition-transform"
              title="Video call — VIP only"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>
              </svg>
              {/* Lock badge */}
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-amber-400 rounded-full flex items-center justify-center text-[7px]">🔒</span>
            </button>
          )}
          {/* Wallpaper button — VIP only */}
          {isVip ? (
            <button
              onClick={() => setShowWallpaperPicker(true)}
              className="w-9 h-9 rounded-full flex items-center justify-center text-base active:scale-90 transition-transform"
              style={{ background: 'var(--color-bg-tertiary)' }}
              title="Change wallpaper"
            >
              🖼️
            </button>
          ) : (
            <button
              onClick={() => setShowCallVipPrompt('voice')}
              className="relative w-9 h-9 rounded-full flex items-center justify-center text-base active:scale-90 transition-transform"
              style={{ background: 'var(--color-bg-tertiary)' }}
              title="Wallpaper — VIP only"
            >
              🖼️
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-amber-400 rounded-full flex items-center justify-center text-[7px]">🔒</span>
            </button>
          )}
          {/* More → opens block/report sheet */}
          <button
            onClick={e => { e.stopPropagation(); setChatMenu('options') }}
            className="w-9 h-9 rounded-full flex items-center justify-center text-gray-500 active:scale-90 transition-transform"
            style={{ background: 'var(--color-bg-tertiary)' }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
              <circle cx="12" cy="5" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="12" cy="19" r="1.5"/>
            </svg>
          </button>
        </div>
      </div>



      {/* ── MESSAGES ── */}
      <div
        className="flex-1 overflow-y-auto py-3 space-y-1 scroll-smooth"
        id="msg-list"
        style={{ background: wallpaperBg }}
      >
        {messages.map((msg, idx) => {
          const isMe = msg.senderId === 'me'
          const showAvatar = !isMe && (idx === 0 || messages[idx - 1]?.senderId !== msg.senderId)
          if (msg.deleted) {
            return (
              <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} px-4`}>
                <span className="text-xs text-gray-400 italic px-3 py-1.5 bg-gray-100 rounded-2xl">
                  {isMe ? 'You deleted this message' : 'Message deleted'}
                </span>
              </div>
            )
          }
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} px-4`}
            >
              <div
                className={`flex items-end gap-2 max-w-[85%] ${isMe ? 'flex-row-reverse' : 'flex-row'}`}
                            onMouseDown={e => handleLongPress(msg, e)}
                onTouchStart={e => handleLongPress(msg, e)}
                onMouseUp={cancelLongPress}
                onTouchEnd={cancelLongPress}
                onMouseLeave={cancelLongPress}
              >
                {/* Other user avatar */}
                {!isMe && (
                  <div className="w-7 h-7 flex-shrink-0">
                    {showAvatar ? (
                      <img src={match.avatar} alt="" className="w-7 h-7 rounded-full object-cover" />
                    ) : null}
                  </div>
                )}

                {/* Bubble */}
                <div className="flex flex-col">
                  {/* Reply preview */}
                  {msg.replyTo && (
                    <div className={`mb-0.5 ${isMe ? 'items-end' : 'items-start'}`}>
                      <ReplyBanner replyTo={msg.replyTo} isMe={isMe} />
                    </div>
                  )}

                  {/* Content */}
                  {msg.type === 'text' && (
                    <div
                      className={`px-4 py-2.5 text-sm leading-relaxed ${
                        isMe
                          ? 'text-white rounded-2xl rounded-br-sm'
                          : 'rounded-2xl rounded-bl-sm'
                      }`}
                      style={isMe
                        ? { background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }
                        : {
                            // Bubbles adapt: semi-transparent white on photo/dark wallpapers
                            background: (wallpaperId && wallpaperId !== 'default') || wallpaperCustomUrl
                              ? 'rgba(255,255,255,0.88)'
                              : 'var(--chat-msg-bg)',
                            color: '#1f2937',
                            boxShadow: '0 1px 6px rgba(0,0,0,0.12)',
                            backdropFilter: 'blur(4px)',
                          }
                      }
                    >
                      {msg.text}
                    </div>
                  )}

                  {(msg.type === 'image' || msg.type === 'video') && msg.mediaUrl && (
                    <MediaBubble
                      url={msg.mediaUrl}
                      type={msg.type}
                      isMe={isMe}
                      uploadProgress={msg.uploadProgress}
                      onExpand={setExpandedImage}
                    />
                  )}

                  {msg.type === 'voice' && msg.mediaUrl && (
                    <VoiceMessageBubble
                      url={msg.mediaUrl}
                      duration={msg.voiceDuration}
                      waveform={msg.waveform}
                      isMe={isMe}
                    />
                  )}

                  {msg.type === 'file' && (
                    <a
                      href={msg.mediaUrl}
                      download={msg.mediaName}
                      target="_blank"
                      rel="noreferrer"
                      className={`flex items-center gap-2.5 px-4 py-3 rounded-2xl max-w-[220px] ${
                        isMe ? 'text-white rounded-br-sm' : 'bg-white shadow-sm rounded-bl-sm text-gray-800'
                      }`}
                      style={isMe ? { background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' } : {}}
                    >
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${isMe ? 'bg-white/20' : 'bg-rose-50'}`}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={isMe ? 'white' : '#ff4d6d'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
                        </svg>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={`text-xs font-semibold truncate ${isMe ? 'text-white' : 'text-gray-800'}`}>{msg.mediaName || 'File'}</p>
                        {msg.mediaSize && <p className={`text-[10px] ${isMe ? 'text-white/70' : 'text-gray-400'}`}>{(msg.mediaSize / 1024).toFixed(0)} KB</p>}
                      </div>
                    </a>
                  )}

                  {/* Emoji reaction */}
                  {msg.emoji && (
                    <div className={`mt-0.5 ${isMe ? 'text-right' : 'text-left'}`}>
                      <span className="text-base">{msg.emoji}</span>
                    </div>
                  )}

                  {/* Time + status */}
                  <div className={`flex items-center gap-1 mt-0.5 ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <span className="text-[10px] text-gray-400">{msg.time}</span>
                    {isMe && <MessageStatusIcon status={msg.status} />}
                  </div>
                </div>
              </div>
            </div>
          )
        })}

        {/* Typing indicator */}
        {isOtherTyping && <TypingIndicator avatar={match.avatar} name={match.name} />}

        <div ref={messagesEndRef} className="h-2" />
      </div>

      {/* ── REPLY STRIP ── */}
      {replyTo && (
        <div className="flex-shrink-0 px-4 py-2" style={{ background: 'var(--color-surface)', borderTop: '1px solid var(--color-border)' }}>
          <ReplyBanner replyTo={replyTo} onCancel={() => setReplyTo(null)} />
        </div>
      )}

      {/* ── RECORDING UI ── */}
      {(voice.isRecording || voice.recording) && (
        <div className="flex-shrink-0 px-4 py-3" style={{ background: 'var(--color-surface)', borderTop: '1px solid var(--color-border)' }}>
          {voice.isRecording ? (
            <div className="flex items-center gap-3">
              {/* Cancel */}
              <button onClick={voice.cancelRecording} className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 active:scale-90 transition-transform flex-shrink-0">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
              {/* Live waveform */}
              <div className="flex-1 overflow-hidden">
                <LiveWaveform waveform={voice.waveform} />
              </div>
              {/* Timer */}
              <span className="text-sm font-bold text-[#ff4d6d] flex-shrink-0">{fmtDuration(voice.duration)}</span>
              {/* Stop button */}
              <button
                onClick={voice.stopRecording}
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 active:scale-90 transition-transform"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="white">
                  <rect x="6" y="6" width="12" height="12" rx="2"/>
                </svg>
              </button>
            </div>
          ) : voice.recording ? (
            /* Preview before send */
            <div className="flex items-center gap-3">
              <button onClick={voice.cancelRecording} className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 active:scale-90 transition-transform flex-shrink-0">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
              <div className="flex-1">
                <VoiceMessageBubble url={voice.recording.url} duration={voice.recording.duration} waveform={voice.recording.waveform} isMe={true} />
              </div>
              <button
                onClick={handleSendVoice}
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 active:scale-90 transition-transform"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              </button>
            </div>
          ) : null}
        </div>
      )}

      {/* ── INPUT BAR ── */}
      {!voice.isRecording && !voice.recording && (
        <div className="flex-shrink-0" style={{ background: 'var(--color-surface)', borderTop: '1px solid var(--color-border)' }}>
          {/* Emoji picker */}
          {showEmoji && (
            <div className="px-4 pt-2">
              <EmojiPicker onSelect={insertEmoji} />
            </div>
          )}

          <div className="flex items-end gap-2 px-3 py-2.5">
            {/* Emoji toggle */}
            <button
              onClick={e => { e.stopPropagation(); setShowEmoji(v => !v) }}
              className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${showEmoji ? 'bg-rose-100 text-[#ff4d6d]' : 'bg-gray-100 text-gray-500'}`}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>
              </svg>
            </button>

            {/* Text input */}
            <div className="flex-1 flex items-end rounded-3xl px-4 py-2 gap-2 min-h-[42px]" style={{ background: 'var(--color-input-bg)', border: '1px solid var(--color-input-border)' }}>
              <input
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSendText()}
                placeholder="Type a message…"
                disabled={false}
                className="flex-1 bg-transparent text-sm outline-none text-gray-800 placeholder-gray-400 disabled:opacity-50 leading-normal"
              />
              {/* Attach */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="text-gray-400 flex-shrink-0 active:scale-90 transition-transform"
                disabled={!canSend}
              >
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>
                </svg>
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
              className="hidden"
              onChange={handleFilePick}
              capture="environment"
            />

            {/* Send or mic */}
            {input.trim() ? (
              <button
                onClick={handleSendText}
                disabled={!canSend}
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 active:scale-90 transition-transform disabled:opacity-40"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
              </button>
            ) : (
              <button
                onMouseDown={() => !voice.isRecording && canSend && voice.startRecording()}
                onTouchStart={() => !voice.isRecording && canSend && voice.startRecording()}
                onMouseUp={() => voice.isRecording && voice.stopRecording()}
                onTouchEnd={() => voice.isRecording && voice.stopRecording()}
                disabled={!canSend}
                className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 active:scale-90 transition-transform disabled:opacity-40 ${
                  voice.isRecording ? 'animate-pulse' : ''
                }`}
                style={{ background: voice.isRecording ? '#dc2626' : 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
                title="Hold to record voice note"
              >
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>
                </svg>
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── LONG-PRESS CONTEXT MENU ── */}
      {longPressMsg && (
        <div
          className="absolute inset-0 flex items-center justify-center z-50"
          onClick={() => setLongPressMsg(null)}
        >
          <div className="bg-white rounded-2xl shadow-2xl border border-gray-100 overflow-hidden w-52" onClick={e => e.stopPropagation()}>
            {/* Quick reactions */}
            <div className="px-3 py-2.5 border-b border-gray-100">
              <QuickReactions onSelect={_emoji => {
                setLongPressMsg(null)
              }} />
            </div>
            <ActionBtn icon="↩️" label="Reply" onClick={() => handleReply(longPressMsg)} />
            {longPressMsg.senderId === 'me' && (
              <ActionBtn icon="🗑️" label="Delete" danger onClick={() => handleDelete(longPressMsg.id)} />
            )}
            <ActionBtn icon="📋" label="Copy text" onClick={() => {
              if (longPressMsg.text) navigator.clipboard.writeText(longPressMsg.text).catch(() => {})
              setLongPressMsg(null)
            }} />
            <ActionBtn icon="✖️" label="Cancel" onClick={() => setLongPressMsg(null)} />
          </div>
        </div>
      )}

      {/* ── FULLSCREEN IMAGE ── */}
      {expandedImage && (
        <FullscreenMedia url={expandedImage} onClose={() => setExpandedImage(null)} />
      )}

      {/* ── BLOCKED BANNER ── */}
      {blocked && (
        <div className="absolute inset-x-0 bottom-16 mx-4 bg-red-50 border border-red-200 rounded-2xl px-4 py-3 z-20 flex items-center gap-3">
          <span className="text-xl">🚫</span>
          <p className="text-sm text-red-700 font-medium flex-1">You have blocked {match.name}. Unblock to send messages.</p>
          <button onClick={() => setChatMenu('options')} className="text-xs font-bold text-red-600 underline">Manage</button>
        </div>
      )}

      {/* ── AI MODERATION WARNING ── */}
      {modWarning && (
        <ModerationWarning
          reason={modWarning.reason}
          severity={modWarning.severity}
          onSendAnyway={() => {
            sendText(modWarning.pendingText, replyTo ?? undefined)
            setInput('')
            setReplyTo(null)
            setModWarning(null)
          }}
          onCancel={() => setModWarning(null)}
        />
      )}

      {/* ── CHAT USER OPTIONS ── */}
      {chatMenu === 'options' && (
        <UserOptionsSheet
          user={matchUser}
          isBlocked={blocked}
          onBlock={() => setChatMenu('block')}
          onReport={() => setChatMenu('report')}
          onClose={() => setChatMenu('none')}
        />
      )}

      {/* ── BLOCK CONFIRM ── */}
      {chatMenu === 'block' && (
        <BlockConfirmSheet
          user={matchUser}
          onBlock={() => { blockUser(matchUser); setChatMenu('none') }}
          onClose={() => setChatMenu('none')}
        />
      )}

      {/* ── REPORT FLOW ── */}
      {chatMenu === 'report' && (
        <ReportFlow
          user={matchUser}
          onSubmit={(reason, detail) => { submitReport(matchUser, reason, detail); setChatMenu('none') }}
          onClose={() => setChatMenu('none')}
        />
      )}

      {/* ── VIP CALL PROMPT ── */}
      {showCallVipPrompt && (
        <div className="absolute inset-0 z-[90] flex flex-col justify-end bg-black/50 animate-slide-up">
          <div className="bg-white rounded-t-3xl px-5 pt-4 pb-10">
            {/* Handle */}
            <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-4" />

            {/* Icon + title */}
            <div className="flex flex-col items-center text-center mb-6">
              <div
                className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-4 shadow-xl shadow-amber-200"
                style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
              >
                {showCallVipPrompt === 'video' ? '🎥' : '📞'}
              </div>
              <h3 className="font-black text-gray-900 text-xl mb-1">
                {showCallVipPrompt === 'video' ? 'HD Video Calls' : 'Private Voice Calls'}
              </h3>
              <p className="text-gray-500 text-sm leading-relaxed max-w-xs">
                {showCallVipPrompt === 'video'
                  ? 'Face-to-face video calls with your matches — exclusively for VIP members.'
                  : 'Private voice calls with your matches — exclusively for VIP members.'}
              </p>
            </div>

            {/* Feature list */}
            <div className="bg-amber-50 rounded-2xl p-4 mb-5 space-y-2">
              {(showCallVipPrompt === 'video'
                ? ['🎥 HD 1-on-1 video calls', '🔄 Front & back camera switch', '📵 Camera on/off toggle', '😊 Send reactions during call', '🔒 End-to-end encrypted']
                : ['📞 Crystal clear voice calls', '🔇 Mute / unmute anytime', '🔊 Earpiece or speaker mode', '😊 Send reactions during call', '🔒 End-to-end encrypted']
              ).map(f => (
                <div key={f} className="flex items-center gap-2">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 6 9 17 4 12"/>
                  </svg>
                  <span className="text-sm text-amber-900 font-medium">{f}</span>
                </div>
              ))}
            </div>

            {/* CTA */}
            <button
              onClick={() => setShowCallVipPrompt(null)}
              className="w-full py-4 rounded-2xl text-white font-black text-base active:scale-[0.98] transition-transform shadow-xl shadow-amber-200 mb-2"
              style={{ background: 'linear-gradient(135deg,#f59e0b,#fbbf24)' }}
              // In real app: open VipModal
            >
              👑 Upgrade to VIP — From $5/mo
            </button>
            <button
              onClick={() => setShowCallVipPrompt(null)}
              className="w-full py-3 text-gray-400 text-sm font-semibold"
            >
              Maybe later
            </button>
          </div>
        </div>
      )}

      {/* ── MATCH PROFILE VIEWER ── */}
      {showMatchProfile && (
        <UserProfileView
          user={
            getRichProfile(match.name, { id: match.id, name: match.name, avatar: match.avatar, isVip: match.isVip, isOnline: match.isOnline })
            ?? { id: match.id, name: match.name, avatar: match.avatar, isVip: match.isVip, isOnline: match.isOnline }
          }
          onClose={() => setShowMatchProfile(false)}
        />
      )}

      {/* ── WALLPAPER PICKER ── */}
      {showWallpaperPicker && (
        <WallpaperPicker
          matchName={match.name}
          currentId={wallpaperId}
          currentCustomUrl={wallpaperCustomUrl}
          onSelect={applyWallpaper}
          onClose={() => setShowWallpaperPicker(false)}
        />
      )}
    </div>
  )
}

function ActionBtn({ icon, label, onClick, danger }: { icon: string; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-4 py-3 text-sm transition-colors ${
        danger ? 'text-red-500 hover:bg-red-50' : 'text-gray-700 hover:bg-gray-50'
      }`}
    >
      <span>{icon}</span>
      <span className="font-medium">{label}</span>
    </button>
  )
}
