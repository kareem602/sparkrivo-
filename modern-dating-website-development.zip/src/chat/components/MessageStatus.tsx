import type { MessageStatus as MsgStatus } from '../types'

export function MessageStatusIcon({ status }: { status: MsgStatus }) {
  if (status === 'sending') {
    return (
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="animate-spin">
        <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
      </svg>
    )
  }
  if (status === 'sent') {
    return (
      <svg width="14" height="10" viewBox="0 0 24 18" fill="none" stroke="#9ca3af" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="2 9 8 15 22 2"/>
      </svg>
    )
  }
  // seen — double blue ticks
  return (
    <svg width="18" height="10" viewBox="0 0 30 14" fill="none" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="1 7 7 13 18 1"/>
      <polyline points="11 7 17 13 28 1"/>
    </svg>
  )
}
