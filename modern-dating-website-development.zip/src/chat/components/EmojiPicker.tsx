const EMOJIS = [
  '😊','😂','🥰','😍','🤩','😘','😁','🤗',
  '❤️','🧡','💛','💚','💙','💜','🖤','🤍',
  '🔥','✨','🌸','💫','⭐','🎉','🎊','🥳',
  '👍','👏','🙌','💪','🫶','🤝','🙏','💯',
  '😭','😢','😤','😱','🤯','😎','🥺','😴',
  '🍕','🎶','🌹','🦋','🌈','🏖️','🎯','💎',
]

interface Props {
  onSelect: (emoji: string) => void
}

export function EmojiPicker({ onSelect }: Props) {
  return (
    <div className="bg-white rounded-2xl shadow-xl border border-gray-100 p-3 w-[260px]">
      <div className="grid grid-cols-8 gap-1">
        {EMOJIS.map(e => (
          <button
            key={e}
            onClick={() => onSelect(e)}
            className="text-xl w-8 h-8 flex items-center justify-center rounded-lg hover:bg-rose-50 active:scale-90 transition-transform"
          >
            {e}
          </button>
        ))}
      </div>
    </div>
  )
}

// Quick reaction row for long-press
export const QUICK_REACTIONS = ['❤️','😂','😮','😢','😡','👍']

interface QuickProps {
  onSelect: (emoji: string) => void
}

export function QuickReactions({ onSelect }: QuickProps) {
  return (
    <div className="flex items-center gap-1.5 bg-white rounded-full shadow-xl border border-gray-100 px-3 py-2">
      {QUICK_REACTIONS.map(e => (
        <button
          key={e}
          onClick={() => onSelect(e)}
          className="text-xl active:scale-90 transition-transform"
        >
          {e}
        </button>
      ))}
    </div>
  )
}
