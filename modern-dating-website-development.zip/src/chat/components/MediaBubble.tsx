import { useState, useRef } from 'react'

interface Props {
  url: string
  type: 'image' | 'video'
  isMe: boolean
  uploadProgress?: number
  onExpand?: (url: string) => void
}

export function MediaBubble({ url, type, isMe, uploadProgress, onExpand }: Props) {
  const [videoPlaying, setVideoPlaying] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const uploading = uploadProgress !== undefined && uploadProgress < 100

  const toggleVideo = () => {
    if (!videoRef.current) return
    if (videoPlaying) {
      videoRef.current.pause()
      setVideoPlaying(false)
    } else {
      videoRef.current.play().catch(() => {})
      setVideoPlaying(true)
    }
  }

  return (
    <div
      className={`relative rounded-2xl overflow-hidden max-w-[230px] ${
        isMe ? 'rounded-br-sm' : 'rounded-bl-sm'
      }`}
      style={{ aspectRatio: '4/3' }}
    >
      {type === 'image' ? (
        <img
          src={url}
          alt="media"
          className="w-full h-full object-cover cursor-pointer"
          onClick={() => onExpand?.(url)}
          loading="lazy"
        />
      ) : (
        <div className="relative w-full h-full bg-black cursor-pointer" onClick={toggleVideo}>
          <video
            ref={videoRef}
            src={url}
            className="w-full h-full object-contain"
            loop
            playsInline
            onPlay={() => setVideoPlaying(true)}
            onPause={() => setVideoPlaying(false)}
          />
          {!videoPlaying && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/30">
              <div className="w-12 h-12 rounded-full bg-white/90 flex items-center justify-center shadow-lg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#ff4d6d" style={{ marginLeft: 2 }}>
                  <polygon points="5 3 19 12 5 21 5 3"/>
                </svg>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Upload progress overlay */}
      {uploading && (
        <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center gap-2">
          <div className="w-8 h-8 rounded-full border-[3px] border-white/30 border-t-white animate-spin" />
          <span className="text-white text-xs font-bold">{Math.round(uploadProgress!)}%</span>
        </div>
      )}

      {/* Expand tap for image */}
      {type === 'image' && !uploading && (
        <button
          onClick={() => onExpand?.(url)}
          className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/40 flex items-center justify-center"
        >
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round">
            <polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/>
            <line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/>
          </svg>
        </button>
      )}
    </div>
  )
}
