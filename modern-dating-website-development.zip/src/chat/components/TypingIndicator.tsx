interface Props {
  avatar: string
  name: string
}

export function TypingIndicator({ avatar, name }: Props) {
  return (
    <div className="flex items-end gap-2 px-4 py-1">
      <img src={avatar} alt={name} className="w-7 h-7 rounded-full object-cover flex-shrink-0" />
      <div className="bg-white rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm flex items-center gap-1">
        <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
        <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
        <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
      <span className="text-[10px] text-gray-400 pb-1">{name} is typing…</span>
    </div>
  )
}
