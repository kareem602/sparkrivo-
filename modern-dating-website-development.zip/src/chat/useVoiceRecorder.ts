import { useState, useRef, useCallback, useEffect } from 'react'

export interface VoiceRecording {
  blob: Blob
  url: string
  duration: number   // seconds
  waveform: number[] // 0-1 amplitudes
}

export function useVoiceRecorder() {
  const [isRecording, setIsRecording] = useState(false)
  const [duration, setDuration] = useState(0)
  const [waveform, setWaveform] = useState<number[]>([])
  const [recording, setRecording] = useState<VoiceRecording | null>(null)

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const analyserRef = useRef<AnalyserNode | null>(null)
  const animFrameRef = useRef<number | null>(null)
  const streamRef = useRef<MediaStream | null>(null)

  const stopAll = useCallback(() => {
    if (timerRef.current) clearInterval(timerRef.current)
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current)
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop())
  }, [])

  const startRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream

      // Set up analyser for waveform
      const ctx = new AudioContext()
      const source = ctx.createMediaStreamSource(stream)
      const analyser = ctx.createAnalyser()
      analyser.fftSize = 64
      source.connect(analyser)
      analyserRef.current = analyser

      const mr = new MediaRecorder(stream, {
        mimeType: MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
          ? 'audio/webm;codecs=opus'
          : 'audio/webm',
      })
      mediaRecorderRef.current = mr
      chunksRef.current = []

      mr.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data) }

      const capturedWaveform: number[] = []

      const tick = () => {
        if (!analyserRef.current) return
        const data = new Uint8Array(analyserRef.current.frequencyBinCount)
        analyserRef.current.getByteFrequencyData(data)
        const avg = Array.from(data).reduce((a, b) => a + b, 0) / data.length
        capturedWaveform.push(Math.min(1, avg / 128))
        setWaveform([...capturedWaveform])
        animFrameRef.current = requestAnimationFrame(tick)
      }

      mr.start(100)
      setIsRecording(true)
      setDuration(0)
      setRecording(null)

      timerRef.current = setInterval(() => setDuration(d => d + 1), 1000)
      animFrameRef.current = requestAnimationFrame(tick)

      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: mr.mimeType })
        const url = URL.createObjectURL(blob)
        // Pad waveform to at least 30 bars
        while (capturedWaveform.length < 30) capturedWaveform.push(0.15 + Math.random() * 0.3)
        const finalWaveform = capturedWaveform.slice(-60) // max 60 bars
        setRecording({ blob, url, duration: capturedWaveform.length / 10, waveform: finalWaveform })
        setWaveform(finalWaveform)
        ctx.close()
      }
    } catch {
      alert('Microphone access denied. Please allow mic permissions.')
    }
  }, [])

  const stopRecording = useCallback(() => {
    stopAll()
    setIsRecording(false)
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      mediaRecorderRef.current.stop()
    }
  }, [stopAll])

  const cancelRecording = useCallback(() => {
    stopAll()
    setIsRecording(false)
    setDuration(0)
    setWaveform([])
    setRecording(null)
    chunksRef.current = []
  }, [stopAll])

  const clearRecording = useCallback(() => {
    setRecording(null)
    setDuration(0)
    setWaveform([])
  }, [])

  useEffect(() => () => stopAll(), [stopAll])

  return {
    isRecording,
    duration,
    waveform,
    recording,
    startRecording,
    stopRecording,
    cancelRecording,
    clearRecording,
  }
}
