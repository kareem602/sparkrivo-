import { useState, useCallback, useRef, useEffect } from 'react'
import {
  type CallType, type CallSession, type CallParticipant,
  ringtoneEngine, getLocalStream, stopStream, switchCamera, simulateNetworkQuality,
} from './callEngine'

const EMPTY_SESSION = (): CallSession => ({
  id: '',
  type: 'voice',
  state: 'idle',
  participant: { id: '', name: '', avatar: '' },
  startedAt: null,
  localStream: null,
  remoteStream: null,
  isMuted: false,
  isCameraOff: false,
  isSpeakerOn: false,
  isFrontCamera: true,
  networkQuality: 'excellent',
})

export type CallReaction = { id: string; emoji: string; at: number }

export function useCallStore() {
  const [session, setSession] = useState<CallSession>(EMPTY_SESSION)
  const [callDuration, setCallDuration] = useState(0)
  const [reactions, setReactions] = useState<CallReaction[]>([])
  const [missedCalls, setMissedCalls] = useState<Array<{ participant: CallParticipant; type: CallType; at: number }>>([])
  const [incomingCall, setIncomingCall] = useState<{ participant: CallParticipant; type: CallType } | null>(null)

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const networkRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const simulatedAnswerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  // ── Duration timer ──────────────────────────────────────────
  const startTimer = useCallback(() => {
    timerRef.current = setInterval(() => setCallDuration(d => d + 1), 1000)
  }, [])

  const stopTimer = useCallback(() => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null }
    setCallDuration(0)
  }, [])

  // ── Network quality simulator ───────────────────────────────
  const startNetworkSim = useCallback(() => {
    networkRef.current = setInterval(() => {
      setSession(s => ({ ...s, networkQuality: simulateNetworkQuality() }))
    }, 4000)
  }, [])

  const stopNetworkSim = useCallback(() => {
    if (networkRef.current) { clearInterval(networkRef.current); networkRef.current = null }
  }, [])

  // ── Start outgoing call ─────────────────────────────────────
  const startCall = useCallback(async (participant: CallParticipant, type: CallType) => {
    ringtoneEngine.resume()
    const stream = await getLocalStream(type === 'video')

    const newSession: CallSession = {
      ...EMPTY_SESSION(),
      id: `call-${Date.now()}`,
      type,
      state: 'calling',
      participant,
      localStream: stream,
    }
    setSession(newSession)

    // Simulate remote answer after 2–5 seconds
    const delay = 2000 + Math.random() * 3000
    const declined = Math.random() < 0.15  // 15% chance of decline

    simulatedAnswerRef.current = setTimeout(() => {
      if (declined) {
        ringtoneEngine.playEndCall()
        setSession(s => ({ ...s, state: 'declined' }))
        stopStream(stream)
        setTimeout(() => setSession(EMPTY_SESSION), 3000)
      } else {
        ringtoneEngine.playConnected()
        setSession(s => ({
          ...s,
          state: 'connected',
          startedAt: Date.now(),
          networkQuality: 'excellent',
        }))
        startTimer()
        startNetworkSim()
      }
    }, delay)
  }, [startTimer, startNetworkSim])

  // ── Simulate incoming call ──────────────────────────────────
  const simulateIncomingCall = useCallback((participant: CallParticipant, type: CallType) => {
    setIncomingCall({ participant, type })
    ringtoneEngine.startRinging()
  }, [])

  // ── Accept incoming call ────────────────────────────────────
  const acceptCall = useCallback(async () => {
    if (!incomingCall) return
    ringtoneEngine.stopRinging()
    ringtoneEngine.playConnected()
    const stream = await getLocalStream(incomingCall.type === 'video')
    setSession({
      ...EMPTY_SESSION(),
      id: `call-${Date.now()}`,
      type: incomingCall.type,
      state: 'connected',
      participant: incomingCall.participant,
      startedAt: Date.now(),
      localStream: stream,
      networkQuality: 'excellent',
    })
    setIncomingCall(null)
    startTimer()
    startNetworkSim()
  }, [incomingCall, startTimer, startNetworkSim])

  // ── Decline incoming call ───────────────────────────────────
  const declineCall = useCallback(() => {
    if (!incomingCall) return
    ringtoneEngine.stopRinging()
    setMissedCalls(prev => [{
      participant: incomingCall.participant,
      type: incomingCall.type,
      at: Date.now(),
    }, ...prev])
    setIncomingCall(null)
  }, [incomingCall])

  // ── End call ────────────────────────────────────────────────
  const endCall = useCallback(() => {
    ringtoneEngine.stopRinging()
    ringtoneEngine.playEndCall()
    stopTimer()
    stopNetworkSim()
    if (simulatedAnswerRef.current) clearTimeout(simulatedAnswerRef.current)
    setSession(s => {
      stopStream(s.localStream)
      stopStream(s.remoteStream)
      return { ...s, state: 'ended', localStream: null, remoteStream: null }
    })
    setTimeout(() => setSession(EMPTY_SESSION), 2200)
  }, [stopTimer, stopNetworkSim])

  // ── Toggle mute ─────────────────────────────────────────────
  const toggleMute = useCallback(() => {
    setSession(s => {
      s.localStream?.getAudioTracks().forEach(t => { t.enabled = s.isMuted })
      return { ...s, isMuted: !s.isMuted }
    })
  }, [])

  // ── Toggle camera ───────────────────────────────────────────
  const toggleCamera = useCallback(() => {
    setSession(s => {
      s.localStream?.getVideoTracks().forEach(t => { t.enabled = s.isCameraOff })
      return { ...s, isCameraOff: !s.isCameraOff }
    })
  }, [])

  // ── Switch camera ───────────────────────────────────────────
  const flipCamera = useCallback(async () => {
    const { localStream } = session
    if (!localStream) return
    const newStream = await switchCamera(localStream)
    if (newStream) {
      stopStream(localStream)
      setSession(s => ({ ...s, localStream: newStream, isFrontCamera: !s.isFrontCamera }))
    }
  }, [session])

  // ── Toggle speaker ──────────────────────────────────────────
  const toggleSpeaker = useCallback(() => {
    setSession(s => ({ ...s, isSpeakerOn: !s.isSpeakerOn }))
  }, [])

  // ── Send reaction ───────────────────────────────────────────
  const sendReaction = useCallback((emoji: string) => {
    const r: CallReaction = { id: `r-${Date.now()}`, emoji, at: Date.now() }
    setReactions(prev => [...prev, r])
    setTimeout(() => setReactions(prev => prev.filter(x => x.id !== r.id)), 3000)
  }, [])

  // Cleanup on unmount
  useEffect(() => () => {
    stopTimer()
    stopNetworkSim()
    if (simulatedAnswerRef.current) clearTimeout(simulatedAnswerRef.current)
    ringtoneEngine.stopRinging()
  }, [stopTimer, stopNetworkSim])

  return {
    session,
    callDuration,
    reactions,
    missedCalls,
    incomingCall,
    startCall,
    simulateIncomingCall,
    acceptCall,
    declineCall,
    endCall,
    toggleMute,
    toggleCamera,
    flipCamera,
    toggleSpeaker,
    sendReaction,
  }
}
