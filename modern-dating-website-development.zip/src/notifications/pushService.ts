// ─── Push Notification Service ───────────────────────────────
// Uses the Web Push / Notifications API for OS-level notifications
// that appear even when the tab is in background.

export type PushNotifPayload = {
  title: string
  body: string
  icon?: string
  badge?: string
  tag?: string       // collapses duplicate notifications
  data?: Record<string, string>
}

class PushService {
  private permission: NotificationPermission = 'default'
  private swRegistration: ServiceWorkerRegistration | null = null
  private supported = typeof window !== 'undefined' && 'Notification' in window

  async init(): Promise<void> {
    if (!this.supported) return
    this.permission = Notification.permission

    // Register our minimal SW (handles background push)
    if ('serviceWorker' in navigator) {
      try {
        const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' })
        this.swRegistration = reg
      } catch {
        // SW not available in some environments — graceful fallback
      }
    }
  }

  async requestPermission(): Promise<boolean> {
    if (!this.supported) return false
    try {
      const result = await Notification.requestPermission()
      this.permission = result
      return result === 'granted'
    } catch {
      return false
    }
  }

  isGranted() {
    return this.supported && this.permission === 'granted'
  }

  isSupported() {
    return this.supported
  }

  getPermission() {
    return this.supported ? Notification.permission : 'denied'
  }

  // Show an OS notification — works when tab is visible (fallback when hidden)
  async show(payload: PushNotifPayload): Promise<void> {
    if (!this.isGranted()) return

    const opts: NotificationOptions = {
      body: payload.body,
      icon: payload.icon ?? '/icon-192.png',
      badge: payload.badge ?? '/badge-72.png',
      tag: payload.tag,
      data: payload.data,
      silent: false,
    }

    // Prefer SW-based notification (works when tab hidden / closed)
    if (this.swRegistration) {
      try {
        await this.swRegistration.showNotification(payload.title, opts)
        return
      } catch {}
    }

    // Fallback: basic Notification API
    try {
      new Notification(payload.title, opts)
    } catch {}
  }

  // Show only if the tab is hidden / document not focused
  async showIfHidden(payload: PushNotifPayload) {
    if (document.hidden || !document.hasFocus()) {
      await this.show(payload)
    }
  }
}

export const pushService = new PushService()
