import { useEffect, useState } from 'react'
import type { AppNotification } from '../data/mockData'

const TYPE_ICON: Record<string, string> = {
  match: '💕', like: '❤️', message: '💬',
  comment: '🗨️', superlike: '⭐', system: '🔔',
}
const TYPE_COLOR: Record<string, string> = {
  match: 'from-rose-500 to-pink-500',
  like: 'from-red-400 to-rose-500',
  message: 'from-violet-500 to-purple-500',
  comment: 'from-blue-400 to-indigo-500',
  superlike: 'from-amber-400 to-yellow-500',
  system: 'from-gray-500 to-gray-600',
}

interface Props {
  toast: AppNotification
  onDismiss: (id: string) => void
}

export function NotifToast({ toast, onDismiss }: Props) {
  const [visible, setVisible] = useState(false)
  const [leaving, setLeaving] = useState(false)

  useEffect(() => {
    // Animate in
    requestAnimationFrame(() => setVisible(true))
    // Auto dismiss after 3.5s
    const t = setTimeout(() => dismiss(), 3500)
    return () => clearTimeout(t)
  }, [])

  const dismiss = () => {
    setLeaving(true)
    setTimeout(() => onDismiss(toast.id), 320)
  }

  return (
    <div
      onClick={dismiss}
      className="w-full cursor-pointer"
      style={{
        transform: visible && !leaving ? 'translateY(0) scale(1)' : 'translateY(-110%) scale(0.92)',
        opacity: visible && !leaving ? 1 : 0,
        transition: 'all 0.32s cubic-bezier(0.34,1.3,0.64,1)',
      }}
    >
      <div className="mx-3 rounded-2xl overflow-hidden shadow-2xl shadow-black/20 flex items-stretch">
        {/* Gradient left bar */}
        <div className={`w-1.5 flex-shrink-0 bg-gradient-to-b ${TYPE_COLOR[toast.type] ?? TYPE_COLOR.system}`} />

        {/* Content */}
        <div className="flex-1 bg-white/95 backdrop-blur-lg px-3 py-3 flex items-center gap-3">
          {/* Avatar or icon */}
          <div className="relative flex-shrink-0">
            {toast.avatar ? (
              <img src={toast.avatar} alt="" className="w-10 h-10 rounded-full object-cover" />
            ) : (
              <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${TYPE_COLOR[toast.type]} flex items-center justify-center text-xl`}>
                {TYPE_ICON[toast.type]}
              </div>
            )}
            <span className="absolute -bottom-0.5 -right-0.5 text-[13px] leading-none">
              {TYPE_ICON[toast.type]}
            </span>
          </div>

          {/* Text */}
          <div className="flex-1 min-w-0">
            <p className="font-bold text-gray-900 text-[13px] leading-tight truncate">
              {toast.name}
            </p>
            <p className="text-gray-600 text-[12px] leading-tight mt-0.5 line-clamp-2">
              {toast.text}
            </p>
          </div>

          {/* Time */}
          <span className="flex-shrink-0 text-[10px] text-gray-400 self-start mt-0.5">now</span>
        </div>
      </div>
    </div>
  )
}

// Container that renders a stack of toasts
interface StackProps {
  toasts: AppNotification[]
  onDismiss: (id: string) => void
}

export function ToastStack({ toasts, onDismiss }: StackProps) {
  if (toasts.length === 0) return null
  return (
    <div
      className="absolute top-0 left-0 right-0 z-[200] pt-2 flex flex-col gap-2 pointer-events-none"
      style={{ pointerEvents: 'none' }}
    >
      {toasts.slice(-3).map(t => (
        <div key={t.id} style={{ pointerEvents: 'all' }}>
          <NotifToast toast={t} onDismiss={onDismiss} />
        </div>
      ))}
    </div>
  )
}
