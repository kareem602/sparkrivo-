// ─── Notification Sound Engine ───────────────────────────────
// Generates all sounds via Web Audio API — no external files needed.

export type SoundStyle = 'default' | 'soft' | 'loud' | 'silent'

class SoundEngine {
  private ctx: AudioContext | null = null
  private enabled = true
  private style: SoundStyle = 'default'
  private vibrationEnabled = true

  private getCtx(): AudioContext {
    if (!this.ctx || this.ctx.state === 'closed') {
      this.ctx = new AudioContext()
    }
    return this.ctx
  }

  setEnabled(v: boolean) { this.enabled = v }
  setStyle(s: SoundStyle) { this.style = s }
  setVibration(v: boolean) { this.vibrationEnabled = v }
  isEnabled() { return this.enabled }
  getStyle() { return this.style }
  isVibrationEnabled() { return this.vibrationEnabled }

  private gain(): number {
    switch (this.style) {
      case 'soft':   return 0.15
      case 'loud':   return 0.9
      case 'silent': return 0
      default:       return 0.45
    }
  }

  private vibrate(pattern: number[]) {
    if (this.vibrationEnabled && 'vibrate' in navigator) {
      try { navigator.vibrate(pattern) } catch {}
    }
  }

  // Short 2-oscillator "pop" — messages
  playMessage() {
    if (!this.enabled || this.style === 'silent') return
    try {
      const ctx = this.getCtx()
      const g = ctx.createGain()
      g.gain.setValueAtTime(this.gain(), ctx.currentTime)
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18)
      g.connect(ctx.destination)

      const o1 = ctx.createOscillator()
      o1.type = 'sine'
      o1.frequency.setValueAtTime(880, ctx.currentTime)
      o1.frequency.exponentialRampToValueAtTime(660, ctx.currentTime + 0.15)
      o1.connect(g)
      o1.start(ctx.currentTime)
      o1.stop(ctx.currentTime + 0.18)

      this.vibrate([30])
    } catch {}
  }

  // Rising arpeggio "ding-ding" — matches
  playMatch() {
    if (!this.enabled || this.style === 'silent') return
    try {
      const ctx = this.getCtx()
      const notes = [523, 659, 784, 1047]
      notes.forEach((freq, i) => {
        const g = ctx.createGain()
        const t = ctx.currentTime + i * 0.12
        g.gain.setValueAtTime(0, t)
        g.gain.linearRampToValueAtTime(this.gain(), t + 0.03)
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.35)
        g.connect(ctx.destination)

        const o = ctx.createOscillator()
        o.type = 'triangle'
        o.frequency.value = freq
        o.connect(g)
        o.start(t)
        o.stop(t + 0.35)
      })

      this.vibrate([50, 50, 50, 100])
    } catch {}
  }

  // Light single tick — likes
  playLike() {
    if (!this.enabled || this.style === 'silent') return
    try {
      const ctx = this.getCtx()
      const g = ctx.createGain()
      g.gain.setValueAtTime(this.gain() * 0.7, ctx.currentTime)
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12)
      g.connect(ctx.destination)

      const o = ctx.createOscillator()
      o.type = 'sine'
      o.frequency.setValueAtTime(1200, ctx.currentTime)
      o.connect(g)
      o.start(ctx.currentTime)
      o.stop(ctx.currentTime + 0.12)

      this.vibrate([20])
    } catch {}
  }

  // Two-tone ping — voice notes
  playVoiceNote() {
    if (!this.enabled || this.style === 'silent') return
    try {
      const ctx = this.getCtx()
      ;[440, 550].forEach((freq, i) => {
        const g = ctx.createGain()
        const t = ctx.currentTime + i * 0.09
        g.gain.setValueAtTime(this.gain(), t)
        g.gain.exponentialRampToValueAtTime(0.001, t + 0.22)
        g.connect(ctx.destination)

        const o = ctx.createOscillator()
        o.type = 'sine'
        o.frequency.value = freq
        o.connect(g)
        o.start(t)
        o.stop(t + 0.22)
      })
      this.vibrate([40, 30])
    } catch {}
  }

  // Short blip — story view / follow
  playGeneral() {
    if (!this.enabled || this.style === 'silent') return
    try {
      const ctx = this.getCtx()
      const g = ctx.createGain()
      g.gain.setValueAtTime(this.gain() * 0.5, ctx.currentTime)
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1)
      g.connect(ctx.destination)

      const o = ctx.createOscillator()
      o.type = 'sine'
      o.frequency.value = 740
      o.connect(g)
      o.start(ctx.currentTime)
      o.stop(ctx.currentTime + 0.1)
    } catch {}
  }

  // Resume audio context after user gesture (browser policy)
  async resume() {
    try {
      if (this.ctx && this.ctx.state === 'suspended') {
        await this.ctx.resume()
      }
    } catch {}
  }
}

export const soundEngine = new SoundEngine()
