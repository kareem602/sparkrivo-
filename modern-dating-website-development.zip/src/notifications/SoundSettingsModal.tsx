import { useState } from 'react'
import type { SoundSettings } from './useNotificationStore'
import type { SoundStyle } from './sounds'
import { soundEngine } from './sounds'

interface Props {
  settings: SoundSettings
  pushPermission: string
  onUpdate: (patch: Partial<SoundSettings>) => void
  onRequestPush: () => Promise<boolean>
  onClose: () => void
}

const STYLES: { id: SoundStyle; label: string; desc: string; emoji: string }[] = [
  { id: 'default', label: 'Default',  desc: 'Balanced tones for all alerts',   emoji: '🔔' },
  { id: 'soft',    label: 'Soft',     desc: 'Gentle, barely-there sounds',     emoji: '🍃' },
  { id: 'loud',    label: 'Loud',     desc: 'Bold sounds, hard to miss',       emoji: '📢' },
  { id: 'silent',  label: 'Silent',   desc: 'No sounds — dots & banners only', emoji: '🔕' },
]

const PREVIEWS: { label: string; fn: () => void; emoji: string }[] = [
  { label: 'Message',   fn: () => soundEngine.playMessage(),   emoji: '💬' },
  { label: 'Match',     fn: () => soundEngine.playMatch(),     emoji: '💕' },
  { label: 'Like',      fn: () => soundEngine.playLike(),      emoji: '❤️' },
  { label: 'Voice note',fn: () => soundEngine.playVoiceNote(), emoji: '🎤' },
]

export function SoundSettingsModal({ settings, pushPermission, onUpdate, onRequestPush, onClose }: Props) {
  const [requesting, setRequesting] = useState(false)

  const handlePreview = (fn: () => void) => {
    soundEngine.resume()
    fn()
  }

  const handleRequestPush = async () => {
    setRequesting(true)
    await onRequestPush()
    setRequesting(false)
  }

  return (
    <div className="absolute inset-0 z-[300] flex flex-col bg-white animate-slide-up">
      {/* Header */}
      <div className="flex-shrink-0 flex items-center gap-3 px-4 py-4 border-b border-gray-100">
        <button
          onClick={onClose}
          className="p-1.5 -ml-1.5 rounded-full hover:bg-gray-100 active:scale-90 transition-transform"
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#374151" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6"/>
          </svg>
        </button>
        <div>
          <h2 className="text-xl font-bold text-gray-900">Notification Settings</h2>
          <p className="text-xs text-gray-400 mt-0.5">Sounds, push, and badge preferences</p>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">

        {/* ── Master sound toggle ── */}
        <section>
          <div className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-2xl">
            <div className="flex items-center gap-3">
              <span className="text-2xl">{settings.enabled ? '🔊' : '🔇'}</span>
              <div>
                <p className="font-bold text-gray-900 text-sm">Notification Sounds</p>
                <p className="text-xs text-gray-500">Play audio when events arrive</p>
              </div>
            </div>
            <Toggle
              value={settings.enabled}
              onChange={v => onUpdate({ enabled: v })}
            />
          </div>
        </section>

        {/* ── Sound style ── */}
        {settings.enabled && (
          <section>
            <h3 className="font-bold text-gray-700 text-sm mb-3 uppercase tracking-wide">Sound Style</h3>
            <div className="space-y-2">
              {STYLES.map(s => (
                <button
                  key={s.id}
                  onClick={() => onUpdate({ style: s.id })}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl border-2 transition-all active:scale-[0.98] ${
                    settings.style === s.id
                      ? 'border-[#ff4d6d] bg-rose-50'
                      : 'border-gray-100 bg-gray-50 hover:border-gray-200'
                  }`}
                >
                  <span className="text-xl">{s.emoji}</span>
                  <div className="flex-1 text-left">
                    <p className={`font-bold text-sm ${settings.style === s.id ? 'text-[#ff4d6d]' : 'text-gray-800'}`}>
                      {s.label}
                    </p>
                    <p className="text-xs text-gray-400">{s.desc}</p>
                  </div>
                  {settings.style === s.id && (
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ff4d6d" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                      <polyline points="20 6 9 17 4 12"/>
                    </svg>
                  )}
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ── Preview sounds ── */}
        {settings.enabled && settings.style !== 'silent' && (
          <section>
            <h3 className="font-bold text-gray-700 text-sm mb-3 uppercase tracking-wide">Preview Sounds</h3>
            <div className="grid grid-cols-2 gap-2">
              {PREVIEWS.map(p => (
                <button
                  key={p.label}
                  onClick={() => handlePreview(p.fn)}
                  className="flex items-center gap-2 px-3 py-3 bg-gray-50 rounded-2xl border border-gray-100 hover:border-[#ff4d6d] hover:bg-rose-50 active:scale-95 transition-all"
                >
                  <span className="text-lg">{p.emoji}</span>
                  <span className="text-sm font-semibold text-gray-700">{p.label}</span>
                  <svg className="ml-auto" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polygon points="5 3 19 12 5 21 5 3"/>
                  </svg>
                </button>
              ))}
            </div>
          </section>
        )}

        {/* ── Vibration ── */}
        <section>
          <div className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-2xl">
            <div className="flex items-center gap-3">
              <span className="text-2xl">📳</span>
              <div>
                <p className="font-bold text-gray-900 text-sm">Vibration</p>
                <p className="text-xs text-gray-500">Haptic feedback on events</p>
              </div>
            </div>
            <Toggle
              value={settings.vibration}
              onChange={v => onUpdate({ vibration: v })}
            />
          </div>
        </section>

        {/* ── Push notifications ── */}
        <section>
          <h3 className="font-bold text-gray-700 text-sm mb-3 uppercase tracking-wide">Push Notifications</h3>
          <div className="px-4 py-4 bg-gray-50 rounded-2xl space-y-3">
            <div className="flex items-center gap-3">
              <span className="text-2xl">📡</span>
              <div className="flex-1">
                <p className="font-bold text-gray-900 text-sm">Background Push</p>
                <p className="text-xs text-gray-500">Receive alerts when the app is closed</p>
              </div>
              <StatusPill permission={pushPermission} />
            </div>

            {pushPermission !== 'granted' && (
              <button
                onClick={handleRequestPush}
                disabled={requesting || pushPermission === 'denied'}
                className="w-full py-3 rounded-xl text-white font-bold text-sm disabled:opacity-50 transition-opacity active:scale-95"
                style={{ background: pushPermission === 'denied' ? '#9ca3af' : 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                {requesting ? 'Requesting…' : pushPermission === 'denied' ? 'Blocked by browser — enable in site settings' : 'Enable Push Notifications'}
              </button>
            )}

            {pushPermission === 'granted' && (
              <div className="flex items-center gap-2 text-green-600 text-sm font-semibold">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
                Push notifications are active
              </div>
            )}
          </div>
        </section>

        {/* ── What you'll receive ── */}
        <section>
          <h3 className="font-bold text-gray-700 text-sm mb-3 uppercase tracking-wide">Alert Types</h3>
          <div className="space-y-1">
            {[
              ['💬', 'New messages', true],
              ['💕', 'New matches', true],
              ['❤️', 'Post likes', true],
              ['🎤', 'Voice notes', true],
              ['👀', 'Story views', true],
              ['⭐', 'Super likes', true],
              ['🗨️', 'Comments', true],
            ].map(([icon, label]) => (
              <div key={label as string} className="flex items-center justify-between py-2.5 px-4 rounded-xl hover:bg-gray-50">
                <div className="flex items-center gap-3">
                  <span className="text-lg">{icon}</span>
                  <span className="text-sm text-gray-700 font-medium">{label}</span>
                </div>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 6 9 17 4 12"/>
                </svg>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${value ? 'bg-[#ff4d6d]' : 'bg-gray-300'}`}
    >
      <div
        className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform duration-200 ${value ? 'translate-x-6' : 'translate-x-0.5'}`}
      />
    </button>
  )
}

function StatusPill({ permission }: { permission: string }) {
  const color =
    permission === 'granted' ? 'bg-green-100 text-green-700' :
    permission === 'denied' ? 'bg-red-100 text-red-600' :
    'bg-amber-100 text-amber-700'
  const label =
    permission === 'granted' ? 'Active' :
    permission === 'denied' ? 'Blocked' : 'Not asked'
  return (
    <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${color}`}>{label}</span>
  )
}
