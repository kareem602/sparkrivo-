import { useState } from 'react'
import { currentUser } from '../data/mockData'
import type { SoundSettings } from '../notifications/useNotificationStore'
import { SoundSettingsModal } from '../notifications/SoundSettingsModal'
import { pushService } from '../notifications/pushService'
import AvatarUploader from '../components/AvatarUploader'
import CoverUploader from '../components/CoverUploader'
import { usePrivacy } from '../privacy/PrivacyContext'
import { PrivacySettingsPanel } from '../privacy/PrivacySettings'
import { useVip } from '../vip/VipContext'
import { VipBadge, VipCountdownPill, BoostActivePill } from '../vip/VipBadge'
import VipModal from '../vip/VipModal'
import SubscriptionManager from '../vip/SubscriptionManager'
import { LegalHub } from '../legal/LegalPages'
import ThemeSettings from '../theme/ThemeSettings'

interface Props {
  onNotifOpen?: () => void
  soundSettings?: SoundSettings
  onUpdateSound?: (patch: Partial<SoundSettings>) => void
  onSignOut?: () => void
  isDark?: boolean
  onToggleTheme?: () => void
}

const INTERESTS_ALL = [
  'Travel ✈️', 'Music 🎵', 'Fitness 💪', 'Food 🍕', 'Movies 🎬', 'Art 🎨',
  'Reading 📚', 'Gaming 🎮', 'Cooking 🍳', 'Dancing 💃', 'Hiking 🏔️', 'Photography 📸',
]

export default function ProfilePage({ onNotifOpen, soundSettings, onUpdateSound, onSignOut, isDark = false, onToggleTheme }: Props) {
  const privacy = usePrivacy()
  const vip = useVip()
  const { isVip, daysLeft, activeBoost, boostMinutesLeft } = vip

  const [showPrivacyPanel, setShowPrivacyPanel] = useState(false)
  const [showSoundSettings, setShowSoundSettings] = useState(false)
  const [showVipModal, setShowVipModal] = useState(false)
  const [showSubManager, setShowSubManager] = useState(false)
  const [showLegal, setShowLegal] = useState(false)
  const [showTheme, setShowTheme] = useState(false)
  const [editMode, setEditMode] = useState(false)

  // Editable profile fields
  const [coverUrl, setCoverUrl] = useState<string | null>(null)
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatar)
  const [name, setName] = useState('Alex Johnson')
  const [username, setUsername] = useState('alexjohnson')
  const [age, setAge] = useState('24')
  const [location, setLocation] = useState('Lagos, Nigeria')
  const [bio, setBio] = useState('Finding my next adventure ✨')
  const [gender, setGender] = useState('Male')
  const [interests, setInterests] = useState(['Travel ✈️', 'Music 🎵', 'Fitness 💪', 'Food 🍕', 'Movies 🎬', 'Art 🎨'])

  // Username edit state
  const [showUsernameEditor, setShowUsernameEditor] = useState(false)
  const [draftUsername, setDraftUsername] = useState(username)
  const [usernameError, setUsernameError] = useState('')

  // Edit form draft state
  const [draftName, setDraftName] = useState(name)
  const [draftAge, setDraftAge] = useState(age)
  const [draftLocation, setDraftLocation] = useState(location)
  const [draftBio, setDraftBio] = useState(bio)
  const [draftGender, setDraftGender] = useState(gender)
  const [draftInterests, setDraftInterests] = useState(interests)

  const stats = [
    { label: 'Matches', value: '23' },
    { label: 'Likes',   value: '89' },
    { label: 'Views',   value: '1.2k' },
  ]

  const openEdit = () => {
    setDraftName(name)
    setDraftAge(age)
    setDraftLocation(location)
    setDraftBio(bio)
    setDraftGender(gender)
    setDraftInterests([...interests])
    setDraftUsername(username)
    setUsernameError('')
    setEditMode(true)
  }

  // Validate username — defined FIRST so all callers below can reference it
  const validateUsername = (val: string): string => {
    const clean = val.toLowerCase().replace(/[^a-z0-9._]/g, '')
    if (clean.length < 3) return 'Username must be at least 3 characters'
    if (clean.length > 30) return 'Username must be 30 characters or less'
    if (/^[._]/.test(clean) || /[._]$/.test(clean)) return 'Cannot start or end with . or _'
    if (/[._]{2}/.test(clean)) return 'Cannot have consecutive . or _'
    return ''
  }

  const saveEdit = () => {
    setName(draftName.trim() || name)
    setAge(draftAge.trim() || age)
    setLocation(draftLocation.trim() || location)
    setBio(draftBio.trim() || bio)
    setGender(draftGender)
    setInterests(draftInterests)
    // Save username if VIP and valid
    if (isVip && draftUsername && !validateUsername(draftUsername)) {
      setUsername(draftUsername)
    }
    setEditMode(false)
  }

  const handleUsernameSave = () => {
    const clean = draftUsername.toLowerCase().replace(/[^a-z0-9._]/g, '')
    const err = validateUsername(clean)
    if (err) { setUsernameError(err); return }
    setUsername(clean)
    setDraftUsername(clean)
    setUsernameError('')
    setShowUsernameEditor(false)
  }

  const toggleDraftInterest = (i: string) => {
    setDraftInterests(prev =>
      prev.includes(i) ? prev.filter(x => x !== i) : [...prev, i]
    )
  }

  return (
    <div className="flex flex-col h-full bg-white overflow-hidden relative">
      {/* ── Header ── */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
        <span className="text-[22px] font-bold text-[#ff4d6d]">Profile</span>
        <div className="flex items-center gap-1.5">
          <button
            onClick={openEdit}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500 active:scale-90 transition-transform"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          {/* Theme toggle */}
          <button
            onClick={() => onToggleTheme?.()}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 active:scale-90 transition-transform text-xl"
            title="Toggle dark/light mode"
          >
            {isDark ? '☀️' : '🌙'}
          </button>
          <button
            onClick={() => setShowSoundSettings(true)}
            className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500 active:scale-90 transition-transform"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3"/>
              <path d="M12 2v2m0 16v2M2 12h2m16 0h2M4.93 4.93l1.41 1.41m11.31 11.31 1.41 1.41M4.93 19.07l1.41-1.41m11.31-11.31 1.41-1.41"/>
            </svg>
          </button>
          {onNotifOpen && (
            <button onClick={onNotifOpen} className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500 active:scale-90 transition-transform">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* ── Scrollable body ── */}
      <div className="flex-1 overflow-y-auto">

          {/* ── Cover photo (full-width, no horizontal padding) ── */}
          <CoverUploader currentUrl={coverUrl} onUploaded={setCoverUrl} />

          {/* ── Avatar + name row (overlaps cover bottom) ── */}
          <div className="flex items-end gap-4 px-4 -mt-10 mb-2 relative z-10">
            {/* Avatar with camera badge */}
            <div className="flex flex-col items-center">
              <AvatarUploader
                currentUrl={avatarUrl}
                name={name}
                size={88}
                onUploaded={setAvatarUrl}
              />
            </div>

            {/* Name / location (right of avatar, padded from cover) */}
            <div className="flex-1 min-w-0 pb-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl font-black text-gray-900 truncate leading-tight">{name}</h2>
                {isVip && <VipBadge size="sm" animated />}
              </div>
              {/* Username — only shown if set, VIP can customise it */}
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-sm font-semibold text-[#ff4d6d]">@{username}</span>
                {isVip ? (
                  <button
                    onClick={() => { setDraftUsername(username); setUsernameError(''); setShowUsernameEditor(true) }}
                    className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-bold text-amber-700 active:scale-90 transition-transform"
                    style={{ background: 'linear-gradient(135deg,#fef3c7,#fde68a)' }}
                  >
                    <svg width="8" height="8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
                      <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
                    </svg>
                    Edit
                  </button>
                ) : (
                  <button
                    onClick={() => setShowVipModal(true)}
                    className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full text-[9px] font-bold text-gray-400 border border-dashed border-gray-300 active:scale-90 transition-transform"
                  >
                    🔒 VIP
                  </button>
                )}
              </div>
              <p className="text-sm text-gray-500 mt-0.5">📍 {location}</p>
              <p className="text-sm text-gray-500">🎂 {age} · {gender}</p>
            </div>
          </div>

        <div className="px-4 pb-5 space-y-5">

          {/* ── Stats ── */}
          <div className="grid grid-cols-3 gap-3">
            {stats.map(stat => (
              <div key={stat.label} className="bg-rose-50 rounded-2xl p-3 text-center">
                <p className="text-xl font-bold text-[#ff4d6d]">{stat.value}</p>
                <p className="text-xs text-gray-500 mt-0.5">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* ── Bio ── */}
          <div className="bg-gray-50 rounded-2xl p-4">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-gray-800 text-sm">About Me</h3>
              <button onClick={openEdit} className="text-[#ff4d6d] text-xs font-semibold">Edit</button>
            </div>
            <p className="text-sm text-gray-600 leading-relaxed">{bio}</p>
          </div>

          {/* ── Interests ── */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-gray-800 text-sm">Interests</h3>
              <button onClick={openEdit} className="text-[#ff4d6d] text-xs font-semibold">Edit</button>
            </div>
            <div className="flex flex-wrap gap-2">
              {interests.map(i => (
                <span key={i} className="px-3 py-1.5 bg-rose-50 text-[#ff4d6d] text-xs font-medium rounded-full border border-rose-100">{i}</span>
              ))}
            </div>
          </div>

          {/* ── Appearance ── */}
          <button
            onClick={() => setShowTheme(true)}
            className="w-full flex items-center gap-4 px-4 py-4 bg-gray-50 rounded-2xl active:scale-[0.98] transition-transform"
          >
            <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 text-xl" style={{ background: isDark ? '#1e1a2e' : '#f3e8ff' }}>
              {isDark ? '🌙' : '☀️'}
            </div>
            <div className="flex-1 text-left">
              <p className="font-bold text-gray-900 text-sm">Appearance</p>
              <p className="text-xs text-gray-400 mt-0.5">{isDark ? 'Dark mode' : 'Light mode'} · Tap to change</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </button>

          {/* ── Legal & Policies ── */}
          <button
            onClick={() => setShowLegal(true)}
            className="w-full flex items-center gap-4 px-4 py-4 bg-gray-50 rounded-2xl active:scale-[0.98] transition-transform"
          >
            <div className="w-11 h-11 rounded-xl bg-blue-100 flex items-center justify-center flex-shrink-0 text-xl">⚖️</div>
            <div className="flex-1 text-left">
              <p className="font-bold text-gray-900 text-sm">Legal & Policies</p>
              <p className="text-xs text-gray-400 mt-0.5">Terms · Privacy · Community Guidelines</p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </button>

          {/* ── Privacy & Safety ── */}
          <button
            onClick={() => setShowPrivacyPanel(true)}
            className="w-full flex items-center gap-4 px-4 py-4 bg-gray-50 rounded-2xl active:scale-[0.98] transition-transform"
          >
            <div className="w-11 h-11 rounded-xl bg-emerald-100 flex items-center justify-center flex-shrink-0">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10b981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
              </svg>
            </div>
            <div className="flex-1 text-left">
              <p className="font-bold text-gray-900 text-sm">Privacy & Safety</p>
              <p className="text-xs text-gray-400 mt-0.5">
                {privacy.settings.messagePerm === 'everyone' ? 'Messages from everyone' :
                 privacy.settings.messagePerm === 'matches' ? 'Matches only can message' :
                 'Messages blocked'} · {privacy.blockedUsers.length} blocked
              </p>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="9 18 15 12 9 6"/>
            </svg>
          </button>

          {/* ── VIP / Boost status ── */}
          {activeBoost && (
            <div className="flex justify-center">
              <BoostActivePill minutesLeft={boostMinutesLeft} />
            </div>
          )}

          {isVip ? (
            /* Active VIP card */
            <button
              onClick={() => setShowSubManager(true)}
              className="w-full rounded-2xl p-4 text-left relative overflow-hidden active:scale-[0.98] transition-transform"
              style={{
                background: 'linear-gradient(135deg,#f59e0b,#fbbf24,#f59e0b)',
                backgroundSize: '200% auto',
                animation: 'vip-shimmer 3s linear infinite',
                boxShadow: '0 0 20px rgba(245,158,11,0.35)',
              }}
            >
              <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-white/10 -translate-y-8 translate-x-8" />
              <div className="flex items-center gap-3 mb-2">
                <div className="w-12 h-12 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center text-2xl flex-shrink-0">👑</div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-black text-white text-sm">VIP Member</h3>
                    <VipBadge size="sm" animated={false} />
                  </div>
                  <p className="text-white/80 text-xs mt-0.5">All premium features active</p>
                </div>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="9 18 15 12 9 6"/>
                </svg>
              </div>
              <VipCountdownPill daysLeft={daysLeft} />
            </button>
          ) : (
            /* Upgrade CTA card */
            <button
              onClick={() => setShowVipModal(true)}
              className="w-full rounded-2xl p-4 text-left relative overflow-hidden active:scale-[0.98] transition-transform"
              style={{ background: 'linear-gradient(135deg,#fef3c7,#fde68a)' }}
            >
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-amber-400 flex items-center justify-center text-2xl flex-shrink-0">👑</div>
                <div className="flex-1">
                  <h3 className="font-bold text-gray-900 text-sm">Upgrade to VIP</h3>
                  <p className="text-xs text-gray-500 mt-0.5">Voice & video calls, see who likes you & more</p>
                </div>
                <div className="bg-amber-400 rounded-xl px-3 py-1.5 flex-shrink-0">
                  <span className="text-white text-xs font-bold">From $5</span>
                </div>
              </div>
            </button>
          )}

          {/* ── Sign Out ── */}
          {onSignOut && (
            <button
              onClick={onSignOut}
              className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl active:scale-[0.98] transition-transform"
              style={{ background: '#fff5f5', border: '1px solid #fecdd3' }}
            >
              <div className="w-11 h-11 rounded-xl bg-red-100 flex items-center justify-center flex-shrink-0">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                  <polyline points="16 17 21 12 16 7"/>
                  <line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
              </div>
              <div className="flex-1 text-left">
                <p className="font-bold text-red-600 text-sm">Sign Out</p>
                <p className="text-xs text-gray-400 mt-0.5">You'll be taken back to the landing page</p>
              </div>
            </button>
          )}
        </div>
      </div>

      {/* ════════════════════════════════════════
          EDIT PROFILE FULL-SCREEN MODAL
      ════════════════════════════════════════ */}
      {editMode && (
        <div className="absolute inset-0 z-50 bg-white flex flex-col animate-slide-up">
          {/* Header */}
          <div className="flex-shrink-0 flex items-center justify-between px-4 py-3.5 border-b border-gray-100">
            <button
              onClick={() => setEditMode(false)}
              className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-gray-100 text-gray-500"
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
            <h2 className="font-bold text-gray-900 text-base">Edit Profile</h2>
            <button
              onClick={saveEdit}
              className="px-4 py-2 rounded-full text-sm font-bold text-white active:scale-95 transition-transform"
              style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
            >
              Save
            </button>
          </div>

          <div className="flex-1 overflow-y-auto space-y-5 pb-6">
            {/* Cover photo */}
            <div>
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wide px-4 pt-4 pb-2">Cover Photo</p>
              <CoverUploader currentUrl={coverUrl} onUploaded={setCoverUrl} />
            </div>

            <div className="px-4 space-y-5">
            {/* Avatar change inside edit sheet */}
            <div className="flex flex-col items-center gap-2 py-1">
              <AvatarUploader
                currentUrl={avatarUrl}
                name={draftName}
                size={96}
                onUploaded={setAvatarUrl}
              />
              <p className="text-xs text-gray-400">Tap 📷 to change profile photo</p>
            </div>

            {/* Fields */}
            <Field label="Name" required>
              <input
                value={draftName}
                onChange={e => setDraftName(e.target.value)}
                placeholder="Your full name"
                maxLength={50}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors"
              />
            </Field>

            {/* Username — VIP only field */}
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Username</label>
                {!isVip && (
                  <span className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold text-amber-700"
                    style={{ background: 'linear-gradient(135deg,#fef3c7,#fde68a)' }}>
                    👑 VIP only
                  </span>
                )}
              </div>
              {isVip ? (
                <div>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-bold text-[#ff4d6d]">@</span>
                    <input
                      value={draftUsername}
                      onChange={e => {
                        const cleaned = e.target.value.toLowerCase().replace(/[^a-z0-9._]/g, '')
                        setDraftUsername(cleaned)
                        setUsernameError(validateUsername(cleaned))
                      }}
                      placeholder="yourhandle"
                      maxLength={30}
                      className="w-full pl-8 pr-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors font-semibold"
                      style={{ borderColor: usernameError ? '#ef4444' : undefined }}
                    />
                  </div>
                  {usernameError ? (
                    <p className="text-xs text-red-500 mt-1 ml-1">{usernameError}</p>
                  ) : (
                    <p className="text-xs text-gray-400 mt-1 ml-1">Letters, numbers, periods and underscores only</p>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => setShowVipModal(true)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl active:scale-[0.98] transition-transform text-left"
                  style={{ background: 'linear-gradient(135deg,#fef3c7,#fde68a)', border: '1px solid #fcd34d' }}
                >
                  <span className="text-xl">✏️</span>
                  <div>
                    <p className="font-bold text-amber-900 text-sm">Custom Username</p>
                    <p className="text-xs text-amber-700">Upgrade to VIP to set your own @handle</p>
                  </div>
                  <svg className="ml-auto" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d97706" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="9 18 15 12 9 6"/>
                  </svg>
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Age" required>
                <input
                  type="number"
                  value={draftAge}
                  onChange={e => setDraftAge(e.target.value)}
                  min="18" max="99"
                  placeholder="24"
                  className="w-full px-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors"
                />
              </Field>
              <Field label="Gender">
                <select
                  value={draftGender}
                  onChange={e => setDraftGender(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors"
                >
                  {['Male', 'Female', 'Non-binary', 'Prefer not to say'].map(g => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </Field>
            </div>

            <Field label="Location">
              <input
                value={draftLocation}
                onChange={e => setDraftLocation(e.target.value)}
                placeholder="City, Country"
                className="w-full px-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors"
              />
            </Field>

            <Field label="Bio">
              <textarea
                value={draftBio}
                onChange={e => setDraftBio(e.target.value)}
                placeholder="Tell people about yourself…"
                rows={4}
                maxLength={500}
                className="w-full px-4 py-3 bg-gray-50 rounded-xl text-sm text-gray-800 outline-none border border-gray-200 focus:border-[#ff4d6d] transition-colors resize-none"
              />
              <p className="text-right text-xs text-gray-400 mt-1">{draftBio.length}/500</p>
            </Field>

            {/* Interests picker */}
            <div>
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-3">
                Interests <span className="text-gray-300 font-normal normal-case">(select up to 8)</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {INTERESTS_ALL.map(i => {
                  const on = draftInterests.includes(i)
                  const disabled = !on && draftInterests.length >= 8
                  return (
                    <button
                      key={i}
                      onClick={() => !disabled && toggleDraftInterest(i)}
                      disabled={disabled}
                      className={`px-3 py-2 rounded-full text-xs font-semibold border transition-all active:scale-95 ${
                        on
                          ? 'bg-[#ff4d6d] text-white border-[#ff4d6d] shadow-sm'
                          : disabled
                          ? 'bg-gray-50 text-gray-300 border-gray-100 cursor-not-allowed'
                          : 'bg-gray-50 text-gray-600 border-gray-200 hover:border-[#ff4d6d]'
                      }`}
                    >
                      {i}
                    </button>
                  )
                })}
              </div>
            </div>
            </div>
          </div>
        </div>
      )}

      {/* Sound Settings */}
      {showSoundSettings && soundSettings && onUpdateSound && (
        <SoundSettingsModal
          settings={soundSettings}
          pushPermission={pushService.getPermission()}
          onUpdate={onUpdateSound}
          onRequestPush={async () => pushService.requestPermission()}
          onClose={() => setShowSoundSettings(false)}
        />
      )}

      {/* Theme Settings */}
      {showTheme && <ThemeSettings onClose={() => setShowTheme(false)} />}

      {/* Legal Hub */}
      {showLegal && <LegalHub onClose={() => setShowLegal(false)} />}

      {/* VIP Modal */}
      {showVipModal && <VipModal onClose={() => setShowVipModal(false)} />}

      {/* Subscription Manager */}
      {showSubManager && (
        <SubscriptionManager
          onClose={() => setShowSubManager(false)}
          onUpgrade={() => { setShowSubManager(false); setShowVipModal(true) }}
        />
      )}

      {/* ── Privacy & Safety Panel ── */}
      {showPrivacyPanel && (
        <PrivacySettingsPanel
          settings={privacy.settings}
          blockedUsers={privacy.blockedUsers}
          reports={privacy.reports}
          onUpdate={privacy.updateSetting}
          onUnblock={privacy.unblockUser}
          onClose={() => setShowPrivacyPanel(false)}
        />
      )}

      {/* ── Username Editor (quick modal, VIP only) ── */}
      {showUsernameEditor && (
        <div className="absolute inset-0 z-[60] flex flex-col justify-end bg-black/50 animate-slide-up">
          <div className="bg-white rounded-t-3xl px-5 pt-4 pb-10">
            {/* Handle */}
            <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-5" />

            {/* Header */}
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                style={{ background: 'linear-gradient(135deg,#fef3c7,#fbbf24)' }}>
                ✏️
              </div>
              <div>
                <h3 className="font-black text-gray-900 text-lg">Change Username</h3>
                <p className="text-xs text-gray-400">VIP exclusive feature</p>
              </div>
              <div className="ml-auto">
                <VipBadge size="sm" animated />
              </div>
            </div>

            {/* Input */}
            <div className="mb-4">
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg font-black text-[#ff4d6d]">@</span>
                <input
                  value={draftUsername}
                  onChange={e => {
                    const cleaned = e.target.value.toLowerCase().replace(/[^a-z0-9._]/g, '')
                    setDraftUsername(cleaned)
                    setUsernameError(validateUsername(cleaned))
                  }}
                  placeholder="yourhandle"
                  maxLength={30}
                  autoFocus
                  className="w-full pl-9 pr-4 py-4 bg-gray-50 rounded-2xl text-base font-bold text-gray-800 outline-none border-2 transition-colors"
                  style={{ borderColor: usernameError ? '#ef4444' : draftUsername ? '#ff4d6d' : '#e5e7eb' }}
                />
              </div>

              {/* Character count */}
              <div className="flex items-center justify-between mt-2 px-1">
                {usernameError ? (
                  <p className="text-xs text-red-500 font-medium">{usernameError}</p>
                ) : draftUsername.length >= 3 ? (
                  <p className="text-xs text-emerald-500 font-medium">✓ Looks good!</p>
                ) : (
                  <p className="text-xs text-gray-400">3–30 characters · letters, numbers, . and _</p>
                )}
                <span className="text-xs text-gray-400 font-medium">{draftUsername.length}/30</span>
              </div>
            </div>

            {/* Preview */}
            {draftUsername.length >= 3 && !usernameError && (
              <div className="flex items-center gap-2 px-4 py-3 bg-rose-50 rounded-2xl mb-4 border border-rose-100">
                <img src={avatarUrl} alt="" className="w-8 h-8 rounded-full object-cover" />
                <div>
                  <p className="font-bold text-gray-900 text-sm">{name}</p>
                  <p className="text-xs text-[#ff4d6d] font-semibold">@{draftUsername}</p>
                </div>
                <span className="ml-auto text-xs text-gray-400">Preview</span>
              </div>
            )}

            {/* Buttons */}
            <button
              onClick={handleUsernameSave}
              disabled={!!usernameError || draftUsername.length < 3}
              className="w-full py-4 rounded-2xl text-white font-black text-base mb-2 disabled:opacity-40 active:scale-[0.98] transition-transform"
              style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
            >
              Save @{draftUsername || 'username'}
            </button>
            <button
              onClick={() => { setShowUsernameEditor(false); setUsernameError('') }}
              className="w-full py-3 text-gray-400 font-semibold text-sm"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

function Field({ label, required, children }: { label: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1.5">
        {label}{required && <span className="text-[#ff4d6d] ml-0.5">*</span>}
      </label>
      {children}
    </div>
  )
}
