import { useState } from 'react'
import { matches as initialMatches, getRichProfile } from '../data/mockData'
import ChatScreen from '../chat/ChatScreen'
import { useCall } from '../calls/CallContext'
import UserProfileView, { type ViewableUser } from '../components/UserProfileView'


type Match = typeof initialMatches[0]

export default function MatchesPage() {
  const [selectedMatch, setSelectedMatch] = useState<Match | null>(null)
  const [viewingProfile, setViewingProfile] = useState<ViewableUser | null>(null)
  const { simulateIncomingCall } = useCall()

  if (selectedMatch) {
    return (
      <ChatScreen
        match={{
          id: selectedMatch.id,
          name: selectedMatch.name,
          avatar: selectedMatch.avatar,
          isVip: selectedMatch.isVip,
          isOnline: selectedMatch.isOnline,
        }}
        onBack={() => setSelectedMatch(null)}
      />
    )
  }

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ background: 'var(--color-bg)' }}>
      {/* Header */}
      <div className="flex-shrink-0 flex items-center justify-between px-4 py-3 border-b" style={{ background: 'var(--color-surface)', borderColor: 'var(--color-border)' }}>
        <div className="flex items-center gap-2">
          <svg width="22" height="20" viewBox="0 0 24 22" fill="#ff4d6d">
            <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
          </svg>
          <span className="text-[22px] font-bold text-[#ff4d6d]">Matches</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-400 bg-gray-100 px-3 py-1 rounded-full font-medium">
            {initialMatches.length} matches
          </span>
          {/* Demo: simulate incoming call */}
          <button
            onClick={() => simulateIncomingCall(
              { id: initialMatches[0].id, name: initialMatches[0].name, avatar: initialMatches[0].avatar, isVip: initialMatches[0].isVip },
              Math.random() > 0.5 ? 'video' : 'voice'
            )}
            className="text-xs text-[#ff4d6d] bg-rose-50 border border-rose-200 px-2 py-1 rounded-full font-semibold"
            title="Simulate incoming call"
          >
            📞 Test Call
          </button>
        </div>
      </div>

      {/* Match list */}
      <div className="flex-1 overflow-y-auto divide-y divide-gray-50">
        {initialMatches.map(match => (
          <div
            key={match.id}
            className="flex items-center gap-3 px-4 py-3.5 hover:bg-rose-50/40 transition-colors"
          >
            {/* Avatar — tap to view profile */}
            <button
              onClick={() => {
                const rich = getRichProfile(match.name, { id: match.id, name: match.name, avatar: match.avatar, isVip: match.isVip, isOnline: match.isOnline })
                setViewingProfile(rich ?? { id: match.id, name: match.name, avatar: match.avatar, isVip: match.isVip, isOnline: match.isOnline })
              }}
              className="relative flex-shrink-0 active:scale-90 transition-transform"
            >
              <img
                src={match.avatar}
                alt={match.name}
                className="w-14 h-14 rounded-full object-cover ring-2 ring-white shadow-sm"
              />
              {match.isOnline && (
                <div className="absolute bottom-0.5 right-0.5 w-3.5 h-3.5 bg-green-400 rounded-full border-2 border-white" />
              )}
              {match.isVip && (
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-amber-400 rounded-full flex items-center justify-center text-[10px] shadow">
                  👑
                </div>
              )}
            </button>

            {/* Info — tap to open chat */}
            <button
              onClick={() => setSelectedMatch(match)}
              className="flex-1 text-left overflow-hidden"
            >
              <div className="flex items-center justify-between mb-0.5">
                <span className="font-bold text-sm text-gray-900">{match.name}</span>
                <span className="text-[11px] text-gray-400">{match.timeAgo}</span>
              </div>
              <p className="text-sm text-gray-500 truncate">{match.lastMessage}</p>
            </button>

            {/* Unread badge */}
            {match.unread > 0 && (
              <div
                className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm"
                style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}
              >
                <span className="text-white text-[10px] font-bold">{match.unread}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Profile viewer — opens when tapping a match avatar */}
      {viewingProfile && (
        <UserProfileView
          user={viewingProfile}
          onClose={() => setViewingProfile(null)}
          onMessage={() => {
            const m = initialMatches.find(x => x.id === viewingProfile.id)
            if (m) setSelectedMatch(m)
            setViewingProfile(null)
          }}
        />
      )}
    </div>
  )
}
