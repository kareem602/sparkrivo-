import { useState } from 'react'

interface Props {
  onGetStarted: () => void
  onSignIn: () => void
}

const PROFILES = [
  { avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face', name: 'Chisom', age: 24, loc: 'Lagos' },
  { avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face', name: 'Kevin', age: 27, loc: 'Abuja' },
  { avatar: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=200&h=200&fit=crop&crop=face', name: 'Fatima', age: 22, loc: 'Lagos' },
  { avatar: 'https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=200&h=200&fit=crop&crop=face', name: 'Blessing', age: 26, loc: 'PH' },
  { avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face', name: 'Olawale', age: 25, loc: 'Lagos' },
  { avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=200&h=200&fit=crop&crop=face', name: 'Ngozi', age: 23, loc: 'Enugu' },
]

const FEATURES = [
  { icon: '💕', title: 'Smart Matching', desc: 'AI-powered matches based on your interests and vibe' },
  { icon: '💬', title: 'Real-time Chat', desc: 'Unlimited messaging with voice notes, photos & videos' },
  { icon: '📞', title: 'Voice & Video Calls', desc: 'Private HD calls with your matches — VIP exclusive' },
  { icon: '📖', title: '24h Stories', desc: 'Share your day and see what your matches are up to' },
  { icon: '🛡️', title: 'Safe & Secure', desc: 'AI moderation, block/report, and privacy controls' },
  { icon: '👑', title: 'VIP Features', desc: 'Unlock unlimited swipes, boosts, and exclusive perks' },
]

export default function LandingPage({ onGetStarted, onSignIn }: Props) {
  const [activeFeature, setActiveFeature] = useState(0)

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white">

      {/* ── Scrollable body ── */}
      <div className="flex-1 overflow-y-auto scrollbar-none">

        {/* ── Hero section ── */}
        <div
          className="relative flex flex-col items-center pt-16 pb-10 px-6"
          style={{ background: 'linear-gradient(160deg, #ff4d6d 0%, #ff6b85 40%, #c0392b 100%)' }}
        >
          {/* Floating profile bubbles */}
          <div className="relative w-full flex justify-center mb-8" style={{ height: 260 }}>
            {/* Centre card */}
            <div
              className="absolute rounded-3xl overflow-hidden shadow-2xl border-4 border-white"
              style={{ width: 160, height: 200, top: 20, left: '50%', transform: 'translateX(-50%)', zIndex: 3 }}
            >
              <img src={PROFILES[0].avatar} alt="" className="w-full h-full object-cover" />
              <div className="absolute bottom-0 left-0 right-0 px-3 py-2" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.7), transparent)' }}>
                <p className="text-white font-bold text-sm">{PROFILES[0].name}, {PROFILES[0].age}</p>
                <p className="text-white/70 text-xs">📍 {PROFILES[0].loc}</p>
              </div>
              {/* Match badge */}
              <div className="absolute top-2 right-2 px-2 py-1 rounded-full text-xs font-bold text-white" style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)' }}>
                💕 98%
              </div>
            </div>
            {/* Left card */}
            <div
              className="absolute rounded-2xl overflow-hidden shadow-xl border-3 border-white/80"
              style={{ width: 120, height: 155, top: 55, left: '10%', zIndex: 2, transform: 'rotate(-8deg)' }}
            >
              <img src={PROFILES[1].avatar} alt="" className="w-full h-full object-cover" />
            </div>
            {/* Right card */}
            <div
              className="absolute rounded-2xl overflow-hidden shadow-xl border-3 border-white/80"
              style={{ width: 120, height: 155, top: 55, right: '10%', zIndex: 2, transform: 'rotate(8deg)' }}
            >
              <img src={PROFILES[2].avatar} alt="" className="w-full h-full object-cover" />
            </div>
            {/* Small left */}
            <div
              className="absolute rounded-xl overflow-hidden shadow-lg border-2 border-white/70"
              style={{ width: 72, height: 90, bottom: 0, left: '8%', zIndex: 1, transform: 'rotate(-4deg)' }}
            >
              <img src={PROFILES[3].avatar} alt="" className="w-full h-full object-cover" />
            </div>
            {/* Small right */}
            <div
              className="absolute rounded-xl overflow-hidden shadow-lg border-2 border-white/70"
              style={{ width: 72, height: 90, bottom: 0, right: '8%', zIndex: 1, transform: 'rotate(4deg)' }}
            >
              <img src={PROFILES[4].avatar} alt="" className="w-full h-full object-cover" />
            </div>

            {/* Floating hearts */}
            <div className="absolute top-0 left-4 text-2xl animate-bounce" style={{ animationDelay: '0s' }}>💕</div>
            <div className="absolute top-10 right-4 text-xl animate-bounce" style={{ animationDelay: '0.4s' }}>✨</div>
            <div className="absolute bottom-4 left-20 text-lg animate-bounce" style={{ animationDelay: '0.8s' }}>❤️</div>
          </div>

          {/* Hero text */}
          <h1 className="text-white font-black text-4xl text-center leading-tight mb-3">
            Find Your<br />
            <span style={{ color: '#ffe0e6' }}>Perfect Match</span>
          </h1>
          <p className="text-white/80 text-base text-center leading-relaxed max-w-xs">
            Join thousands of singles finding real connections every day on SparkMatch 🇳🇬
          </p>

          {/* Stats row */}
          <div className="flex items-center gap-6 mt-6 mb-2">
            {[['50K+','Members'],['98%','Match rate'],['4.9★','Rating']].map(([val, lbl]) => (
              <div key={lbl} className="text-center">
                <p className="text-white font-black text-xl leading-tight">{val}</p>
                <p className="text-white/70 text-xs font-medium">{lbl}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── Features section ── */}
        <div className="px-5 py-8">
          <h2 className="font-black text-gray-900 text-2xl text-center mb-6">
            Everything you need to<br />
            <span style={{ color: '#ff4d6d' }}>connect & flourish</span>
          </h2>

          <div className="grid grid-cols-2 gap-3 mb-8">
            {FEATURES.map((f, i) => (
              <button
                key={i}
                onClick={() => setActiveFeature(i)}
                className="flex flex-col items-start gap-2 p-4 rounded-2xl text-left transition-all active:scale-[0.97]"
                style={{
                  background: activeFeature === i
                    ? 'linear-gradient(135deg, #fff0f4, #fce8ef)'
                    : '#f9fafb',
                  border: `2px solid ${activeFeature === i ? '#ff4d6d' : '#f3f4f6'}`,
                  boxShadow: activeFeature === i ? '0 4px 12px rgba(255,77,109,0.15)' : 'none',
                }}
              >
                <span className="text-2xl">{f.icon}</span>
                <div>
                  <p className={`font-bold text-sm leading-tight ${activeFeature === i ? 'text-[#ff4d6d]' : 'text-gray-800'}`}>{f.title}</p>
                  <p className="text-gray-500 text-xs mt-0.5 leading-snug">{f.desc}</p>
                </div>
              </button>
            ))}
          </div>

          {/* Testimonials */}
          <div
            className="rounded-3xl p-5 mb-8"
            style={{ background: 'linear-gradient(135deg, #fff0f4, #fce8ef)', border: '1px solid #fecdd3' }}
          >
            <div className="flex items-center gap-3 mb-3">
              <img src={PROFILES[5].avatar} alt="" className="w-11 h-11 rounded-full object-cover border-2 border-white shadow" />
              <div>
                <p className="font-bold text-gray-900 text-sm">Ngozi A.</p>
                <div className="flex text-amber-400 text-xs">{'★★★★★'}</div>
              </div>
            </div>
            <p className="text-gray-700 text-sm leading-relaxed italic">
              "I found my partner of 2 years on SparkMatch! The matching algorithm is incredible. Highly recommend to anyone looking for something real." 💕
            </p>
          </div>

          {/* VIP promo */}
          <div
            className="rounded-3xl p-5 mb-8 relative overflow-hidden"
            style={{ background: 'linear-gradient(135deg, #f59e0b, #fbbf24)' }}
          >
            <div className="absolute top-0 right-0 w-24 h-24 rounded-full bg-white/10 -translate-y-8 translate-x-8" />
            <div className="flex items-center gap-3 mb-3">
              <span className="text-4xl">👑</span>
              <div>
                <p className="font-black text-white text-lg">Go VIP</p>
                <p className="text-white/80 text-xs">From just $5/month</p>
              </div>
            </div>
            <div className="space-y-1.5 mb-4">
              {['See who liked you', 'Unlimited swipes & likes', 'Voice & video calls', 'Custom chat wallpapers', 'Profile boost (3× visibility)'].map(f => (
                <div key={f} className="flex items-center gap-2">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                  <span className="text-white text-xs font-medium">{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── Fixed CTA bar ── */}
      <div className="flex-shrink-0 px-5 pb-8 pt-4 bg-white" style={{ borderTop: '1px solid #f3f4f6' }}>
        {/* Primary CTA */}
        <button
          onClick={onGetStarted}
          className="w-full py-4 rounded-2xl text-white font-black text-lg mb-3 active:scale-[0.98] transition-transform"
          style={{ background: 'linear-gradient(135deg,#ff4d6d,#ff8fa3)', boxShadow: '0 8px 24px rgba(255,77,109,0.35)' }}
        >
          Create Free Account ✨
        </button>

        {/* Sign in link */}
        <div className="text-center">
          <span className="text-gray-500 text-sm">Already have an account? </span>
          <button
            onClick={onSignIn}
            className="text-[#ff4d6d] font-bold text-sm active:opacity-70 transition-opacity"
          >
            Sign In
          </button>
        </div>

        {/* Legal notice */}
        <p className="text-center text-gray-400 text-[11px] mt-3 leading-relaxed">
          By continuing you agree to our{' '}
          <span className="text-[#ff4d6d] font-medium">Terms of Service</span>
          {' & '}
          <span className="text-[#ff4d6d] font-medium">Privacy Policy</span>
        </p>
      </div>
    </div>
  )
}
