// SparkMatch Service Worker — handles background push notifications
const CACHE = 'sparkmatch-v1'

self.addEventListener('install', () => self.skipWaiting())
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()))

// Background push event (from a real push server like Firebase)
self.addEventListener('push', e => {
  let data = { title: 'SparkMatch', body: 'You have a new notification!' }
  try { data = e.data?.json() ?? data } catch {}
  e.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: '/icon-192.png',
      badge: '/badge-72.png',
      tag: data.tag ?? 'sparkmatch',
      data: data,
    })
  )
})

// Notification click — focus or open the app
self.addEventListener('notificationclick', e => {
  e.notification.close()
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(clients => {
      const existing = clients.find(c => c.url.includes(self.location.origin) && 'focus' in c)
      if (existing) return existing.focus()
      return self.clients.openWindow('/')
    })
  )
})

// Minimal fetch handler — pass through
self.addEventListener('fetch', e => e.respondWith(fetch(e.request).catch(() => new Response(''))))
